dnl Copyright 2002, The libsigc++ Development Team 
dnl 
dnl This library is free software; you can redistribute it and/or 
dnl modify it under the terms of the GNU Lesser General Public 
dnl License as published by the Free Software Foundation; either 
dnl version 2.1 of the License, or (at your option) any later version. 
dnl 
dnl This library is distributed in the hope that it will be useful, 
dnl but WITHOUT ANY WARRANTY; without even the implied warranty of 
dnl MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU 
dnl Lesser General Public License for more details. 
dnl 
dnl You should have received a copy of the GNU Lesser General Public 
dnl License along with this library; if not, write to the Free Software 
dnl Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
dnl
divert(-1)
include(template.macros.m4)
divert(0)dnl
#include <sigc++/adaptors/lambda/select.h>

_DEPRECATE_IFDEF_START

namespace sigc {

// sigc::_1 .. sigc::_7 must be kept until we can break ABI.
// See https://bugzilla.gnome.org/show_bug.cgi?id=755550
// The extern declarations have been moved from select.h, to keep them out of the API.
// Without them the const sigc::_1 .. sigc::_7 would be local to this .cc file.
FOR(1,CALL_SIZE,[[extern SIGC_API const lambda<internal::lambda_select%1> _%1;
]])
FOR(1,CALL_SIZE,[[const lambda<internal::lambda_select%1> _%1;
]])
} /* namespace sigc */

_DEPRECATE_IFDEF_END

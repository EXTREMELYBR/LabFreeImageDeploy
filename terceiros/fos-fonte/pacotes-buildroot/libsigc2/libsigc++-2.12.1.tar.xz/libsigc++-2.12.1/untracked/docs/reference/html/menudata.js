/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var menudata={children:[
{text:"Main Page",url:"index.html"},
{text:"Related Pages",url:"pages.html"},
{text:"Modules",url:"modules.html"},
{text:"Namespaces",url:"namespaces.html",children:[
{text:"Namespace List",url:"namespaces.html"},
{text:"Namespace Members",url:"namespacemembers.html",children:[
{text:"All",url:"namespacemembers.html",children:[
{text:"b",url:"namespacemembers.html#index_b"},
{text:"c",url:"namespacemembers_c.html#index_c"},
{text:"d",url:"namespacemembers_d.html#index_d"},
{text:"e",url:"namespacemembers_e.html#index_e"},
{text:"h",url:"namespacemembers_h.html#index_h"},
{text:"m",url:"namespacemembers_m.html#index_m"},
{text:"p",url:"namespacemembers_p.html#index_p"},
{text:"r",url:"namespacemembers_r.html#index_r"},
{text:"t",url:"namespacemembers_t.html#index_t"},
{text:"u",url:"namespacemembers_u.html#index_u"},
{text:"v",url:"namespacemembers_v.html#index_v"}]},
{text:"Functions",url:"namespacemembers_func.html",children:[
{text:"b",url:"namespacemembers_func.html#index_b"},
{text:"c",url:"namespacemembers_func_c.html#index_c"},
{text:"e",url:"namespacemembers_func_e.html#index_e"},
{text:"h",url:"namespacemembers_func_h.html#index_h"},
{text:"m",url:"namespacemembers_func_m.html#index_m"},
{text:"p",url:"namespacemembers_func_p.html#index_p"},
{text:"r",url:"namespacemembers_func_r.html#index_r"},
{text:"t",url:"namespacemembers_func_t.html#index_t"},
{text:"u",url:"namespacemembers_func_u.html#index_u"},
{text:"v",url:"namespacemembers_func_v.html#index_v"}]},
{text:"Typedefs",url:"namespacemembers_type.html"}]}]},
{text:"Classes",url:"annotated.html",children:[
{text:"Class List",url:"annotated.html"},
{text:"Class Index",url:"classes.html"},
{text:"Class Hierarchy",url:"inherits.html"},
{text:"Class Members",url:"functions.html",children:[
{text:"All",url:"functions.html",children:[
{text:"a",url:"functions.html#index_a"},
{text:"b",url:"functions_b.html#index_b"},
{text:"c",url:"functions_c.html#index_c"},
{text:"d",url:"functions_d.html#index_d"},
{text:"e",url:"functions_e.html#index_e"},
{text:"f",url:"functions_f.html#index_f"},
{text:"g",url:"functions_g.html#index_g"},
{text:"h",url:"functions_h.html#index_h"},
{text:"i",url:"functions_i.html#index_i"},
{text:"l",url:"functions_l.html#index_l"},
{text:"m",url:"functions_m.html#index_m"},
{text:"n",url:"functions_n.html#index_n"},
{text:"o",url:"functions_o.html#index_o"},
{text:"p",url:"functions_p.html#index_p"},
{text:"r",url:"functions_r.html#index_r"},
{text:"s",url:"functions_s.html#index_s"},
{text:"t",url:"functions_t.html#index_t"},
{text:"u",url:"functions_u.html#index_u"},
{text:"v",url:"functions_v.html#index_v"},
{text:"~",url:"functions_~.html#index__7E"}]},
{text:"Functions",url:"functions_func.html",children:[
{text:"a",url:"functions_func.html#index_a"},
{text:"b",url:"functions_func_b.html#index_b"},
{text:"c",url:"functions_func_c.html#index_c"},
{text:"d",url:"functions_func_d.html#index_d"},
{text:"e",url:"functions_func_e.html#index_e"},
{text:"f",url:"functions_func_f.html#index_f"},
{text:"h",url:"functions_func_h.html#index_h"},
{text:"i",url:"functions_func_i.html#index_i"},
{text:"l",url:"functions_func_l.html#index_l"},
{text:"m",url:"functions_func_m.html#index_m"},
{text:"n",url:"functions_func_n.html#index_n"},
{text:"o",url:"functions_func_o.html#index_o"},
{text:"p",url:"functions_func_p.html#index_p"},
{text:"r",url:"functions_func_r.html#index_r"},
{text:"s",url:"functions_func_s.html#index_s"},
{text:"t",url:"functions_func_t.html#index_t"},
{text:"u",url:"functions_func_u.html#index_u"},
{text:"v",url:"functions_func_v.html#index_v"},
{text:"~",url:"functions_func_~.html#index__7E"}]},
{text:"Variables",url:"functions_vars.html",children:[
{text:"b",url:"functions_vars.html#index_b"},
{text:"c",url:"functions_vars.html#index_c"},
{text:"f",url:"functions_vars.html#index_f"},
{text:"g",url:"functions_vars.html#index_g"},
{text:"i",url:"functions_vars.html#index_i"},
{text:"l",url:"functions_vars.html#index_l"},
{text:"o",url:"functions_vars.html#index_o"},
{text:"r",url:"functions_vars.html#index_r"},
{text:"v",url:"functions_vars.html#index_v"}]},
{text:"Typedefs",url:"functions_type.html",children:[
{text:"a",url:"functions_type.html#index_a"},
{text:"c",url:"functions_type_c.html#index_c"},
{text:"d",url:"functions_type_d.html#index_d"},
{text:"e",url:"functions_type_e.html#index_e"},
{text:"f",url:"functions_type_f.html#index_f"},
{text:"g",url:"functions_type_g.html#index_g"},
{text:"i",url:"functions_type_i.html#index_i"},
{text:"p",url:"functions_type_p.html#index_p"},
{text:"r",url:"functions_type_r.html#index_r"},
{text:"s",url:"functions_type_s.html#index_s"},
{text:"t",url:"functions_type_t.html#index_t"},
{text:"v",url:"functions_type_v.html#index_v"}]}]}]}]}

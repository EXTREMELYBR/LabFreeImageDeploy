<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>
<tagfile doxygen_version="1.9.4">
  <compound kind="class">
    <name>basic_streambuf</name>
    <filename>classbasic__streambuf.html</filename>
  </compound>
  <compound kind="class">
    <name>mask_based_range_hashing</name>
    <filename>classmask__based__range__hashing.html</filename>
  </compound>
  <compound kind="class">
    <name>mod_based_range_hashing</name>
    <filename>classmod__based__range__hashing.html</filename>
  </compound>
  <compound kind="struct">
    <name>sigc::adaptor_base</name>
    <filename>structsigc_1_1adaptor__base.html</filename>
    <base>sigc::functor_base</base>
  </compound>
  <compound kind="struct">
    <name>sigc::adaptor_functor</name>
    <filename>structsigc_1_1adaptor__functor.html</filename>
    <templarg>class T_functor</templarg>
    <base>sigc::adaptor_base</base>
    <member kind="typedef">
      <type>functor_trait&lt; T_functor &gt;::result_type</type>
      <name>result_type</name>
      <anchorfile>structsigc_1_1adaptor__functor.html</anchorfile>
      <anchor>adc1e7ebba9db294494c62666e10b719b</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>adaptor_functor</name>
      <anchorfile>structsigc_1_1adaptor__functor.html</anchorfile>
      <anchor>a39ef4610f8e0f03425b6f4a44b59e5fb</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>adaptor_functor</name>
      <anchorfile>structsigc_1_1adaptor__functor.html</anchorfile>
      <anchor>ac5907212f7ee2eadf10b31757a0c5930</anchor>
      <arglist>(const T_functor &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>adaptor_functor</name>
      <anchorfile>structsigc_1_1adaptor__functor.html</anchorfile>
      <anchor>af765e401002eb15f18aca5cfaa678b01</anchor>
      <arglist>(const T_type &amp;_A_type)</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1adaptor__functor.html</anchorfile>
      <anchor>aa8f3859324cce86596f0eb81b7bb6037</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1adaptor__functor.html</anchorfile>
      <anchor>adcd467ad020d2a34ef9d4b3ab6eb6bed</anchor>
      <arglist>(T_arg1 _A_arg1) const</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1adaptor__functor.html</anchorfile>
      <anchor>addf63c1bb9b094663c3d21523878ae09</anchor>
      <arglist>(T_arg1 _A_arg1, T_arg2 _A_arg2) const</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1adaptor__functor.html</anchorfile>
      <anchor>a7904faa29886db76315c8ecbacd4da08</anchor>
      <arglist>(T_arg1 _A_arg1, T_arg2 _A_arg2, T_arg3 _A_arg3) const</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1adaptor__functor.html</anchorfile>
      <anchor>ac5cdbc08cc4ba125c6157e012a46c279</anchor>
      <arglist>(T_arg1 _A_arg1, T_arg2 _A_arg2, T_arg3 _A_arg3, T_arg4 _A_arg4) const</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1adaptor__functor.html</anchorfile>
      <anchor>a58ac558ad1d5c5da0c9079c458a2f928</anchor>
      <arglist>(T_arg1 _A_arg1, T_arg2 _A_arg2, T_arg3 _A_arg3, T_arg4 _A_arg4, T_arg5 _A_arg5) const</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1adaptor__functor.html</anchorfile>
      <anchor>a7372a24b5a4c7383a8fa4985b3c25beb</anchor>
      <arglist>(T_arg1 _A_arg1, T_arg2 _A_arg2, T_arg3 _A_arg3, T_arg4 _A_arg4, T_arg5 _A_arg5, T_arg6 _A_arg6) const</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1adaptor__functor.html</anchorfile>
      <anchor>af3f1736e705667ea3e9c32fcb989d8fa</anchor>
      <arglist>(T_arg1 _A_arg1, T_arg2 _A_arg2, T_arg3 _A_arg3, T_arg4 _A_arg4, T_arg5 _A_arg5, T_arg6 _A_arg6, T_arg7 _A_arg7) const</arglist>
    </member>
    <member kind="variable">
      <type>T_functor</type>
      <name>functor_</name>
      <anchorfile>structsigc_1_1adaptor__functor.html</anchorfile>
      <anchor>a4faff6b7a82f4f6d92e3d3b0aa8fdca8</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::adaptor_trait</name>
    <filename>structsigc_1_1adaptor__trait.html</filename>
    <templarg>class T_functor</templarg>
    <templarg>bool I_isadaptor</templarg>
  </compound>
  <compound kind="struct">
    <name>sigc::adaptor_trait&lt; T_functor, false &gt;</name>
    <filename>structsigc_1_1adaptor__trait_3_01T__functor_00_01false_01_4.html</filename>
    <templarg>class T_functor</templarg>
    <member kind="typedef">
      <type>adaptor_functor&lt; functor_type &gt;</type>
      <name>adaptor_type</name>
      <anchorfile>structsigc_1_1adaptor__trait_3_01T__functor_00_01false_01_4.html</anchorfile>
      <anchor>ad3bd68364a24b2b6580b523d5301b25c</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>functor_trait&lt; T_functor &gt;::functor_type</type>
      <name>functor_type</name>
      <anchorfile>structsigc_1_1adaptor__trait_3_01T__functor_00_01false_01_4.html</anchorfile>
      <anchor>acb1a7066d665d00e2525c49d089efc0f</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>functor_trait&lt; T_functor &gt;::result_type</type>
      <name>result_type</name>
      <anchorfile>structsigc_1_1adaptor__trait_3_01T__functor_00_01false_01_4.html</anchorfile>
      <anchor>a512a6d201bdd43574a2df993b3b85d0e</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::adaptor_trait&lt; T_functor, true &gt;</name>
    <filename>structsigc_1_1adaptor__trait_3_01T__functor_00_01true_01_4.html</filename>
    <templarg>class T_functor</templarg>
    <member kind="typedef">
      <type>T_functor</type>
      <name>adaptor_type</name>
      <anchorfile>structsigc_1_1adaptor__trait_3_01T__functor_00_01true_01_4.html</anchorfile>
      <anchor>a449daad4cd77bd1fbfe59d8fae9d9039</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_functor</type>
      <name>functor_type</name>
      <anchorfile>structsigc_1_1adaptor__trait_3_01T__functor_00_01true_01_4.html</anchorfile>
      <anchor>ae065e339af2abe58cad43d630328240f</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_functor::result_type</type>
      <name>result_type</name>
      <anchorfile>structsigc_1_1adaptor__trait_3_01T__functor_00_01true_01_4.html</anchorfile>
      <anchor>a6b83ed91f53a25e7002546a2835457b3</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::adapts</name>
    <filename>structsigc_1_1adapts.html</filename>
    <templarg>class T_functor</templarg>
    <base>sigc::adaptor_base</base>
    <member kind="typedef">
      <type>adaptor_trait&lt; T_functor &gt;::adaptor_type</type>
      <name>adaptor_type</name>
      <anchorfile>structsigc_1_1adapts.html</anchorfile>
      <anchor>a5c3f3b614455552f4cd5d88b1f330248</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>adaptor_trait&lt; T_functor &gt;::result_type</type>
      <name>result_type</name>
      <anchorfile>structsigc_1_1adapts.html</anchorfile>
      <anchor>a914e75556dae1fdcf0162c4c99aca79d</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>adapts</name>
      <anchorfile>structsigc_1_1adapts.html</anchorfile>
      <anchor>a947b69ccbdcabd4ef4163dcab96096f8</anchor>
      <arglist>(const T_functor &amp;_A_functor)</arglist>
    </member>
    <member kind="variable">
      <type>adaptor_type</type>
      <name>functor_</name>
      <anchorfile>structsigc_1_1adapts.html</anchorfile>
      <anchor>a2f4b37eb160708baf17de57f2abce7a7</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::bind_functor</name>
    <filename>structsigc_1_1bind__functor.html</filename>
    <templarg>int I_location</templarg>
    <templarg>class T_functor</templarg>
    <templarg>class T_type1</templarg>
    <templarg>class T_type2</templarg>
    <templarg>class T_type3</templarg>
    <templarg>class T_type4</templarg>
    <templarg>class T_type5</templarg>
    <templarg>class T_type6</templarg>
    <templarg>class T_type7</templarg>
  </compound>
  <compound kind="struct">
    <name>sigc::bind_functor&lt; 0, T_functor, T_bound, nil, nil, nil, nil, nil, nil &gt;</name>
    <filename>structsigc_1_1bind__functor_3_010_00_01T__functor_00_01T__bound_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</filename>
    <templarg>class T_functor</templarg>
    <templarg>class T_bound</templarg>
    <base>sigc::adapts</base>
    <member kind="typedef">
      <type>adapts&lt; T_functor &gt;::adaptor_type</type>
      <name>adaptor_type</name>
      <anchorfile>structsigc_1_1bind__functor_3_010_00_01T__functor_00_01T__bound_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>ac6004db92703257f83addd412037f1f7</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>adaptor_type::result_type</type>
      <name>result_type</name>
      <anchorfile>structsigc_1_1bind__functor_3_010_00_01T__functor_00_01T__bound_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a1c6d091ffd70c23930cf6e2b9042d466</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bind_functor</name>
      <anchorfile>structsigc_1_1bind__functor_3_010_00_01T__functor_00_01T__bound_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>ac170bca0fe2af4722cf6e1fd6b3de128</anchor>
      <arglist>(type_trait_take_t&lt; T_functor &gt; _A_func, type_trait_take_t&lt; T_bound &gt; _A_bound)</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1bind__functor_3_010_00_01T__functor_00_01T__bound_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a0f1c2891d52c9f564e571209dbef6f54</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1bind__functor_3_010_00_01T__functor_00_01T__bound_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a085c5257409c1efe8e644b6c63c46349</anchor>
      <arglist>(T_arg1 _A_arg1)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1bind__functor_3_010_00_01T__functor_00_01T__bound_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a70ae89829956ee6453cc204c8f7155e8</anchor>
      <arglist>(T_arg1 _A_arg1, T_arg2 _A_arg2)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1bind__functor_3_010_00_01T__functor_00_01T__bound_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a0b91a32a18fd707ec1953a2c449208b4</anchor>
      <arglist>(T_arg1 _A_arg1, T_arg2 _A_arg2, T_arg3 _A_arg3)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1bind__functor_3_010_00_01T__functor_00_01T__bound_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>aa16e6e69b6dc830c97ac2f3271e0d970</anchor>
      <arglist>(T_arg1 _A_arg1, T_arg2 _A_arg2, T_arg3 _A_arg3, T_arg4 _A_arg4)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1bind__functor_3_010_00_01T__functor_00_01T__bound_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a665e5179a484e000402c4c1b19b7df99</anchor>
      <arglist>(T_arg1 _A_arg1, T_arg2 _A_arg2, T_arg3 _A_arg3, T_arg4 _A_arg4, T_arg5 _A_arg5)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1bind__functor_3_010_00_01T__functor_00_01T__bound_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a26cf0ffbedfb4d8601f47ca8255c21ee</anchor>
      <arglist>(T_arg1 _A_arg1, T_arg2 _A_arg2, T_arg3 _A_arg3, T_arg4 _A_arg4, T_arg5 _A_arg5, T_arg6 _A_arg6)</arglist>
    </member>
    <member kind="variable">
      <type>bound_argument&lt; T_bound &gt;</type>
      <name>bound_</name>
      <anchorfile>structsigc_1_1bind__functor_3_010_00_01T__functor_00_01T__bound_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>afbbf5b4d89cf98a1224da5d72554afdc</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::bind_functor&lt;-1, T_functor, T_type1, nil, nil, nil, nil, nil, nil &gt;</name>
    <filename>structsigc_1_1bind__functor_3-1_00_01T__functor_00_01T__type1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</filename>
    <templarg>class T_functor</templarg>
    <templarg>class T_type1</templarg>
    <base>sigc::adapts</base>
    <member kind="typedef">
      <type>adapts&lt; T_functor &gt;::adaptor_type</type>
      <name>adaptor_type</name>
      <anchorfile>structsigc_1_1bind__functor_3-1_00_01T__functor_00_01T__type1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>ac249b81b5d6fff6e7c4b1d9b47a98077</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>adaptor_type::result_type</type>
      <name>result_type</name>
      <anchorfile>structsigc_1_1bind__functor_3-1_00_01T__functor_00_01T__type1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>abd1e51093bf7d4428e443c2e6704bed9</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bind_functor</name>
      <anchorfile>structsigc_1_1bind__functor_3-1_00_01T__functor_00_01T__type1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>ad61bb64a42d144999a94767cd6031259</anchor>
      <arglist>(type_trait_take_t&lt; T_functor &gt; _A_func, type_trait_take_t&lt; T_type1 &gt; _A_bound1)</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1bind__functor_3-1_00_01T__functor_00_01T__type1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a5bd5dd13ef2cd495cfd23b8d0f7cffbd</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1bind__functor_3-1_00_01T__functor_00_01T__type1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a4a2c3cde26dea29cd36af2c8186a897a</anchor>
      <arglist>(T_arg1 _A_arg1)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1bind__functor_3-1_00_01T__functor_00_01T__type1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>abeb5701626b0c5a4e81b612bd049d48d</anchor>
      <arglist>(T_arg1 _A_arg1, T_arg2 _A_arg2)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1bind__functor_3-1_00_01T__functor_00_01T__type1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>adcbb341411dd3bfda24b1a56f013ae43</anchor>
      <arglist>(T_arg1 _A_arg1, T_arg2 _A_arg2, T_arg3 _A_arg3)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1bind__functor_3-1_00_01T__functor_00_01T__type1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a4e373ac9bfae9efbacc35b6d0b66ac60</anchor>
      <arglist>(T_arg1 _A_arg1, T_arg2 _A_arg2, T_arg3 _A_arg3, T_arg4 _A_arg4)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1bind__functor_3-1_00_01T__functor_00_01T__type1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>acab2506b39e2c99e53384c1fdcd00e79</anchor>
      <arglist>(T_arg1 _A_arg1, T_arg2 _A_arg2, T_arg3 _A_arg3, T_arg4 _A_arg4, T_arg5 _A_arg5)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1bind__functor_3-1_00_01T__functor_00_01T__type1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a29b4ea6235b05d02158f75e5fcab674a</anchor>
      <arglist>(T_arg1 _A_arg1, T_arg2 _A_arg2, T_arg3 _A_arg3, T_arg4 _A_arg4, T_arg5 _A_arg5, T_arg6 _A_arg6)</arglist>
    </member>
    <member kind="variable">
      <type>bound_argument&lt; T_type1 &gt;</type>
      <name>bound1_</name>
      <anchorfile>structsigc_1_1bind__functor_3-1_00_01T__functor_00_01T__type1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a5e92e05deb3d9e952a49a338bac42cb4</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::bind_return_functor</name>
    <filename>structsigc_1_1bind__return__functor.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_functor</templarg>
    <base>sigc::adapts</base>
    <member kind="typedef">
      <type>unwrap_reference&lt; T_return &gt;::type</type>
      <name>result_type</name>
      <anchorfile>structsigc_1_1bind__return__functor.html</anchorfile>
      <anchor>a4fe6cb8d80573ae7abe934ba54879592</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bind_return_functor</name>
      <anchorfile>structsigc_1_1bind__return__functor.html</anchorfile>
      <anchor>a1fa9551283794b249cbbdf7d270745d4</anchor>
      <arglist>(type_trait_take_t&lt; T_functor &gt; _A_functor, type_trait_take_t&lt; T_return &gt; _A_ret_value)</arglist>
    </member>
    <member kind="function">
      <type>unwrap_reference&lt; T_return &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1bind__return__functor.html</anchorfile>
      <anchor>a35959a6f4d5f6ddc83f603ee67d25981</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>unwrap_reference&lt; T_return &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1bind__return__functor.html</anchorfile>
      <anchor>aae3168e0ccd37c1c88c40ba52211cd3f</anchor>
      <arglist>(T_arg1 _A_a1)</arglist>
    </member>
    <member kind="function">
      <type>unwrap_reference&lt; T_return &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1bind__return__functor.html</anchorfile>
      <anchor>a2b7455271418f9f9099b4028cc44e438</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2)</arglist>
    </member>
    <member kind="function">
      <type>unwrap_reference&lt; T_return &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1bind__return__functor.html</anchorfile>
      <anchor>a93578ada371996698c2ee90b770dba33</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3)</arglist>
    </member>
    <member kind="function">
      <type>unwrap_reference&lt; T_return &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1bind__return__functor.html</anchorfile>
      <anchor>a83232aa7c8467a03d4bfa6b23431f08b</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4)</arglist>
    </member>
    <member kind="function">
      <type>unwrap_reference&lt; T_return &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1bind__return__functor.html</anchorfile>
      <anchor>afc057eb6b5c1546c2b462256ad4b09ea</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5)</arglist>
    </member>
    <member kind="function">
      <type>unwrap_reference&lt; T_return &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1bind__return__functor.html</anchorfile>
      <anchor>a69b4cb0e08adc771ecadce0ad7ab31c5</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5, T_arg6 _A_a6)</arglist>
    </member>
    <member kind="function">
      <type>unwrap_reference&lt; T_return &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1bind__return__functor.html</anchorfile>
      <anchor>ad21cdad5a90834f92edadfa70d6cb096</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5, T_arg6 _A_a6, T_arg7 _A_a7)</arglist>
    </member>
    <member kind="variable">
      <type>bound_argument&lt; T_return &gt;</type>
      <name>ret_value_</name>
      <anchorfile>structsigc_1_1bind__return__functor.html</anchorfile>
      <anchor>aa7b8287c19d98cec75a7e64a9464772e</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_argument</name>
    <filename>classsigc_1_1bound__argument.html</filename>
    <templarg>class T_type</templarg>
    <member kind="function">
      <type></type>
      <name>bound_argument</name>
      <anchorfile>classsigc_1_1bound__argument.html</anchorfile>
      <anchor>a495bb69a41b38eda5d6ace5a36807a37</anchor>
      <arglist>(const T_type &amp;_A_argument)</arglist>
    </member>
    <member kind="function">
      <type>T_type &amp;</type>
      <name>invoke</name>
      <anchorfile>classsigc_1_1bound__argument.html</anchorfile>
      <anchor>ac93dac5a6002282edbf974a9410daa27</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const T_type &amp;</type>
      <name>visit</name>
      <anchorfile>classsigc_1_1bound__argument.html</anchorfile>
      <anchor>a491f33af00692443cf41c8344493a8c3</anchor>
      <arglist>() const</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_argument&lt; const_reference_wrapper&lt; T_wrapped &gt; &gt;</name>
    <filename>classsigc_1_1bound__argument_3_01const__reference__wrapper_3_01T__wrapped_01_4_01_4.html</filename>
    <templarg>class T_wrapped</templarg>
    <member kind="function">
      <type></type>
      <name>bound_argument</name>
      <anchorfile>classsigc_1_1bound__argument_3_01const__reference__wrapper_3_01T__wrapped_01_4_01_4.html</anchorfile>
      <anchor>afdfab4386d34bd03e82b05a2eb1f2afe</anchor>
      <arglist>(const const_reference_wrapper&lt; T_wrapped &gt; &amp;_A_argument)</arglist>
    </member>
    <member kind="function">
      <type>const T_wrapped &amp;</type>
      <name>invoke</name>
      <anchorfile>classsigc_1_1bound__argument_3_01const__reference__wrapper_3_01T__wrapped_01_4_01_4.html</anchorfile>
      <anchor>a09d0a1773732e2f6de8181af50720a13</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const const_limit_reference&lt; T_wrapped &gt; &amp;</type>
      <name>visit</name>
      <anchorfile>classsigc_1_1bound__argument_3_01const__reference__wrapper_3_01T__wrapped_01_4_01_4.html</anchorfile>
      <anchor>a610980ceb5cc4847154caabd73aab2ec</anchor>
      <arglist>() const</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_argument&lt; reference_wrapper&lt; T_wrapped &gt; &gt;</name>
    <filename>classsigc_1_1bound__argument_3_01reference__wrapper_3_01T__wrapped_01_4_01_4.html</filename>
    <templarg>class T_wrapped</templarg>
    <member kind="function">
      <type></type>
      <name>bound_argument</name>
      <anchorfile>classsigc_1_1bound__argument_3_01reference__wrapper_3_01T__wrapped_01_4_01_4.html</anchorfile>
      <anchor>a46f705d774a2436055785b7a55830349</anchor>
      <arglist>(const reference_wrapper&lt; T_wrapped &gt; &amp;_A_argument)</arglist>
    </member>
    <member kind="function">
      <type>T_wrapped &amp;</type>
      <name>invoke</name>
      <anchorfile>classsigc_1_1bound__argument_3_01reference__wrapper_3_01T__wrapped_01_4_01_4.html</anchorfile>
      <anchor>ab280012899a94dd9db0ed9d59921f331</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const limit_reference&lt; T_wrapped &gt; &amp;</type>
      <name>visit</name>
      <anchorfile>classsigc_1_1bound__argument_3_01reference__wrapper_3_01T__wrapped_01_4_01_4.html</anchorfile>
      <anchor>ad74ff62bcd83684701285a13da125417</anchor>
      <arglist>() const</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_argument&lt; std::reference_wrapper&lt; T_wrapped &gt; &gt;</name>
    <filename>classsigc_1_1bound__argument_3_01std_1_1reference__wrapper_3_01T__wrapped_01_4_01_4.html</filename>
    <templarg>class T_wrapped</templarg>
    <member kind="function">
      <type></type>
      <name>bound_argument</name>
      <anchorfile>classsigc_1_1bound__argument_3_01std_1_1reference__wrapper_3_01T__wrapped_01_4_01_4.html</anchorfile>
      <anchor>a597709183c9a0b753f4674aaab80b4ff</anchor>
      <arglist>(const std::reference_wrapper&lt; T_wrapped &gt; &amp;_A_argument)</arglist>
    </member>
    <member kind="function">
      <type>T_wrapped &amp;</type>
      <name>invoke</name>
      <anchorfile>classsigc_1_1bound__argument_3_01std_1_1reference__wrapper_3_01T__wrapped_01_4_01_4.html</anchorfile>
      <anchor>ab3b9e2490dbc57d897d386a9932664c0</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const limit_reference&lt; T_wrapped &gt; &amp;</type>
      <name>visit</name>
      <anchorfile>classsigc_1_1bound__argument_3_01std_1_1reference__wrapper_3_01T__wrapped_01_4_01_4.html</anchorfile>
      <anchor>a4bf76f6edbfe02c4b8623f19b84b33eb</anchor>
      <arglist>() const</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_const_mem_functor0</name>
    <filename>classsigc_1_1bound__const__mem__functor0.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <base>sigc::const_mem_functor0</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor0.html</anchorfile>
      <anchor>a12ae83ad7820bd716ed8a07484a339d9</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_mem_functor0</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor0.html</anchorfile>
      <anchor>a44aeae8d1432f66fce9cd385094b78fa</anchor>
      <arglist>(const T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_mem_functor0</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor0.html</anchorfile>
      <anchor>a67756fc7a32eb42309a1d55aea2eeb19</anchor>
      <arglist>(const T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor0.html</anchorfile>
      <anchor>a7949abb2e0a675ab7faccf4b0c2b5480</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="variable">
      <type>const_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor0.html</anchorfile>
      <anchor>afe36947825350dc17d7fed286f57c32a</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_const_mem_functor1</name>
    <filename>classsigc_1_1bound__const__mem__functor1.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <base>sigc::const_mem_functor1</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor1.html</anchorfile>
      <anchor>a65f0cde178bdd7a26fe687a8748dac4e</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_mem_functor1</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor1.html</anchorfile>
      <anchor>af62c239e5612df1b7c4c91a52a2e0c62</anchor>
      <arglist>(const T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_mem_functor1</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor1.html</anchorfile>
      <anchor>aca80f40c27a3346521ffee81ba79da77</anchor>
      <arglist>(const T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor1.html</anchorfile>
      <anchor>a4ba51a05a053caf20d9306efb0f05791</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1) const</arglist>
    </member>
    <member kind="variable">
      <type>const_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor1.html</anchorfile>
      <anchor>ac4141561bf43206a396d082dd0089fb2</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_const_mem_functor2</name>
    <filename>classsigc_1_1bound__const__mem__functor2.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <base>sigc::const_mem_functor2</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor2.html</anchorfile>
      <anchor>abe2916ee9b6867554b48370000eb6886</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_mem_functor2</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor2.html</anchorfile>
      <anchor>ab5213783f248b53b357ea6385b7bbe7a</anchor>
      <arglist>(const T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_mem_functor2</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor2.html</anchorfile>
      <anchor>a6732b8f5b308ff8ff1adea9e3734f4bf</anchor>
      <arglist>(const T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor2.html</anchorfile>
      <anchor>a00df32df2a5bafc0adb39da243ad3a3d</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2) const</arglist>
    </member>
    <member kind="variable">
      <type>const_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor2.html</anchorfile>
      <anchor>a3994b65f2ec0b45f5b502f07bf7baca1</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_const_mem_functor3</name>
    <filename>classsigc_1_1bound__const__mem__functor3.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <base>sigc::const_mem_functor3</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor3.html</anchorfile>
      <anchor>ab4e793d8c65bf8754aea133a2473dc6c</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_mem_functor3</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor3.html</anchorfile>
      <anchor>a7fa6101b1b387baac23a7861e2819ad9</anchor>
      <arglist>(const T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_mem_functor3</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor3.html</anchorfile>
      <anchor>ae63bd158d8ce2571038d4f6382a7bc51</anchor>
      <arglist>(const T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor3.html</anchorfile>
      <anchor>aabad5390e5b2671de1b9fbba7bf1cda6</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3) const</arglist>
    </member>
    <member kind="variable">
      <type>const_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor3.html</anchorfile>
      <anchor>ac4b0ceb88bda73c90d84b1320e274621</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_const_mem_functor4</name>
    <filename>classsigc_1_1bound__const__mem__functor4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <base>sigc::const_mem_functor4</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor4.html</anchorfile>
      <anchor>a3ffc5790ded15878ce2704072791c4e9</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_mem_functor4</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor4.html</anchorfile>
      <anchor>a06e43c95d6ace639ac169ff2d0083ebc</anchor>
      <arglist>(const T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_mem_functor4</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor4.html</anchorfile>
      <anchor>a1d441ea8caf2d2ff8cfca414f259b657</anchor>
      <arglist>(const T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor4.html</anchorfile>
      <anchor>a4db87f79d355f2ca4f5ff20d47c35ee3</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4) const</arglist>
    </member>
    <member kind="variable">
      <type>const_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor4.html</anchorfile>
      <anchor>a78490633e22357be6e0a0fcf124121b5</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_const_mem_functor5</name>
    <filename>classsigc_1_1bound__const__mem__functor5.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <base>sigc::const_mem_functor5</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor5.html</anchorfile>
      <anchor>a882a71b51f303ded9d1ce172b522692a</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_mem_functor5</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor5.html</anchorfile>
      <anchor>a3c8a1d1411eea1136fa273886688290d</anchor>
      <arglist>(const T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_mem_functor5</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor5.html</anchorfile>
      <anchor>a9e80ad7a6b586eb1d0cc0a4afc9ea1d4</anchor>
      <arglist>(const T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor5.html</anchorfile>
      <anchor>a89a861b0925989a0e845399443eee20a</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5) const</arglist>
    </member>
    <member kind="variable">
      <type>const_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor5.html</anchorfile>
      <anchor>a71f8b7b3a9971d58209c3008d5e32d79</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_const_mem_functor6</name>
    <filename>classsigc_1_1bound__const__mem__functor6.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <base>sigc::const_mem_functor6</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor6.html</anchorfile>
      <anchor>a9cd70f288cac9b8d7ee9695166f3d306</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_mem_functor6</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor6.html</anchorfile>
      <anchor>afa0adf0adf9cde73008982d2494f3d7e</anchor>
      <arglist>(const T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_mem_functor6</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor6.html</anchorfile>
      <anchor>a4c6a29813f84239bfc224e36d3ada58c</anchor>
      <arglist>(const T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor6.html</anchorfile>
      <anchor>a6bc7018118bbf55444f4d9250cf3ce65</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6) const</arglist>
    </member>
    <member kind="variable">
      <type>const_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor6.html</anchorfile>
      <anchor>a152f10d5c46eb9d7d582a6e4cb747baf</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_const_mem_functor7</name>
    <filename>classsigc_1_1bound__const__mem__functor7.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <templarg>class T_arg7</templarg>
    <base>sigc::const_mem_functor7</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor7.html</anchorfile>
      <anchor>ae95db1c3ce4d07122e39dde2c9c5af02</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_mem_functor7</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor7.html</anchorfile>
      <anchor>a22e365208dda5614599860d5794cb64f</anchor>
      <arglist>(const T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_mem_functor7</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor7.html</anchorfile>
      <anchor>a3353dd997ced3fc00f44ee2b8ccb0063</anchor>
      <arglist>(const T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor7.html</anchorfile>
      <anchor>a941b925ad1f628cde49bb268be8daf4a</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6, type_trait_take_t&lt; T_arg7 &gt; _A_a7) const</arglist>
    </member>
    <member kind="variable">
      <type>const_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__const__mem__functor7.html</anchorfile>
      <anchor>a2b59ccc18d96b4b2ec0f6828a5c2a6e0</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_const_volatile_mem_functor0</name>
    <filename>classsigc_1_1bound__const__volatile__mem__functor0.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <base>sigc::const_volatile_mem_functor0</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor0.html</anchorfile>
      <anchor>a622322ff2ef93f0e611fd6f93f6ccdcc</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_volatile_mem_functor0</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor0.html</anchorfile>
      <anchor>a12e99e7dc91602d1e7170a791f96a616</anchor>
      <arglist>(const T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_volatile_mem_functor0</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor0.html</anchorfile>
      <anchor>a364e1b19994e41acf1d99d27ffca8924</anchor>
      <arglist>(const T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor0.html</anchorfile>
      <anchor>abbe8bbaa0d3d7318046be146fe6fda03</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="variable">
      <type>const_volatile_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor0.html</anchorfile>
      <anchor>adfea0aeaf66e1531da58af3051327949</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_const_volatile_mem_functor1</name>
    <filename>classsigc_1_1bound__const__volatile__mem__functor1.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <base>sigc::const_volatile_mem_functor1</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor1.html</anchorfile>
      <anchor>ac7a0c09914219d8baf1715675e838e59</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_volatile_mem_functor1</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor1.html</anchorfile>
      <anchor>aaccca7de16e3da31976680b714d10e79</anchor>
      <arglist>(const T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_volatile_mem_functor1</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor1.html</anchorfile>
      <anchor>ac99241e0e7ba52e295f6176c03cdd741</anchor>
      <arglist>(const T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor1.html</anchorfile>
      <anchor>a0c520be9f25daa56ca9aba061edb7e77</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1) const</arglist>
    </member>
    <member kind="variable">
      <type>const_volatile_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor1.html</anchorfile>
      <anchor>a4c6537ee7b64251b8f418047cb9fd87d</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_const_volatile_mem_functor2</name>
    <filename>classsigc_1_1bound__const__volatile__mem__functor2.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <base>sigc::const_volatile_mem_functor2</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor2.html</anchorfile>
      <anchor>a26e4bc5d2c64c1029b760fe7994fee3f</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_volatile_mem_functor2</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor2.html</anchorfile>
      <anchor>a6a7a540b5e6a5e7d322a448904bc8881</anchor>
      <arglist>(const T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_volatile_mem_functor2</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor2.html</anchorfile>
      <anchor>a1b629cd2ff30fcaeb035136e190c3f4d</anchor>
      <arglist>(const T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor2.html</anchorfile>
      <anchor>a434acb850963a28b1a5a4662fad2b5d5</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2) const</arglist>
    </member>
    <member kind="variable">
      <type>const_volatile_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor2.html</anchorfile>
      <anchor>a28eef54f97c2468f3385358b75d6cb70</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_const_volatile_mem_functor3</name>
    <filename>classsigc_1_1bound__const__volatile__mem__functor3.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <base>sigc::const_volatile_mem_functor3</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor3.html</anchorfile>
      <anchor>ae127200c20b69f91ccaf40eb60f2c448</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_volatile_mem_functor3</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor3.html</anchorfile>
      <anchor>a3fbbc6533b408ccde3d517b1f2a38223</anchor>
      <arglist>(const T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_volatile_mem_functor3</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor3.html</anchorfile>
      <anchor>a7c5661cbb3554624e50c62789f339aaf</anchor>
      <arglist>(const T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor3.html</anchorfile>
      <anchor>af14d93c72657777d2257e3db60f20a01</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3) const</arglist>
    </member>
    <member kind="variable">
      <type>const_volatile_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor3.html</anchorfile>
      <anchor>a65b0c3f640389160aa73a299aed8c512</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_const_volatile_mem_functor4</name>
    <filename>classsigc_1_1bound__const__volatile__mem__functor4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <base>sigc::const_volatile_mem_functor4</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor4.html</anchorfile>
      <anchor>a2c06c731ae9564be215802a98541d06c</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_volatile_mem_functor4</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor4.html</anchorfile>
      <anchor>a4e0fdda617113a58f8839ab53a9fa613</anchor>
      <arglist>(const T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_volatile_mem_functor4</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor4.html</anchorfile>
      <anchor>a97b15b931ba6db1852011d252dd3d5f0</anchor>
      <arglist>(const T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor4.html</anchorfile>
      <anchor>ac1593becd15c2704535c9b50482503f9</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4) const</arglist>
    </member>
    <member kind="variable">
      <type>const_volatile_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor4.html</anchorfile>
      <anchor>a52abd6d1eb7dd0919ecb6d3a667b0e18</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_const_volatile_mem_functor5</name>
    <filename>classsigc_1_1bound__const__volatile__mem__functor5.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <base>sigc::const_volatile_mem_functor5</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor5.html</anchorfile>
      <anchor>a54debcbe3edf1a9606aad9cfcc1e004c</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_volatile_mem_functor5</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor5.html</anchorfile>
      <anchor>a178805b13affaa2b0fbaafe287cb9390</anchor>
      <arglist>(const T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_volatile_mem_functor5</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor5.html</anchorfile>
      <anchor>acc05a40bf47bd943c5d822b354a80ae9</anchor>
      <arglist>(const T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor5.html</anchorfile>
      <anchor>a7f70def3a438e6735b67f669c8fc107a</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5) const</arglist>
    </member>
    <member kind="variable">
      <type>const_volatile_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor5.html</anchorfile>
      <anchor>a72dab40d6161daa1ad1655a03e5a5aa4</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_const_volatile_mem_functor6</name>
    <filename>classsigc_1_1bound__const__volatile__mem__functor6.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <base>sigc::const_volatile_mem_functor6</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor6.html</anchorfile>
      <anchor>aa8d75053aa097f0632c13bf1185f84a9</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_volatile_mem_functor6</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor6.html</anchorfile>
      <anchor>ac5aa6dc8967fed463dd69f412ded1fd1</anchor>
      <arglist>(const T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_volatile_mem_functor6</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor6.html</anchorfile>
      <anchor>ae07e825b1d3ee4fa7d4dd45eb7f2fbad</anchor>
      <arglist>(const T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor6.html</anchorfile>
      <anchor>a9cd3a5dd70008fe70d17712cfee0f470</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6) const</arglist>
    </member>
    <member kind="variable">
      <type>const_volatile_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor6.html</anchorfile>
      <anchor>abbd560d8331fbab5cd8a08afd756c8fc</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_const_volatile_mem_functor7</name>
    <filename>classsigc_1_1bound__const__volatile__mem__functor7.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <templarg>class T_arg7</templarg>
    <base>sigc::const_volatile_mem_functor7</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor7.html</anchorfile>
      <anchor>a48030a47276e3eede338fc78c79e5a35</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_volatile_mem_functor7</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor7.html</anchorfile>
      <anchor>aed3adf188de8b282a4a597fb5e4a07bc</anchor>
      <arglist>(const T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_const_volatile_mem_functor7</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor7.html</anchorfile>
      <anchor>a6f2635a9548c06f2f5090d75df09fbf1</anchor>
      <arglist>(const T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor7.html</anchorfile>
      <anchor>a8fe1055d39082226d8acb3201b7b5ce7</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6, type_trait_take_t&lt; T_arg7 &gt; _A_a7) const</arglist>
    </member>
    <member kind="variable">
      <type>const_volatile_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__const__volatile__mem__functor7.html</anchorfile>
      <anchor>aec37eae62ba95f04b55dd6c55c6161c1</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_mem_functor0</name>
    <filename>classsigc_1_1bound__mem__functor0.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <base>sigc::mem_functor0</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__mem__functor0.html</anchorfile>
      <anchor>a36b5479bfc091c063d44b11ad024393a</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_mem_functor0</name>
      <anchorfile>classsigc_1_1bound__mem__functor0.html</anchorfile>
      <anchor>a137ab7d3b66b421f664e154e3d01e66c</anchor>
      <arglist>(T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_mem_functor0</name>
      <anchorfile>classsigc_1_1bound__mem__functor0.html</anchorfile>
      <anchor>a7de90a27f55055cae43df1425cc78415</anchor>
      <arglist>(T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__mem__functor0.html</anchorfile>
      <anchor>a8f0ea7caa1c5858b44ebdb0bcf4ba74a</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="variable">
      <type>limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__mem__functor0.html</anchorfile>
      <anchor>ae64f4c6596667228376947a38c4a8bb7</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_mem_functor1</name>
    <filename>classsigc_1_1bound__mem__functor1.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <base>sigc::mem_functor1</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__mem__functor1.html</anchorfile>
      <anchor>a8e460c2a0eb87dcaf263c984b4dc5888</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_mem_functor1</name>
      <anchorfile>classsigc_1_1bound__mem__functor1.html</anchorfile>
      <anchor>a777afe4673c9adc0798a38fc96bca7f6</anchor>
      <arglist>(T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_mem_functor1</name>
      <anchorfile>classsigc_1_1bound__mem__functor1.html</anchorfile>
      <anchor>ad13235c20a9171bd24a4f8ae36577448</anchor>
      <arglist>(T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__mem__functor1.html</anchorfile>
      <anchor>af9d43a802f122d38d264b3f662bcfe43</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1) const</arglist>
    </member>
    <member kind="variable">
      <type>limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__mem__functor1.html</anchorfile>
      <anchor>a95ae2c4525d8218569b68bbb3effbadf</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_mem_functor2</name>
    <filename>classsigc_1_1bound__mem__functor2.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <base>sigc::mem_functor2</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__mem__functor2.html</anchorfile>
      <anchor>a1b0b5d2145f50d19214ff41bd45ab978</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_mem_functor2</name>
      <anchorfile>classsigc_1_1bound__mem__functor2.html</anchorfile>
      <anchor>a830746b33cae370b756334e4a8cab703</anchor>
      <arglist>(T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_mem_functor2</name>
      <anchorfile>classsigc_1_1bound__mem__functor2.html</anchorfile>
      <anchor>a48bc9b34469749461813061d17680ca2</anchor>
      <arglist>(T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__mem__functor2.html</anchorfile>
      <anchor>a09d48d61cc092e3f12c8ac4df4449596</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2) const</arglist>
    </member>
    <member kind="variable">
      <type>limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__mem__functor2.html</anchorfile>
      <anchor>a423780eab9a560771ec3266ea0693117</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_mem_functor3</name>
    <filename>classsigc_1_1bound__mem__functor3.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <base>sigc::mem_functor3</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__mem__functor3.html</anchorfile>
      <anchor>a66d1aa7ad3edafd8851ee0b334f83efe</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_mem_functor3</name>
      <anchorfile>classsigc_1_1bound__mem__functor3.html</anchorfile>
      <anchor>a1d1dddd6a334864611f5dc3a8ece26f9</anchor>
      <arglist>(T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_mem_functor3</name>
      <anchorfile>classsigc_1_1bound__mem__functor3.html</anchorfile>
      <anchor>aadbbb586e3ba0c44a25c1f3834c4c438</anchor>
      <arglist>(T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__mem__functor3.html</anchorfile>
      <anchor>aa61ed1a1c920069032ffd5427d24a771</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3) const</arglist>
    </member>
    <member kind="variable">
      <type>limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__mem__functor3.html</anchorfile>
      <anchor>ae05cea0cbd3345abc624e545422bb47a</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_mem_functor4</name>
    <filename>classsigc_1_1bound__mem__functor4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <base>sigc::mem_functor4</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__mem__functor4.html</anchorfile>
      <anchor>aeddcfc0ce5fe38259608bfc88af37568</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_mem_functor4</name>
      <anchorfile>classsigc_1_1bound__mem__functor4.html</anchorfile>
      <anchor>ae15ccaa9f58865b2cd9929644aa85612</anchor>
      <arglist>(T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_mem_functor4</name>
      <anchorfile>classsigc_1_1bound__mem__functor4.html</anchorfile>
      <anchor>a15b592122574775dd2c4804617e1e3dd</anchor>
      <arglist>(T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__mem__functor4.html</anchorfile>
      <anchor>a0a9d2fb52ef15ae8d4e56238217c0539</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4) const</arglist>
    </member>
    <member kind="variable">
      <type>limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__mem__functor4.html</anchorfile>
      <anchor>aa9a90c28652fb499438e757cdc6f3be7</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_mem_functor5</name>
    <filename>classsigc_1_1bound__mem__functor5.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <base>sigc::mem_functor5</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__mem__functor5.html</anchorfile>
      <anchor>a91181f20bd393befce307655486949ad</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_mem_functor5</name>
      <anchorfile>classsigc_1_1bound__mem__functor5.html</anchorfile>
      <anchor>a179304173879dac0023d49e313125c8c</anchor>
      <arglist>(T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_mem_functor5</name>
      <anchorfile>classsigc_1_1bound__mem__functor5.html</anchorfile>
      <anchor>aaf05ba83268cf4a55f96db281898b406</anchor>
      <arglist>(T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__mem__functor5.html</anchorfile>
      <anchor>aa1de6366cd9e5f0ea037287438a8072f</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5) const</arglist>
    </member>
    <member kind="variable">
      <type>limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__mem__functor5.html</anchorfile>
      <anchor>a477578c56471258d6eaefb45713dbae8</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_mem_functor6</name>
    <filename>classsigc_1_1bound__mem__functor6.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <base>sigc::mem_functor6</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__mem__functor6.html</anchorfile>
      <anchor>ac92e6b87056623eeec0d09a35f41296d</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_mem_functor6</name>
      <anchorfile>classsigc_1_1bound__mem__functor6.html</anchorfile>
      <anchor>abff60fd63e92b1c28c2aacf1cee93508</anchor>
      <arglist>(T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_mem_functor6</name>
      <anchorfile>classsigc_1_1bound__mem__functor6.html</anchorfile>
      <anchor>ab2724a290ceef4f2c279156b606e8c88</anchor>
      <arglist>(T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__mem__functor6.html</anchorfile>
      <anchor>ad44376814c73959398026d4e0df3d401</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6) const</arglist>
    </member>
    <member kind="variable">
      <type>limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__mem__functor6.html</anchorfile>
      <anchor>a8aced07018e8f32dcc4339ce26a0e924</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_mem_functor7</name>
    <filename>classsigc_1_1bound__mem__functor7.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <templarg>class T_arg7</templarg>
    <base>sigc::mem_functor7</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__mem__functor7.html</anchorfile>
      <anchor>a0fcd4636185a806d055d6b885503863b</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_mem_functor7</name>
      <anchorfile>classsigc_1_1bound__mem__functor7.html</anchorfile>
      <anchor>a29f43e3ad8d4714c8f3477be02d62c3d</anchor>
      <arglist>(T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_mem_functor7</name>
      <anchorfile>classsigc_1_1bound__mem__functor7.html</anchorfile>
      <anchor>a989011ff72d908959d2f0ad346357706</anchor>
      <arglist>(T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__mem__functor7.html</anchorfile>
      <anchor>ab0c379b445a5655f55f8260c699e7053</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6, type_trait_take_t&lt; T_arg7 &gt; _A_a7) const</arglist>
    </member>
    <member kind="variable">
      <type>limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__mem__functor7.html</anchorfile>
      <anchor>a03e799b2af9cdc19c76e81d0bcb843ad</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_volatile_mem_functor0</name>
    <filename>classsigc_1_1bound__volatile__mem__functor0.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <base>sigc::volatile_mem_functor0</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor0.html</anchorfile>
      <anchor>a9a07aa91b2bd5ef0c4fc1a89bad5d3b0</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_volatile_mem_functor0</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor0.html</anchorfile>
      <anchor>a4f81dd585b0aae830cd585ebb5867e20</anchor>
      <arglist>(T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_volatile_mem_functor0</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor0.html</anchorfile>
      <anchor>a5812d3638dc20b9fe37688d31dde8ed8</anchor>
      <arglist>(T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor0.html</anchorfile>
      <anchor>a5726bcc0d34cff2356976bc586d36b44</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="variable">
      <type>volatile_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor0.html</anchorfile>
      <anchor>abc4357df8d4458326135e23965ba5871</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_volatile_mem_functor1</name>
    <filename>classsigc_1_1bound__volatile__mem__functor1.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <base>sigc::volatile_mem_functor1</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor1.html</anchorfile>
      <anchor>a38ee12aba5c1d6a7c608165a1137219a</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_volatile_mem_functor1</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor1.html</anchorfile>
      <anchor>ae51c0fe21853f42cd9890f5f995f4d87</anchor>
      <arglist>(T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_volatile_mem_functor1</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor1.html</anchorfile>
      <anchor>af0b1a108c0080fe202b1d77cae86a7d0</anchor>
      <arglist>(T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor1.html</anchorfile>
      <anchor>a989556175b19d8e13c34727f231228ad</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1) const</arglist>
    </member>
    <member kind="variable">
      <type>volatile_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor1.html</anchorfile>
      <anchor>a09b9ac461833030fae01249b50e5984c</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_volatile_mem_functor2</name>
    <filename>classsigc_1_1bound__volatile__mem__functor2.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <base>sigc::volatile_mem_functor2</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor2.html</anchorfile>
      <anchor>a16d5240b9bbb31ae266725d20b0f37d7</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_volatile_mem_functor2</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor2.html</anchorfile>
      <anchor>ac3a72dc9eb316e9f096cb0a93792e368</anchor>
      <arglist>(T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_volatile_mem_functor2</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor2.html</anchorfile>
      <anchor>af2222c46ab0b47bd59af92ad509ef6fb</anchor>
      <arglist>(T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor2.html</anchorfile>
      <anchor>a5a93614f492dacd37dd1cfd94cc033b3</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2) const</arglist>
    </member>
    <member kind="variable">
      <type>volatile_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor2.html</anchorfile>
      <anchor>a80858a8bbb89469136b8e476d0bae0e6</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_volatile_mem_functor3</name>
    <filename>classsigc_1_1bound__volatile__mem__functor3.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <base>sigc::volatile_mem_functor3</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor3.html</anchorfile>
      <anchor>abc967931a7ab1411e02c022035073be5</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_volatile_mem_functor3</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor3.html</anchorfile>
      <anchor>a1f2aacad170885008a58975c8562a863</anchor>
      <arglist>(T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_volatile_mem_functor3</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor3.html</anchorfile>
      <anchor>a21c0be5f093ddcd084cc5ad172ceaf92</anchor>
      <arglist>(T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor3.html</anchorfile>
      <anchor>af5b4934a8e75fd7c32d41a989ec67f66</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3) const</arglist>
    </member>
    <member kind="variable">
      <type>volatile_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor3.html</anchorfile>
      <anchor>a01d01f9945bd93e227403cdbb8271e2a</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_volatile_mem_functor4</name>
    <filename>classsigc_1_1bound__volatile__mem__functor4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <base>sigc::volatile_mem_functor4</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor4.html</anchorfile>
      <anchor>a7a30b6a2e3067254fdea50104fea8469</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_volatile_mem_functor4</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor4.html</anchorfile>
      <anchor>a7264500594318b92a0a668fcfbbeffbc</anchor>
      <arglist>(T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_volatile_mem_functor4</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor4.html</anchorfile>
      <anchor>ae2385ee536e72cfbb0d945ba770f2e69</anchor>
      <arglist>(T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor4.html</anchorfile>
      <anchor>a22702ad82b54c77d93fb6d0481896d8f</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4) const</arglist>
    </member>
    <member kind="variable">
      <type>volatile_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor4.html</anchorfile>
      <anchor>a4bb276cfe8c35645f166cde087f5d17f</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_volatile_mem_functor5</name>
    <filename>classsigc_1_1bound__volatile__mem__functor5.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <base>sigc::volatile_mem_functor5</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor5.html</anchorfile>
      <anchor>a1561f499bd4d950fd36ee43ee60db585</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_volatile_mem_functor5</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor5.html</anchorfile>
      <anchor>a01734765e6a89bd0ab89063f130541e3</anchor>
      <arglist>(T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_volatile_mem_functor5</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor5.html</anchorfile>
      <anchor>af5e4db24b5ba51d92746aa3fee080d49</anchor>
      <arglist>(T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor5.html</anchorfile>
      <anchor>aaf0765f195ee2efef0536dfb854af9e4</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5) const</arglist>
    </member>
    <member kind="variable">
      <type>volatile_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor5.html</anchorfile>
      <anchor>ae17c42b74b72c74f3a7e4d5faadaa761</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_volatile_mem_functor6</name>
    <filename>classsigc_1_1bound__volatile__mem__functor6.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <base>sigc::volatile_mem_functor6</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor6.html</anchorfile>
      <anchor>a6eeca5f695bff3c3302e4cf7d222a73d</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_volatile_mem_functor6</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor6.html</anchorfile>
      <anchor>af79be68e9cb6c772f6d6e817bffe9656</anchor>
      <arglist>(T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_volatile_mem_functor6</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor6.html</anchorfile>
      <anchor>acb8a7befd300496343cf46d8520db04f</anchor>
      <arglist>(T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor6.html</anchorfile>
      <anchor>aa8aa3006bba7344c630f6f8adb3507d5</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6) const</arglist>
    </member>
    <member kind="variable">
      <type>volatile_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor6.html</anchorfile>
      <anchor>a64c4455bc351be0f2b42dc28b03baeb9</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::bound_volatile_mem_functor7</name>
    <filename>classsigc_1_1bound__volatile__mem__functor7.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <templarg>class T_arg7</templarg>
    <base>sigc::volatile_mem_functor7</base>
    <member kind="typedef">
      <type>base_type_::function_type</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor7.html</anchorfile>
      <anchor>afce6246f9f2828a7185b3c696435d70a</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_volatile_mem_functor7</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor7.html</anchorfile>
      <anchor>a3109683023c9e82a586660399b12769e</anchor>
      <arglist>(T_obj &amp;_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>bound_volatile_mem_functor7</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor7.html</anchorfile>
      <anchor>a18f28191685aa86228328e7016b5c803</anchor>
      <arglist>(T_obj *_A_obj, function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor7.html</anchorfile>
      <anchor>ad1ab1d5cf45600c5369a0a119a5a89ad</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6, type_trait_take_t&lt; T_arg7 &gt; _A_a7) const</arglist>
    </member>
    <member kind="variable">
      <type>volatile_limit_reference&lt; T_obj &gt;</type>
      <name>obj_</name>
      <anchorfile>classsigc_1_1bound__volatile__mem__functor7.html</anchorfile>
      <anchor>a32b6c9b9aaa1e750217fc1f9d9e4b2df</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::can_deduce_result_type_with_decltype</name>
    <filename>classsigc_1_1can__deduce__result__type__with__decltype.html</filename>
    <templarg>typename T_functor</templarg>
    <member kind="variable" static="yes">
      <type>static const bool</type>
      <name>value</name>
      <anchorfile>classsigc_1_1can__deduce__result__type__with__decltype.html</anchorfile>
      <anchor>a3e390d22fe03a03bb34bb38bca1aea91</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::compose1_functor</name>
    <filename>structsigc_1_1compose1__functor.html</filename>
    <templarg>class T_setter</templarg>
    <templarg>class T_getter</templarg>
    <base>adapts&lt; T_setter &gt;</base>
    <member kind="typedef">
      <type>adapts&lt; T_setter &gt;::adaptor_type</type>
      <name>adaptor_type</name>
      <anchorfile>structsigc_1_1compose1__functor.html</anchorfile>
      <anchor>a90d506f177dca8afeaef61b6b5956541</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_getter</type>
      <name>getter_type</name>
      <anchorfile>structsigc_1_1compose1__functor.html</anchorfile>
      <anchor>ad54c2d62658fb7a47da41df0ccfc618c</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>adaptor_type::result_type</type>
      <name>result_type</name>
      <anchorfile>structsigc_1_1compose1__functor.html</anchorfile>
      <anchor>ab096c0a388f877d97b3812f2fcc813f9</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_setter</type>
      <name>setter_type</name>
      <anchorfile>structsigc_1_1compose1__functor.html</anchorfile>
      <anchor>a86a8bc8f4926f7bb91ef362fff03a25e</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>compose1_functor</name>
      <anchorfile>structsigc_1_1compose1__functor.html</anchorfile>
      <anchor>a1bb831ebfb46a214a6ffda98e77ad044</anchor>
      <arglist>(const T_setter &amp;_A_setter, const T_getter &amp;_A_getter)</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1compose1__functor.html</anchorfile>
      <anchor>ae7c074e7656595157b0f421028e34609</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1compose1__functor.html</anchorfile>
      <anchor>a97c7b10789a2c24b28e93dbec285f3b6</anchor>
      <arglist>(T_arg1 _A_a1)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1compose1__functor.html</anchorfile>
      <anchor>a0ec27fdf66e733c8c07a94a4b0bcff38</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1compose1__functor.html</anchorfile>
      <anchor>a7b53bd647e4ef9ad343f4f9c21ce8541</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1compose1__functor.html</anchorfile>
      <anchor>ab25380b0441b33b9649883b818d863de</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1compose1__functor.html</anchorfile>
      <anchor>a92d4806089ccb056f1fed60ad306dad0</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1compose1__functor.html</anchorfile>
      <anchor>ac570ce504b2f79fd61a758016aed8a0d</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5, T_arg6 _A_a6)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1compose1__functor.html</anchorfile>
      <anchor>af31ffcd71de7b556770927351dab76c1</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5, T_arg6 _A_a6, T_arg7 _A_a7)</arglist>
    </member>
    <member kind="variable">
      <type>getter_type</type>
      <name>get_</name>
      <anchorfile>structsigc_1_1compose1__functor.html</anchorfile>
      <anchor>abc9151caeb78b1cd79ce1eb6984dc066</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::compose2_functor</name>
    <filename>structsigc_1_1compose2__functor.html</filename>
    <templarg>class T_setter</templarg>
    <templarg>class T_getter1</templarg>
    <templarg>class T_getter2</templarg>
    <base>adapts&lt; T_setter &gt;</base>
    <member kind="typedef">
      <type>adapts&lt; T_setter &gt;::adaptor_type</type>
      <name>adaptor_type</name>
      <anchorfile>structsigc_1_1compose2__functor.html</anchorfile>
      <anchor>ac1c9b3dc43cc75ec65fe0708fb4450d8</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_getter1</type>
      <name>getter1_type</name>
      <anchorfile>structsigc_1_1compose2__functor.html</anchorfile>
      <anchor>ab7ab82eee45e8df9116a5a2b7c12c39c</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_getter2</type>
      <name>getter2_type</name>
      <anchorfile>structsigc_1_1compose2__functor.html</anchorfile>
      <anchor>a75e252684d06f75f036043df56d8df69</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>adaptor_type::result_type</type>
      <name>result_type</name>
      <anchorfile>structsigc_1_1compose2__functor.html</anchorfile>
      <anchor>a78ccb07f23696a452df9f61308885542</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_setter</type>
      <name>setter_type</name>
      <anchorfile>structsigc_1_1compose2__functor.html</anchorfile>
      <anchor>ac3d7308c702df7378af1635281d5f7b8</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>compose2_functor</name>
      <anchorfile>structsigc_1_1compose2__functor.html</anchorfile>
      <anchor>a72719db97ab3ffdc0176ea3b443ffb60</anchor>
      <arglist>(const T_setter &amp;_A_setter, const T_getter1 &amp;_A_getter1, const T_getter2 &amp;_A_getter2)</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1compose2__functor.html</anchorfile>
      <anchor>a3cfcfa7d8d95962b3448ed886f3495a0</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1compose2__functor.html</anchorfile>
      <anchor>a6631f8b8a2a697af7edbec359a7914e9</anchor>
      <arglist>(T_arg1 _A_a1)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1compose2__functor.html</anchorfile>
      <anchor>a3857ee1d1ee9161d5f59ba863f17f146</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1compose2__functor.html</anchorfile>
      <anchor>a75d619764ae5ebbd23918054e8497100</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1compose2__functor.html</anchorfile>
      <anchor>abe24ed5b104bd43f89730e9ea5d4c957</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1compose2__functor.html</anchorfile>
      <anchor>ae420a3a87f48d8c7469fd668190a9444</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1compose2__functor.html</anchorfile>
      <anchor>a5fc415aad83af2df842f96c45ad3d4bb</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5, T_arg6 _A_a6)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1compose2__functor.html</anchorfile>
      <anchor>a4a3a9cd597a3c734ec78c393584d3ba5</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5, T_arg6 _A_a6, T_arg7 _A_a7)</arglist>
    </member>
    <member kind="variable">
      <type>getter1_type</type>
      <name>get1_</name>
      <anchorfile>structsigc_1_1compose2__functor.html</anchorfile>
      <anchor>af5404ffb509175690aa896932571e8bf</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>getter2_type</type>
      <name>get2_</name>
      <anchorfile>structsigc_1_1compose2__functor.html</anchorfile>
      <anchor>af8404295ebbcb968a798c9fdf3f3d527</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::connection</name>
    <filename>structsigc_1_1connection.html</filename>
    <member kind="function">
      <type></type>
      <name>connection</name>
      <anchorfile>structsigc_1_1connection.html</anchorfile>
      <anchor>a95f80dbbf10fde0b851d78ec12cc2629</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>connection</name>
      <anchorfile>structsigc_1_1connection.html</anchorfile>
      <anchor>ad13d5e3331cc9b1494e0edb8fa37fdba</anchor>
      <arglist>(const connection &amp;c)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>connection</name>
      <anchorfile>structsigc_1_1connection.html</anchorfile>
      <anchor>ac8847ae94e0b05bed6c81f54f58deef3</anchor>
      <arglist>(const slot_iterator&lt; T_slot &gt; &amp;it)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>connection</name>
      <anchorfile>structsigc_1_1connection.html</anchorfile>
      <anchor>a124709de26781e5ffcf8bbb5dcd621ed</anchor>
      <arglist>(slot_base &amp;sl)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~connection</name>
      <anchorfile>structsigc_1_1connection.html</anchorfile>
      <anchor>a99678ccb2be5c20719f37e469416578a</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>bool</type>
      <name>block</name>
      <anchorfile>structsigc_1_1connection.html</anchorfile>
      <anchor>a581ae4f2b708cb6be7b081557864d6ec</anchor>
      <arglist>(bool should_block=true) noexcept</arglist>
    </member>
    <member kind="function">
      <type>bool</type>
      <name>blocked</name>
      <anchorfile>structsigc_1_1connection.html</anchorfile>
      <anchor>a7c86964aa4b0f339db5842e6c7e604f3</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>bool</type>
      <name>connected</name>
      <anchorfile>structsigc_1_1connection.html</anchorfile>
      <anchor>a307b5df56439539be66f92d6e39f0bce</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>disconnect</name>
      <anchorfile>structsigc_1_1connection.html</anchorfile>
      <anchor>a0452bd182a61650d14a9664d6297ed1b</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>bool</type>
      <name>empty</name>
      <anchorfile>structsigc_1_1connection.html</anchorfile>
      <anchor>a810bdde9fbe7ad10bf9d578eebf929de</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>operator bool</name>
      <anchorfile>structsigc_1_1connection.html</anchorfile>
      <anchor>a93215e1ea86c5fd0a465b2c4dba1257e</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="function">
      <type>connection &amp;</type>
      <name>operator=</name>
      <anchorfile>structsigc_1_1connection.html</anchorfile>
      <anchor>a2e441da37feabf189c85b54f0b4b9bbb</anchor>
      <arglist>(const connection &amp;c)</arglist>
    </member>
    <member kind="function">
      <type>connection &amp;</type>
      <name>operator=</name>
      <anchorfile>structsigc_1_1connection.html</anchorfile>
      <anchor>a1ef02d3e8cf6b1e45d460bcd2eacae52</anchor>
      <arglist>(const slot_iterator&lt; T_slot &gt; &amp;it)</arglist>
    </member>
    <member kind="function">
      <type>bool</type>
      <name>unblock</name>
      <anchorfile>structsigc_1_1connection.html</anchorfile>
      <anchor>a15abcbfa76f1e5d8601cf4ad4176ed50</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void *</type>
      <name>notify</name>
      <anchorfile>structsigc_1_1connection.html</anchorfile>
      <anchor>a8d9b11e96bbf7d1e98bcf3171b57155e</anchor>
      <arglist>(void *data)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::const_limit_reference</name>
    <filename>classsigc_1_1const__limit__reference.html</filename>
    <templarg>class T_type</templarg>
    <templarg>bool I_derives_trackable</templarg>
    <member kind="function">
      <type></type>
      <name>const_limit_reference</name>
      <anchorfile>classsigc_1_1const__limit__reference.html</anchorfile>
      <anchor>acee8a4c09720730cd5f66696fd018b4c</anchor>
      <arglist>(const T_type &amp;_A_target)</arglist>
    </member>
    <member kind="function">
      <type>const T_type &amp;</type>
      <name>invoke</name>
      <anchorfile>classsigc_1_1const__limit__reference.html</anchorfile>
      <anchor>aa63de63299fb63f312f2021635aeabd9</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>const T_type &amp;</type>
      <name>visit</name>
      <anchorfile>classsigc_1_1const__limit__reference.html</anchorfile>
      <anchor>aa454c123c8264e46b3786a255bd2dc1f</anchor>
      <arglist>() const</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::const_limit_reference&lt; T_type, true &gt;</name>
    <filename>classsigc_1_1const__limit__reference_3_01T__type_00_01true_01_4.html</filename>
    <templarg>class T_type</templarg>
    <member kind="function">
      <type></type>
      <name>const_limit_reference</name>
      <anchorfile>classsigc_1_1const__limit__reference_3_01T__type_00_01true_01_4.html</anchorfile>
      <anchor>a68f1337800c19036c81512e76e0dd6cd</anchor>
      <arglist>(const T_type &amp;_A_target)</arglist>
    </member>
    <member kind="function">
      <type>const T_type &amp;</type>
      <name>invoke</name>
      <anchorfile>classsigc_1_1const__limit__reference_3_01T__type_00_01true_01_4.html</anchorfile>
      <anchor>ac24de401081716c54c4240c72ff8b465</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>const trackable &amp;</type>
      <name>visit</name>
      <anchorfile>classsigc_1_1const__limit__reference_3_01T__type_00_01true_01_4.html</anchorfile>
      <anchor>a5db5d89f3f742fc39a7756370762e672</anchor>
      <arglist>() const</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::const_mem_functor0</name>
    <filename>classsigc_1_1const__mem__functor0.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1const__mem__functor0.html</anchorfile>
      <anchor>a5b768319ee81e2aa9e96a900e5e64996</anchor>
      <arglist>)() const</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1const__mem__functor0.html</anchorfile>
      <anchor>a553cd4d85524b5deea445b67773527bf</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_mem_functor0</name>
      <anchorfile>classsigc_1_1const__mem__functor0.html</anchorfile>
      <anchor>a49bba4c8045b8b6933b8f5a854ac98d6</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_mem_functor0</name>
      <anchorfile>classsigc_1_1const__mem__functor0.html</anchorfile>
      <anchor>a27895e58972642453f7b853f25a66f42</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__mem__functor0.html</anchorfile>
      <anchor>ac388853f99f074e549c8784d1a38f46b</anchor>
      <arglist>(const T_obj &amp;_A_obj) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__mem__functor0.html</anchorfile>
      <anchor>abcc08c39943577648dac107692e5b34a</anchor>
      <arglist>(const T_obj *_A_obj) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1const__mem__functor0.html</anchorfile>
      <anchor>a215359b20450c2afe93496826ac45c1d</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::const_mem_functor1</name>
    <filename>classsigc_1_1const__mem__functor1.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1const__mem__functor1.html</anchorfile>
      <anchor>a14e585a05b63c5e4790b3de75cb18c96</anchor>
      <arglist>)(T_arg1) const</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1const__mem__functor1.html</anchorfile>
      <anchor>a8ba6a6565b8a29812e266aa4e5261a2d</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_mem_functor1</name>
      <anchorfile>classsigc_1_1const__mem__functor1.html</anchorfile>
      <anchor>a2c171737e0c7dc6ae00f73f1580a976d</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_mem_functor1</name>
      <anchorfile>classsigc_1_1const__mem__functor1.html</anchorfile>
      <anchor>aba30421222bd496f9dec9b733fe70447</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__mem__functor1.html</anchorfile>
      <anchor>a3a575262ae2d62c39c52280017956a95</anchor>
      <arglist>(const T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__mem__functor1.html</anchorfile>
      <anchor>a9e549ccae24d5a7d1741f17c09db7d5f</anchor>
      <arglist>(const T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1const__mem__functor1.html</anchorfile>
      <anchor>af791174008d5b58aa0f4fb42a531cc4a</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::const_mem_functor2</name>
    <filename>classsigc_1_1const__mem__functor2.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1const__mem__functor2.html</anchorfile>
      <anchor>a2294d014482fee6845b69ab5bc27daa9</anchor>
      <arglist>)(T_arg1, T_arg2) const</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1const__mem__functor2.html</anchorfile>
      <anchor>a5eaa5f2ab10ad755c89ff5b09c1e281d</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_mem_functor2</name>
      <anchorfile>classsigc_1_1const__mem__functor2.html</anchorfile>
      <anchor>a6265bdc51f35d8d5274bfeb8cdafc1dc</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_mem_functor2</name>
      <anchorfile>classsigc_1_1const__mem__functor2.html</anchorfile>
      <anchor>ab281b110d1fbba86e2d58f9607d0f0c3</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__mem__functor2.html</anchorfile>
      <anchor>aafbf14880952214525553f4b419bf5c6</anchor>
      <arglist>(const T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__mem__functor2.html</anchorfile>
      <anchor>a51c12b33270c350c8988194cb29df590</anchor>
      <arglist>(const T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1const__mem__functor2.html</anchorfile>
      <anchor>a4445ff55323e94d525c1b2574ee32ddc</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::const_mem_functor3</name>
    <filename>classsigc_1_1const__mem__functor3.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1const__mem__functor3.html</anchorfile>
      <anchor>accd266c72527ca411756bd9a4045eac9</anchor>
      <arglist>)(T_arg1, T_arg2, T_arg3) const</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1const__mem__functor3.html</anchorfile>
      <anchor>ae67fd219e64f81359640873d30123c9d</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_mem_functor3</name>
      <anchorfile>classsigc_1_1const__mem__functor3.html</anchorfile>
      <anchor>a9921cf28137404e029e3f5d7c291021d</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_mem_functor3</name>
      <anchorfile>classsigc_1_1const__mem__functor3.html</anchorfile>
      <anchor>ae70cb6e5e322ef3f3a9673b1e541d2c1</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__mem__functor3.html</anchorfile>
      <anchor>aa123c4fb39116ca1a28896cfd029b1de</anchor>
      <arglist>(const T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__mem__functor3.html</anchorfile>
      <anchor>a6322fdc9cc492d4f3a2c8482e193540f</anchor>
      <arglist>(const T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1const__mem__functor3.html</anchorfile>
      <anchor>ad86eb326f14c401748d0a118265e558d</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::const_mem_functor4</name>
    <filename>classsigc_1_1const__mem__functor4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1const__mem__functor4.html</anchorfile>
      <anchor>a775bb61661f2a7007b36f16ee106a8ad</anchor>
      <arglist>)(T_arg1, T_arg2, T_arg3, T_arg4) const</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1const__mem__functor4.html</anchorfile>
      <anchor>a78069750e64446199d91c0682b0915cc</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_mem_functor4</name>
      <anchorfile>classsigc_1_1const__mem__functor4.html</anchorfile>
      <anchor>acdde68d1638c13cd29157d1cb1bd42d2</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_mem_functor4</name>
      <anchorfile>classsigc_1_1const__mem__functor4.html</anchorfile>
      <anchor>a7e09703c6320542cb5f0075d371908a8</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__mem__functor4.html</anchorfile>
      <anchor>a25b73f70e0cb8771a6fc8dd1ad521795</anchor>
      <arglist>(const T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__mem__functor4.html</anchorfile>
      <anchor>a5b178876ca9fbec1fa2339819939a9e7</anchor>
      <arglist>(const T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1const__mem__functor4.html</anchorfile>
      <anchor>ac0feeedacde97bd166141c285fa2c74c</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::const_mem_functor5</name>
    <filename>classsigc_1_1const__mem__functor5.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1const__mem__functor5.html</anchorfile>
      <anchor>aa58310b256b11e94d9a757acf60b410a</anchor>
      <arglist>)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5) const</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1const__mem__functor5.html</anchorfile>
      <anchor>a9d952d52dade789bc38953c4c83fb425</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_mem_functor5</name>
      <anchorfile>classsigc_1_1const__mem__functor5.html</anchorfile>
      <anchor>a818da40f7c82d6a1fde3009d32bf3920</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_mem_functor5</name>
      <anchorfile>classsigc_1_1const__mem__functor5.html</anchorfile>
      <anchor>a47769ef46d8ff779df8c152acdc0d74c</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__mem__functor5.html</anchorfile>
      <anchor>aaceffe6505aed22dd5af369231914965</anchor>
      <arglist>(const T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__mem__functor5.html</anchorfile>
      <anchor>ae710c03998c58cb8f90ce75a46fab69c</anchor>
      <arglist>(const T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1const__mem__functor5.html</anchorfile>
      <anchor>aeb6e66e0304e5c039d97264a3dd7d6e9</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::const_mem_functor6</name>
    <filename>classsigc_1_1const__mem__functor6.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1const__mem__functor6.html</anchorfile>
      <anchor>ad64803b1192e1007887f234b8c7421ac</anchor>
      <arglist>)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6) const</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1const__mem__functor6.html</anchorfile>
      <anchor>adf81aebfa633d0bf14a0d3f5e9688561</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_mem_functor6</name>
      <anchorfile>classsigc_1_1const__mem__functor6.html</anchorfile>
      <anchor>a7a5e8a3a981a615a545aab358efa9472</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_mem_functor6</name>
      <anchorfile>classsigc_1_1const__mem__functor6.html</anchorfile>
      <anchor>a0803b89f79b60c16d87c0372be261211</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__mem__functor6.html</anchorfile>
      <anchor>a8657b806cb2eeb7e43f0a09f6556c514</anchor>
      <arglist>(const T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__mem__functor6.html</anchorfile>
      <anchor>a023fd4cb845234b50c5dee1f4147cde9</anchor>
      <arglist>(const T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1const__mem__functor6.html</anchorfile>
      <anchor>a665c77c3da00d474d6d999c394801a98</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::const_mem_functor7</name>
    <filename>classsigc_1_1const__mem__functor7.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <templarg>class T_arg7</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1const__mem__functor7.html</anchorfile>
      <anchor>a73af81d23d0fa816b8ef00acb1970d43</anchor>
      <arglist>)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7) const</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1const__mem__functor7.html</anchorfile>
      <anchor>a724b8b210493e0d3cf06b5a393b91546</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_mem_functor7</name>
      <anchorfile>classsigc_1_1const__mem__functor7.html</anchorfile>
      <anchor>add4d7f74905c6bc20afc6f7681f367c0</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_mem_functor7</name>
      <anchorfile>classsigc_1_1const__mem__functor7.html</anchorfile>
      <anchor>a0538bba01694fc13456fcee0e96d8f34</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__mem__functor7.html</anchorfile>
      <anchor>ab49dc9f302ef22e4b76043d9bc2f5062</anchor>
      <arglist>(const T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6, type_trait_take_t&lt; T_arg7 &gt; _A_a7) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__mem__functor7.html</anchorfile>
      <anchor>a53f19248e5b61460759d7cdbf41ca21b</anchor>
      <arglist>(const T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6, type_trait_take_t&lt; T_arg7 &gt; _A_a7) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1const__mem__functor7.html</anchorfile>
      <anchor>a255588607e165db8bd25c3bb8d7e1fbe</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::const_reference_wrapper</name>
    <filename>structsigc_1_1const__reference__wrapper.html</filename>
    <templarg>class T_type</templarg>
    <member kind="function">
      <type></type>
      <name>const_reference_wrapper</name>
      <anchorfile>structsigc_1_1const__reference__wrapper.html</anchorfile>
      <anchor>a249ae888fb9be126598d81ce339fbf81</anchor>
      <arglist>(const T_type &amp;v)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>operator const T_type &amp;</name>
      <anchorfile>structsigc_1_1const__reference__wrapper.html</anchorfile>
      <anchor>a2cf7a981855668dfb69e98cfaa6eb779</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="variable">
      <type>const T_type &amp;</type>
      <name>value_</name>
      <anchorfile>structsigc_1_1const__reference__wrapper.html</anchorfile>
      <anchor>aaaba3da60073e485144be648f8c4f69f</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::const_volatile_limit_reference</name>
    <filename>classsigc_1_1const__volatile__limit__reference.html</filename>
    <templarg>class T_type</templarg>
    <templarg>bool I_derives_trackable</templarg>
    <member kind="function">
      <type></type>
      <name>const_volatile_limit_reference</name>
      <anchorfile>classsigc_1_1const__volatile__limit__reference.html</anchorfile>
      <anchor>a9a01809bae79cb1b13ee50ce9d84dcb8</anchor>
      <arglist>(const T_type &amp;_A_target)</arglist>
    </member>
    <member kind="function">
      <type>const volatile T_type &amp;</type>
      <name>invoke</name>
      <anchorfile>classsigc_1_1const__volatile__limit__reference.html</anchorfile>
      <anchor>a616fabd3ed8fffe7ce9d60cdd5f08160</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>const T_type &amp;</type>
      <name>visit</name>
      <anchorfile>classsigc_1_1const__volatile__limit__reference.html</anchorfile>
      <anchor>aeb3469454f4ff675f5d35d8a821c81fb</anchor>
      <arglist>() const</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::const_volatile_limit_reference&lt; T_type, true &gt;</name>
    <filename>classsigc_1_1const__volatile__limit__reference_3_01T__type_00_01true_01_4.html</filename>
    <templarg>class T_type</templarg>
    <member kind="function">
      <type></type>
      <name>const_volatile_limit_reference</name>
      <anchorfile>classsigc_1_1const__volatile__limit__reference_3_01T__type_00_01true_01_4.html</anchorfile>
      <anchor>a94bf04779d798bd2737c521d20655122</anchor>
      <arglist>(const T_type &amp;_A_target)</arglist>
    </member>
    <member kind="function">
      <type>const volatile T_type &amp;</type>
      <name>invoke</name>
      <anchorfile>classsigc_1_1const__volatile__limit__reference_3_01T__type_00_01true_01_4.html</anchorfile>
      <anchor>a9292e115901b0e7f7e603f95be589aca</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>const trackable &amp;</type>
      <name>visit</name>
      <anchorfile>classsigc_1_1const__volatile__limit__reference_3_01T__type_00_01true_01_4.html</anchorfile>
      <anchor>af8dbc1310e5eec3e1d97d1c5369b7c26</anchor>
      <arglist>() const</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::const_volatile_mem_functor0</name>
    <filename>classsigc_1_1const__volatile__mem__functor0.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor0.html</anchorfile>
      <anchor>a3247f7d0e3804ff455e0996b969f6c59</anchor>
      <arglist>)() const volatile</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor0.html</anchorfile>
      <anchor>ab8e419ef5ad21d6230a306cd7d910df9</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_volatile_mem_functor0</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor0.html</anchorfile>
      <anchor>a8eec4c4ff04b8d5ef7c184e853ea0486</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_volatile_mem_functor0</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor0.html</anchorfile>
      <anchor>ab20dd00a6c8908a8ebd7846985d71856</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor0.html</anchorfile>
      <anchor>adfd64d64707c012329915edf19190772</anchor>
      <arglist>(const T_obj &amp;_A_obj) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor0.html</anchorfile>
      <anchor>a86005d47b02e980c90d135a636e21674</anchor>
      <arglist>(const T_obj *_A_obj) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor0.html</anchorfile>
      <anchor>ae0f88c6683fb175845f5f804c2c04ec8</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::const_volatile_mem_functor1</name>
    <filename>classsigc_1_1const__volatile__mem__functor1.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor1.html</anchorfile>
      <anchor>acc367f8d6ee646c370623650a7ed6cde</anchor>
      <arglist>)(T_arg1) const volatile</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor1.html</anchorfile>
      <anchor>adeaf82cc2aff607efe2a51945d6b8565</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_volatile_mem_functor1</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor1.html</anchorfile>
      <anchor>a25a541c4bef874a6b2d177a3be7ab988</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_volatile_mem_functor1</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor1.html</anchorfile>
      <anchor>aa8cb4ad934ac610ffe3425cbe799ba8d</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor1.html</anchorfile>
      <anchor>a715b1d5c56a537cbd397875e8eba532d</anchor>
      <arglist>(const T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor1.html</anchorfile>
      <anchor>a9af06968e1db65f5bd136175e10d250f</anchor>
      <arglist>(const T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor1.html</anchorfile>
      <anchor>af9da27522999030f09c718dbe164f1f6</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::const_volatile_mem_functor2</name>
    <filename>classsigc_1_1const__volatile__mem__functor2.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor2.html</anchorfile>
      <anchor>ac46d1e343e669092d6bb24aa8b5d5dbb</anchor>
      <arglist>)(T_arg1, T_arg2) const volatile</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor2.html</anchorfile>
      <anchor>a0d143bb32627f7a0c17270321df8145f</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_volatile_mem_functor2</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor2.html</anchorfile>
      <anchor>ad99060cf675fb65cbc00f2b8e9ec3068</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_volatile_mem_functor2</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor2.html</anchorfile>
      <anchor>ada3da9a8dd692377c90abbfa9bcfe73a</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor2.html</anchorfile>
      <anchor>a467a45cf9bc54bed0f3c5bade3329067</anchor>
      <arglist>(const T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor2.html</anchorfile>
      <anchor>a9d024cf10df876df77183e1fb79a52ec</anchor>
      <arglist>(const T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor2.html</anchorfile>
      <anchor>aac7f64e6cff784ecd6700d0448d8e796</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::const_volatile_mem_functor3</name>
    <filename>classsigc_1_1const__volatile__mem__functor3.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor3.html</anchorfile>
      <anchor>a472ab7835e2b6792a108f4fcc80d4669</anchor>
      <arglist>)(T_arg1, T_arg2, T_arg3) const volatile</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor3.html</anchorfile>
      <anchor>ad2056f73eed4664ff41f5e673a2276f0</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_volatile_mem_functor3</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor3.html</anchorfile>
      <anchor>af284f300a6b3696f6379dcc9ed97a744</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_volatile_mem_functor3</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor3.html</anchorfile>
      <anchor>aa586f24064b6a5c8b69c963fff614d04</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor3.html</anchorfile>
      <anchor>a4af918f707067763bb2031d8758991d5</anchor>
      <arglist>(const T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor3.html</anchorfile>
      <anchor>a47374a80a3a61b69e39478ca9a4a4776</anchor>
      <arglist>(const T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor3.html</anchorfile>
      <anchor>a6ffedac451ab4f525bd7c9df0b83cf2c</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::const_volatile_mem_functor4</name>
    <filename>classsigc_1_1const__volatile__mem__functor4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor4.html</anchorfile>
      <anchor>ace3cb54e6265ebe06ee2995dd01f2540</anchor>
      <arglist>)(T_arg1, T_arg2, T_arg3, T_arg4) const volatile</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor4.html</anchorfile>
      <anchor>a8e38a0816627c7ad4fd48278d287f863</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_volatile_mem_functor4</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor4.html</anchorfile>
      <anchor>aad7b7f5037a0c8d13668f9c350e010ee</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_volatile_mem_functor4</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor4.html</anchorfile>
      <anchor>a0ffe59d6392c736e6d14c43a4bfa26e5</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor4.html</anchorfile>
      <anchor>a7cd0900e7e3c8523503e037e7c696f5d</anchor>
      <arglist>(const T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor4.html</anchorfile>
      <anchor>a589c68eddffeb3399838d2af7f5b6d19</anchor>
      <arglist>(const T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor4.html</anchorfile>
      <anchor>a0714aabc799c5d41af988650fec71410</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::const_volatile_mem_functor5</name>
    <filename>classsigc_1_1const__volatile__mem__functor5.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor5.html</anchorfile>
      <anchor>a1d49a5a7086d41d1db2e40aed1273631</anchor>
      <arglist>)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5) const volatile</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor5.html</anchorfile>
      <anchor>a42d6cd140b98358c1d12c90b975ad2b1</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_volatile_mem_functor5</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor5.html</anchorfile>
      <anchor>afe48307086c70740f39f58488a3cbdb5</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_volatile_mem_functor5</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor5.html</anchorfile>
      <anchor>a13787a099e237b44280ddbe9b8d97a04</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor5.html</anchorfile>
      <anchor>a8d74b334440d1c9add3a358cd1913b11</anchor>
      <arglist>(const T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor5.html</anchorfile>
      <anchor>a7b1fde7647e7e936b29c97797835ca7b</anchor>
      <arglist>(const T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor5.html</anchorfile>
      <anchor>a785d079f14f42cafd052639a1ebdaeb9</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::const_volatile_mem_functor6</name>
    <filename>classsigc_1_1const__volatile__mem__functor6.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor6.html</anchorfile>
      <anchor>af8da04ac5f6e2252f963f4f4bb87c9fd</anchor>
      <arglist>)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6) const volatile</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor6.html</anchorfile>
      <anchor>a9f866db08b59a0960875f7608a0c93f0</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_volatile_mem_functor6</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor6.html</anchorfile>
      <anchor>aa921f2d1cea8ddd987cdaa8df6479fab</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_volatile_mem_functor6</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor6.html</anchorfile>
      <anchor>a09704c72e9b0353b04776522edefd57e</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor6.html</anchorfile>
      <anchor>a5cf522fd8072a8f77e56cae87d65892f</anchor>
      <arglist>(const T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor6.html</anchorfile>
      <anchor>adff33012b1d7a20cb39c41c19b1db9a5</anchor>
      <arglist>(const T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor6.html</anchorfile>
      <anchor>aed412f2606f91f9c11567c37ae6175bc</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::const_volatile_mem_functor7</name>
    <filename>classsigc_1_1const__volatile__mem__functor7.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <templarg>class T_arg7</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor7.html</anchorfile>
      <anchor>a7e3bac9b817c848b96e9d1b257be1de5</anchor>
      <arglist>)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7) const volatile</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor7.html</anchorfile>
      <anchor>a25cb7e6ed71406c5b91ab2696ad8e623</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_volatile_mem_functor7</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor7.html</anchorfile>
      <anchor>ac71290a7277b022f8a8d7abc4158a7ae</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>const_volatile_mem_functor7</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor7.html</anchorfile>
      <anchor>a95dcac66fbdb4c3b92682a1ddaa0309c</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor7.html</anchorfile>
      <anchor>a9cb200c4d7a95edf269ede2b9c7ab060</anchor>
      <arglist>(const T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6, type_trait_take_t&lt; T_arg7 &gt; _A_a7) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor7.html</anchorfile>
      <anchor>a1c9477eed5eef826a4666817aee9ea25</anchor>
      <arglist>(const T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6, type_trait_take_t&lt; T_arg7 &gt; _A_a7) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1const__volatile__mem__functor7.html</anchorfile>
      <anchor>a3f19b8bff74776f040492d3410c54fa1</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::deduce_result_type</name>
    <filename>structsigc_1_1deduce__result__type.html</filename>
    <templarg>class T_functor</templarg>
    <templarg>class... T_args</templarg>
    <member kind="typedef">
      <type>decltype(test&lt; T_functor &gt;())</type>
      <name>type</name>
      <anchorfile>structsigc_1_1deduce__result__type.html</anchorfile>
      <anchor>a529a6b7809ea3ad1a2d4392b9ffcec42</anchor>
      <arglist></arglist>
    </member>
    <member kind="function" static="yes">
      <type>static U_functor::template deduce_result_type&lt; T_args... &gt;::type</type>
      <name>test</name>
      <anchorfile>structsigc_1_1deduce__result__type.html</anchorfile>
      <anchor>a24243a95add007382a7666a2d1e383cf</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static functor_trait&lt; T_functor &gt;::result_type</type>
      <name>test</name>
      <anchorfile>structsigc_1_1deduce__result__type.html</anchorfile>
      <anchor>ad12108d87a486eb12fd7afd1ca29dd44</anchor>
      <arglist>()</arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::exception_catch_functor</name>
    <filename>structsigc_1_1exception__catch__functor.html</filename>
    <templarg>class T_functor</templarg>
    <templarg>class T_catcher</templarg>
    <templarg>class T_return</templarg>
    <base>sigc::adapts</base>
    <member kind="typedef">
      <type>adapts&lt; T_functor &gt;::adaptor_type</type>
      <name>adaptor_type</name>
      <anchorfile>structsigc_1_1exception__catch__functor.html</anchorfile>
      <anchor>a5dc4ecab205c7ad5c3954c2572d4cc08</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>structsigc_1_1exception__catch__functor.html</anchorfile>
      <anchor>a498f5575ae283594cfe03288fab54fdf</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>exception_catch_functor</name>
      <anchorfile>structsigc_1_1exception__catch__functor.html</anchorfile>
      <anchor>acefeea54e1d83cb64844a956598918fd</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_catcher &amp;_A_catcher)</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1exception__catch__functor.html</anchorfile>
      <anchor>a9f6b5068be1af2623e2aef727f2b73db</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1exception__catch__functor.html</anchorfile>
      <anchor>a133cc2a6fa2b6ed5dddc9d493f81e912</anchor>
      <arglist>(T_arg1 _A_a1)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1exception__catch__functor.html</anchorfile>
      <anchor>abaf6e14400dbc9e985f93092e33bd7cf</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1exception__catch__functor.html</anchorfile>
      <anchor>ab2303f8a947f123aa41e1734139e8d65</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1exception__catch__functor.html</anchorfile>
      <anchor>a770072d18f3daea43e827d5b9ed36c44</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1exception__catch__functor.html</anchorfile>
      <anchor>ad095c1190e681238864ab853c5abafc2</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1exception__catch__functor.html</anchorfile>
      <anchor>a14c2fef8d1cd324f7b62a41980efa381</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5, T_arg6 _A_a6)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1exception__catch__functor.html</anchorfile>
      <anchor>a5c5d829d33668c79da127e472f253f4c</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5, T_arg6 _A_a6, T_arg7 _A_a7)</arglist>
    </member>
    <member kind="variable">
      <type>T_catcher</type>
      <name>catcher_</name>
      <anchorfile>structsigc_1_1exception__catch__functor.html</anchorfile>
      <anchor>af94123d76a61a13258893ed575a019b0</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::exception_catch_functor&lt; T_functor, T_catcher, void &gt;</name>
    <filename>structsigc_1_1exception__catch__functor_3_01T__functor_00_01T__catcher_00_01void_01_4.html</filename>
    <templarg>class T_functor</templarg>
    <templarg>class T_catcher</templarg>
    <base>sigc::adapts</base>
    <member kind="typedef">
      <type>adapts&lt; T_functor &gt;::adaptor_type</type>
      <name>adaptor_type</name>
      <anchorfile>structsigc_1_1exception__catch__functor_3_01T__functor_00_01T__catcher_00_01void_01_4.html</anchorfile>
      <anchor>aa9803c7bd355ae0674dbfabf346676c0</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>void</type>
      <name>result_type</name>
      <anchorfile>structsigc_1_1exception__catch__functor_3_01T__functor_00_01T__catcher_00_01void_01_4.html</anchorfile>
      <anchor>a06506e0d4da26682740b7f4f9aec80d5</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>exception_catch_functor</name>
      <anchorfile>structsigc_1_1exception__catch__functor_3_01T__functor_00_01T__catcher_00_01void_01_4.html</anchorfile>
      <anchor>a84b167dc0dd520253776c55eb711c461</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>exception_catch_functor</name>
      <anchorfile>structsigc_1_1exception__catch__functor_3_01T__functor_00_01T__catcher_00_01void_01_4.html</anchorfile>
      <anchor>a08a5ce7a94a0646e92c5eb8fb6b7d5f3</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_catcher &amp;_A_catcher)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~exception_catch_functor</name>
      <anchorfile>structsigc_1_1exception__catch__functor_3_01T__functor_00_01T__catcher_00_01void_01_4.html</anchorfile>
      <anchor>a1537e7d0175046d65522bd960149bb62</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1exception__catch__functor_3_01T__functor_00_01T__catcher_00_01void_01_4.html</anchorfile>
      <anchor>a24e842daf8e8d756e2b77ceb47c55c14</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1exception__catch__functor_3_01T__functor_00_01T__catcher_00_01void_01_4.html</anchorfile>
      <anchor>a82a612391a897fc19a1446aeeef6565a</anchor>
      <arglist>(T_arg1 _A_a1)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1exception__catch__functor_3_01T__functor_00_01T__catcher_00_01void_01_4.html</anchorfile>
      <anchor>a06b40f68b2e6cdd284e2b497eb74a939</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1exception__catch__functor_3_01T__functor_00_01T__catcher_00_01void_01_4.html</anchorfile>
      <anchor>a22b9f8e4875e2b72179e37a67638b9c3</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1exception__catch__functor_3_01T__functor_00_01T__catcher_00_01void_01_4.html</anchorfile>
      <anchor>af1d91f1e60a08f4e1acb11e2b20a5f88</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1exception__catch__functor_3_01T__functor_00_01T__catcher_00_01void_01_4.html</anchorfile>
      <anchor>a060d8b8f91a1dd1fb6c2aaf62044fa58</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1exception__catch__functor_3_01T__functor_00_01T__catcher_00_01void_01_4.html</anchorfile>
      <anchor>a5641f044d5d1e9e317ffa9f3975c8780</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5, T_arg6 _A_a6)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1exception__catch__functor_3_01T__functor_00_01T__catcher_00_01void_01_4.html</anchorfile>
      <anchor>afbb9c979fe6dbe18a5b803e724a94f69</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5, T_arg6 _A_a6, T_arg7 _A_a7)</arglist>
    </member>
    <member kind="variable">
      <type>T_catcher</type>
      <name>catcher_</name>
      <anchorfile>structsigc_1_1exception__catch__functor_3_01T__functor_00_01T__catcher_00_01void_01_4.html</anchorfile>
      <anchor>acc50467493545db2b55e638f7ac28c42</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::functor_base</name>
    <filename>structsigc_1_1functor__base.html</filename>
  </compound>
  <compound kind="struct">
    <name>sigc::functor_trait</name>
    <filename>structsigc_1_1functor__trait.html</filename>
    <templarg>class T_functor</templarg>
    <templarg>bool I_derives_functor_base</templarg>
    <templarg>bool I_can_use_decltype</templarg>
    <member kind="typedef">
      <type>T_functor</type>
      <name>functor_type</name>
      <anchorfile>structsigc_1_1functor__trait.html</anchorfile>
      <anchor>ac779b3d3d04e78d57b6b2ae4545b1667</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>void</type>
      <name>result_type</name>
      <anchorfile>structsigc_1_1functor__trait.html</anchorfile>
      <anchor>af1324bf0d3cec3d1f2e39e932b228d6d</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::hide_functor</name>
    <filename>structsigc_1_1hide__functor.html</filename>
    <templarg>int I_location</templarg>
    <templarg>class T_functor</templarg>
  </compound>
  <compound kind="struct">
    <name>sigc::hide_functor&lt; 0, T_functor &gt;</name>
    <filename>structsigc_1_1hide__functor_3_010_00_01T__functor_01_4.html</filename>
    <templarg>class T_functor</templarg>
    <base>sigc::adapts</base>
    <member kind="typedef">
      <type>adapts&lt; T_functor &gt;::adaptor_type</type>
      <name>adaptor_type</name>
      <anchorfile>structsigc_1_1hide__functor_3_010_00_01T__functor_01_4.html</anchorfile>
      <anchor>a33b1c4635aad21aac771627a9a9fe60f</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>adaptor_type::result_type</type>
      <name>result_type</name>
      <anchorfile>structsigc_1_1hide__functor_3_010_00_01T__functor_01_4.html</anchorfile>
      <anchor>af5b5ee49bb277471b5bc8e3769d0dcb7</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>hide_functor</name>
      <anchorfile>structsigc_1_1hide__functor_3_010_00_01T__functor_01_4.html</anchorfile>
      <anchor>a7d5504f337ab7a4b6f709219c9e98222</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1hide__functor_3_010_00_01T__functor_01_4.html</anchorfile>
      <anchor>a8067098094753b9c89aba8051fdb9493</anchor>
      <arglist>(T_arg1)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1hide__functor_3_010_00_01T__functor_01_4.html</anchorfile>
      <anchor>a70aa1639293d5c22dfc50f8b14d4660f</anchor>
      <arglist>(T_arg1, T_arg2 _A_a2)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1hide__functor_3_010_00_01T__functor_01_4.html</anchorfile>
      <anchor>ae8b3148af2b274007e7af18c71640056</anchor>
      <arglist>(T_arg1, T_arg2 _A_a2, T_arg3 _A_a3)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1hide__functor_3_010_00_01T__functor_01_4.html</anchorfile>
      <anchor>a594218b8c3881be4dde577c8bcea3ae6</anchor>
      <arglist>(T_arg1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1hide__functor_3_010_00_01T__functor_01_4.html</anchorfile>
      <anchor>aa1e4872dcb4e8f5e29b5a8c55989b61b</anchor>
      <arglist>(T_arg1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1hide__functor_3_010_00_01T__functor_01_4.html</anchorfile>
      <anchor>acc2eb3b914117aae4ee7023482a99e91</anchor>
      <arglist>(T_arg1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5, T_arg6 _A_a6)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1hide__functor_3_010_00_01T__functor_01_4.html</anchorfile>
      <anchor>a7a257aa9c41d5e5452056afbee47d5d1</anchor>
      <arglist>(T_arg1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5, T_arg6 _A_a6, T_arg7 _A_a7)</arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::hide_functor&lt;-1, T_functor &gt;</name>
    <filename>structsigc_1_1hide__functor_3-1_00_01T__functor_01_4.html</filename>
    <templarg>class T_functor</templarg>
    <base>sigc::adapts</base>
    <member kind="typedef">
      <type>adapts&lt; T_functor &gt;::adaptor_type</type>
      <name>adaptor_type</name>
      <anchorfile>structsigc_1_1hide__functor_3-1_00_01T__functor_01_4.html</anchorfile>
      <anchor>a1f2c49ddcd02a3b7f240f0d0e6f0eec5</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>adaptor_type::result_type</type>
      <name>result_type</name>
      <anchorfile>structsigc_1_1hide__functor_3-1_00_01T__functor_01_4.html</anchorfile>
      <anchor>a72ea0ce5ad7cf4f9e0e7b160d830c5a4</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>hide_functor</name>
      <anchorfile>structsigc_1_1hide__functor_3-1_00_01T__functor_01_4.html</anchorfile>
      <anchor>a4c8d774e447991a6a920b9f3fca63205</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1hide__functor_3-1_00_01T__functor_01_4.html</anchorfile>
      <anchor>a616e76cd26a118b2a186085ee7a75ddf</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5, T_arg6 _A_a6, T_arg7)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1hide__functor_3-1_00_01T__functor_01_4.html</anchorfile>
      <anchor>a6e19e5f44f4ce8c6b72ddd95cfed7b21</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5, T_arg6)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1hide__functor_3-1_00_01T__functor_01_4.html</anchorfile>
      <anchor>aa0c6045eb292a0e14b578062fec35aa3</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1hide__functor_3-1_00_01T__functor_01_4.html</anchorfile>
      <anchor>a320d72b80189920ded2090ac2385ae3f</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1hide__functor_3-1_00_01T__functor_01_4.html</anchorfile>
      <anchor>a3b5f3a5ac163ad05b5d25045152b22c9</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1hide__functor_3-1_00_01T__functor_01_4.html</anchorfile>
      <anchor>a3a96e4a4ae2696f17ca62c61689faf9e</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1hide__functor_3-1_00_01T__functor_01_4.html</anchorfile>
      <anchor>a859bf6d21d0c1a30c23d0baaa5bee894</anchor>
      <arglist>(T_arg1)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::limit_reference</name>
    <filename>classsigc_1_1limit__reference.html</filename>
    <templarg>class T_type</templarg>
    <templarg>bool I_derives_trackable</templarg>
    <member kind="function">
      <type></type>
      <name>limit_reference</name>
      <anchorfile>classsigc_1_1limit__reference.html</anchorfile>
      <anchor>a58bf17e1eaa63d86336c831fa885bc66</anchor>
      <arglist>(T_type &amp;_A_target)</arglist>
    </member>
    <member kind="function">
      <type>T_type &amp;</type>
      <name>invoke</name>
      <anchorfile>classsigc_1_1limit__reference.html</anchorfile>
      <anchor>abc32490b6778d62878654d459b9a2042</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>const T_type &amp;</type>
      <name>visit</name>
      <anchorfile>classsigc_1_1limit__reference.html</anchorfile>
      <anchor>ac7b2431f1d05191b4af4ca2735d297a1</anchor>
      <arglist>() const</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::limit_reference&lt; T_type, true &gt;</name>
    <filename>classsigc_1_1limit__reference_3_01T__type_00_01true_01_4.html</filename>
    <templarg>class T_type</templarg>
    <member kind="function">
      <type></type>
      <name>limit_reference</name>
      <anchorfile>classsigc_1_1limit__reference_3_01T__type_00_01true_01_4.html</anchorfile>
      <anchor>a26ef98ef1f11a4b5891d426e9722c2c8</anchor>
      <arglist>(T_type &amp;_A_target)</arglist>
    </member>
    <member kind="function">
      <type>T_type &amp;</type>
      <name>invoke</name>
      <anchorfile>classsigc_1_1limit__reference_3_01T__type_00_01true_01_4.html</anchorfile>
      <anchor>a09a78b73059d74420a0fc1784ee1e323</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>const trackable &amp;</type>
      <name>visit</name>
      <anchorfile>classsigc_1_1limit__reference_3_01T__type_00_01true_01_4.html</anchorfile>
      <anchor>a0c718830147ca51ff4f19dab99c8ed81</anchor>
      <arglist>() const</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::mem_functor0</name>
    <filename>classsigc_1_1mem__functor0.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1mem__functor0.html</anchorfile>
      <anchor>a2b54ee0f1d0b0ca4f25707c85a5d4bab</anchor>
      <arglist>)()</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1mem__functor0.html</anchorfile>
      <anchor>aa679f73c7b786540686c110628a71dde</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>mem_functor0</name>
      <anchorfile>classsigc_1_1mem__functor0.html</anchorfile>
      <anchor>ad598cd301fc54f3aa4da2b9e3c16bc81</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>mem_functor0</name>
      <anchorfile>classsigc_1_1mem__functor0.html</anchorfile>
      <anchor>a5655f48c6f36716dc15daf584f20d51c</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1mem__functor0.html</anchorfile>
      <anchor>a51d5213c9d41b51e3b8cca705bd801cc</anchor>
      <arglist>(T_obj &amp;_A_obj) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1mem__functor0.html</anchorfile>
      <anchor>a0a8b70a8f59ddbdc3f1a9892c634bf48</anchor>
      <arglist>(T_obj *_A_obj) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1mem__functor0.html</anchorfile>
      <anchor>a1f7b51d412900f55e155ecdd848fa283</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::mem_functor1</name>
    <filename>classsigc_1_1mem__functor1.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1mem__functor1.html</anchorfile>
      <anchor>a4f10314fc4d7811e126aa0d8dc9fea8c</anchor>
      <arglist>)(T_arg1)</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1mem__functor1.html</anchorfile>
      <anchor>a7c7ab28530e2f678eae87772253df709</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>mem_functor1</name>
      <anchorfile>classsigc_1_1mem__functor1.html</anchorfile>
      <anchor>ab97c2206275025d8d1e7665c12322eba</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>mem_functor1</name>
      <anchorfile>classsigc_1_1mem__functor1.html</anchorfile>
      <anchor>a63230b348e410f7d2f245df1f2af019a</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1mem__functor1.html</anchorfile>
      <anchor>a55a370a320def89e80aa37141c101c98</anchor>
      <arglist>(T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1mem__functor1.html</anchorfile>
      <anchor>a11fa461ba0bbddc9e5a7dd687e90591b</anchor>
      <arglist>(T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1mem__functor1.html</anchorfile>
      <anchor>af5981be86ea36d59e86234ef5cd2b5a4</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::mem_functor2</name>
    <filename>classsigc_1_1mem__functor2.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1mem__functor2.html</anchorfile>
      <anchor>aa584cfe15bb8dc5b2931d2bfd034c118</anchor>
      <arglist>)(T_arg1, T_arg2)</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1mem__functor2.html</anchorfile>
      <anchor>a9080e942d35d226ea6f9dda097342f07</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>mem_functor2</name>
      <anchorfile>classsigc_1_1mem__functor2.html</anchorfile>
      <anchor>a691e21d47b7a54b67605812f7e089299</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>mem_functor2</name>
      <anchorfile>classsigc_1_1mem__functor2.html</anchorfile>
      <anchor>aeee1c7f263f8d7e7b6fa9be0156878fe</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1mem__functor2.html</anchorfile>
      <anchor>a6fe02ecb626919c1149888b03fde552e</anchor>
      <arglist>(T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1mem__functor2.html</anchorfile>
      <anchor>ad5d0f74803537d1ed8b9678ac2da57d5</anchor>
      <arglist>(T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1mem__functor2.html</anchorfile>
      <anchor>aa4b00e1d6bb65c1c1791d314b5dcb4d6</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::mem_functor3</name>
    <filename>classsigc_1_1mem__functor3.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1mem__functor3.html</anchorfile>
      <anchor>a8da99a5dcfe5ae1cecd6ce93ab91b929</anchor>
      <arglist>)(T_arg1, T_arg2, T_arg3)</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1mem__functor3.html</anchorfile>
      <anchor>af620103fa36aa86fb539843f7f730e01</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>mem_functor3</name>
      <anchorfile>classsigc_1_1mem__functor3.html</anchorfile>
      <anchor>abc94be96c346537bca09c73a342f5ccd</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>mem_functor3</name>
      <anchorfile>classsigc_1_1mem__functor3.html</anchorfile>
      <anchor>af22e274e905262144832ca9683d8823f</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1mem__functor3.html</anchorfile>
      <anchor>a12319d24e245cf126c130de8202d91bf</anchor>
      <arglist>(T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1mem__functor3.html</anchorfile>
      <anchor>ae7496f451661d60b287d528a7cfcaf82</anchor>
      <arglist>(T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1mem__functor3.html</anchorfile>
      <anchor>ac7ed881bf6b6ef8c7ed418ad3bfc0ccc</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::mem_functor4</name>
    <filename>classsigc_1_1mem__functor4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1mem__functor4.html</anchorfile>
      <anchor>a9dcf1ef95187c2588ecf2abb089cc7c8</anchor>
      <arglist>)(T_arg1, T_arg2, T_arg3, T_arg4)</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1mem__functor4.html</anchorfile>
      <anchor>a79bf0a3c25dbe6eb07829ee55ce5d664</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>mem_functor4</name>
      <anchorfile>classsigc_1_1mem__functor4.html</anchorfile>
      <anchor>a9774f0ab47d023f5bccdb9960c4fcdee</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>mem_functor4</name>
      <anchorfile>classsigc_1_1mem__functor4.html</anchorfile>
      <anchor>a4f7841b2ccd26fac6c21bf04fc524e08</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1mem__functor4.html</anchorfile>
      <anchor>a37b49e119c9be15f15362fe44eadc6a2</anchor>
      <arglist>(T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1mem__functor4.html</anchorfile>
      <anchor>aef140dac7b4876793fac8a006aad0a62</anchor>
      <arglist>(T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1mem__functor4.html</anchorfile>
      <anchor>a28282d9285ca1a2075fd8041905a6302</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::mem_functor5</name>
    <filename>classsigc_1_1mem__functor5.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1mem__functor5.html</anchorfile>
      <anchor>a66e9bb0c9829b13af029ee2127b54eb5</anchor>
      <arglist>)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5)</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1mem__functor5.html</anchorfile>
      <anchor>a3e0587ce338328d42f44c4e5f79be6ed</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>mem_functor5</name>
      <anchorfile>classsigc_1_1mem__functor5.html</anchorfile>
      <anchor>a9048a4a2216e20f9f34380020f5b67ec</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>mem_functor5</name>
      <anchorfile>classsigc_1_1mem__functor5.html</anchorfile>
      <anchor>a01bdff47bf4aed8c52fdfd5520fdf3cf</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1mem__functor5.html</anchorfile>
      <anchor>af1ce121edd0248d104f95e239af683bd</anchor>
      <arglist>(T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1mem__functor5.html</anchorfile>
      <anchor>a7ad7a4d81470125047755dfa8509c6dc</anchor>
      <arglist>(T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1mem__functor5.html</anchorfile>
      <anchor>a73a58b713dccc6a48b0083063b0df719</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::mem_functor6</name>
    <filename>classsigc_1_1mem__functor6.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1mem__functor6.html</anchorfile>
      <anchor>a202287b72f6213f64a696b185fb90268</anchor>
      <arglist>)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6)</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1mem__functor6.html</anchorfile>
      <anchor>af80425ff57ca2115cba771c275f49e36</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>mem_functor6</name>
      <anchorfile>classsigc_1_1mem__functor6.html</anchorfile>
      <anchor>aaa43195f4b4e39c76c10478539d35172</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>mem_functor6</name>
      <anchorfile>classsigc_1_1mem__functor6.html</anchorfile>
      <anchor>aabc6bb723e0831e27a0a9131525d96bc</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1mem__functor6.html</anchorfile>
      <anchor>a4a322216c1783eb8ad7f63972b3a1164</anchor>
      <arglist>(T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1mem__functor6.html</anchorfile>
      <anchor>afc40dbe8ea11726018dfa7c1ca435f3d</anchor>
      <arglist>(T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1mem__functor6.html</anchorfile>
      <anchor>af07a44f7435cf15228903b0868fac956</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::mem_functor7</name>
    <filename>classsigc_1_1mem__functor7.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <templarg>class T_arg7</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1mem__functor7.html</anchorfile>
      <anchor>a408f0afec5b4c750ca8e1bdab0f8b535</anchor>
      <arglist>)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7)</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1mem__functor7.html</anchorfile>
      <anchor>a967b5f6572e988ea0833818b993745f9</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>mem_functor7</name>
      <anchorfile>classsigc_1_1mem__functor7.html</anchorfile>
      <anchor>afbb9b8ecaa25e0dd85c0f3d539f198b4</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>mem_functor7</name>
      <anchorfile>classsigc_1_1mem__functor7.html</anchorfile>
      <anchor>a79de1ccebb568e82b7f7a67ab85e4dc6</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1mem__functor7.html</anchorfile>
      <anchor>ad8e9031dc12742265d834a5529b1f00d</anchor>
      <arglist>(T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6, type_trait_take_t&lt; T_arg7 &gt; _A_a7) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1mem__functor7.html</anchorfile>
      <anchor>ab95293e358caf96b5dbf123f024eed8d</anchor>
      <arglist>(T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6, type_trait_take_t&lt; T_arg7 &gt; _A_a7) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1mem__functor7.html</anchorfile>
      <anchor>a779c41d697c3b80d08a06cbcc9a5ea25</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::nil</name>
    <filename>structsigc_1_1nil.html</filename>
  </compound>
  <compound kind="class">
    <name>sigc::pointer_functor0</name>
    <filename>classsigc_1_1pointer__functor0.html</filename>
    <templarg>class T_return</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1pointer__functor0.html</anchorfile>
      <anchor>af44316e53e33b4184ca151b6b11c70e5</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>pointer_functor0</name>
      <anchorfile>classsigc_1_1pointer__functor0.html</anchorfile>
      <anchor>afdb67f682e7b9190f646eed879dcfbe4</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>pointer_functor0</name>
      <anchorfile>classsigc_1_1pointer__functor0.html</anchorfile>
      <anchor>a9ae3efd5c13c738db815f619499004d7</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1pointer__functor0.html</anchorfile>
      <anchor>a56db821303c19ec3345679d80d6ef96e</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1pointer__functor0.html</anchorfile>
      <anchor>af998b64dac7b3c7eeb2e9a2856a4213e</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::pointer_functor1</name>
    <filename>classsigc_1_1pointer__functor1.html</filename>
    <templarg>class T_arg1</templarg>
    <templarg>class T_return</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1pointer__functor1.html</anchorfile>
      <anchor>a4080910d23a74b102a123838fa93e90b</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>pointer_functor1</name>
      <anchorfile>classsigc_1_1pointer__functor1.html</anchorfile>
      <anchor>a6ce467c0641f8e3e0d91f3b843b07c3f</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>pointer_functor1</name>
      <anchorfile>classsigc_1_1pointer__functor1.html</anchorfile>
      <anchor>a8ab0c5b707dc41a821c63769344db2cb</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1pointer__functor1.html</anchorfile>
      <anchor>a3c978e35c107326078f3e33afcdd1235</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1pointer__functor1.html</anchorfile>
      <anchor>a864ab55240be5287faf07c341ae9501e</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::pointer_functor2</name>
    <filename>classsigc_1_1pointer__functor2.html</filename>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_return</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1pointer__functor2.html</anchorfile>
      <anchor>a297b784eb0cea07b364c854e5dd5f864</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>pointer_functor2</name>
      <anchorfile>classsigc_1_1pointer__functor2.html</anchorfile>
      <anchor>a2977aa1d72f5f0fd6c778b60ad791b9c</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>pointer_functor2</name>
      <anchorfile>classsigc_1_1pointer__functor2.html</anchorfile>
      <anchor>a428226381ff7bda06044c8fa53d4e27e</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1pointer__functor2.html</anchorfile>
      <anchor>af3d1d778be1730e170c42c52511d6926</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1pointer__functor2.html</anchorfile>
      <anchor>a340680ba8ae5ea67eb0afe33d118c82b</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::pointer_functor3</name>
    <filename>classsigc_1_1pointer__functor3.html</filename>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_return</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1pointer__functor3.html</anchorfile>
      <anchor>a2a0ed29803c02cc62fcc6497f83f88bf</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>pointer_functor3</name>
      <anchorfile>classsigc_1_1pointer__functor3.html</anchorfile>
      <anchor>a1a4909d1444e4456a89eb5852933d1cc</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>pointer_functor3</name>
      <anchorfile>classsigc_1_1pointer__functor3.html</anchorfile>
      <anchor>aae48103ba1c48e192a04c9a1b81ae9dc</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1pointer__functor3.html</anchorfile>
      <anchor>adf560c1e583b2216bba4de3027e3a05e</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1pointer__functor3.html</anchorfile>
      <anchor>a1ac1e43f2515d64c0da4656cdfac1f44</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::pointer_functor4</name>
    <filename>classsigc_1_1pointer__functor4.html</filename>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_return</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1pointer__functor4.html</anchorfile>
      <anchor>a787f8ea1c15d7bfab7643081a408401c</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>pointer_functor4</name>
      <anchorfile>classsigc_1_1pointer__functor4.html</anchorfile>
      <anchor>ab8e3bf143e71c5ffe8f155ace0f895a8</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>pointer_functor4</name>
      <anchorfile>classsigc_1_1pointer__functor4.html</anchorfile>
      <anchor>a30eaeb5f9974bed73d7577b862c2e06b</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1pointer__functor4.html</anchorfile>
      <anchor>a42875d789a30fb04395dbef76d720989</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1pointer__functor4.html</anchorfile>
      <anchor>af7079533ac64ac9ba23eab99e5c54269</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::pointer_functor5</name>
    <filename>classsigc_1_1pointer__functor5.html</filename>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_return</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1pointer__functor5.html</anchorfile>
      <anchor>a00dcbec8a920ea784e3210743c77855b</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>pointer_functor5</name>
      <anchorfile>classsigc_1_1pointer__functor5.html</anchorfile>
      <anchor>aa86bb74ff5e188f8f6497b7e73621cdd</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>pointer_functor5</name>
      <anchorfile>classsigc_1_1pointer__functor5.html</anchorfile>
      <anchor>abf1e06db145e4554ec53964ca79171cf</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1pointer__functor5.html</anchorfile>
      <anchor>aa2f399d3f76e802670c8a08ede82c40c</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1pointer__functor5.html</anchorfile>
      <anchor>a1c97e4e7e8598e06802b07cb86b32466</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::pointer_functor6</name>
    <filename>classsigc_1_1pointer__functor6.html</filename>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <templarg>class T_return</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1pointer__functor6.html</anchorfile>
      <anchor>a9fd7af745ebad4d59f67e0f60fb395e0</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>pointer_functor6</name>
      <anchorfile>classsigc_1_1pointer__functor6.html</anchorfile>
      <anchor>a26551fa703a65a9a14190c7579a3b77d</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>pointer_functor6</name>
      <anchorfile>classsigc_1_1pointer__functor6.html</anchorfile>
      <anchor>ab56acb7713cf87d0b3094adc4ffe7a15</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1pointer__functor6.html</anchorfile>
      <anchor>ac35109048b7360e1436e2b4e3a53d1cf</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1pointer__functor6.html</anchorfile>
      <anchor>a69c965009b6c3b65106c731b20e60368</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::pointer_functor7</name>
    <filename>classsigc_1_1pointer__functor7.html</filename>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <templarg>class T_arg7</templarg>
    <templarg>class T_return</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1pointer__functor7.html</anchorfile>
      <anchor>a41613e64e2b96656b85aa9eefa35aa91</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>pointer_functor7</name>
      <anchorfile>classsigc_1_1pointer__functor7.html</anchorfile>
      <anchor>a1268abfa3437c0977517dd4cd0548080</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>pointer_functor7</name>
      <anchorfile>classsigc_1_1pointer__functor7.html</anchorfile>
      <anchor>a01a6793cd057cd94bba98db3b34a3e7c</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1pointer__functor7.html</anchorfile>
      <anchor>a564941861ee4b84b9b61a1f247f0cfa1</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6, type_trait_take_t&lt; T_arg7 &gt; _A_a7) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1pointer__functor7.html</anchorfile>
      <anchor>aa092fb6515cb3496529b253b1a57118b</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::reference_wrapper</name>
    <filename>structsigc_1_1reference__wrapper.html</filename>
    <templarg>class T_type</templarg>
    <member kind="function">
      <type></type>
      <name>reference_wrapper</name>
      <anchorfile>structsigc_1_1reference__wrapper.html</anchorfile>
      <anchor>a05dfcad06f2af395c5e2daa9600d455a</anchor>
      <arglist>(T_type &amp;v)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>operator T_type &amp;</name>
      <anchorfile>structsigc_1_1reference__wrapper.html</anchorfile>
      <anchor>ae0b2f512b6a2555b489ed9dd229efc1c</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="variable">
      <type>T_type &amp;</type>
      <name>value_</name>
      <anchorfile>structsigc_1_1reference__wrapper.html</anchorfile>
      <anchor>acf0463810eeadc10cc3dd2eab900145f</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::retype_functor</name>
    <filename>structsigc_1_1retype__functor.html</filename>
    <templarg>class T_functor</templarg>
    <templarg>class T_type1</templarg>
    <templarg>class T_type2</templarg>
    <templarg>class T_type3</templarg>
    <templarg>class T_type4</templarg>
    <templarg>class T_type5</templarg>
    <templarg>class T_type6</templarg>
    <templarg>class T_type7</templarg>
    <base>sigc::adapts</base>
    <member kind="typedef">
      <type>adapts&lt; T_functor &gt;::adaptor_type</type>
      <name>adaptor_type</name>
      <anchorfile>structsigc_1_1retype__functor.html</anchorfile>
      <anchor>ace4a0fc864a6417a7cb36adf011177e0</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>adapts&lt; T_functor &gt;::result_type</type>
      <name>result_type</name>
      <anchorfile>structsigc_1_1retype__functor.html</anchorfile>
      <anchor>a1a594553d0312ca12e1009d179af0dbe</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>retype_functor</name>
      <anchorfile>structsigc_1_1retype__functor.html</anchorfile>
      <anchor>a30f35ce3d25b7fd571fbd3ef730de225</anchor>
      <arglist>(type_trait_take_t&lt; T_functor &gt; _A_functor)</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__functor.html</anchorfile>
      <anchor>a841d7fd2ae795ca4decccca8342e231c</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__functor.html</anchorfile>
      <anchor>a8b2d4a735c23e205cbd5d521088edec7</anchor>
      <arglist>(T_arg1 _A_a1)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__functor.html</anchorfile>
      <anchor>a8687527b70905a9fcdbe756a0c3db183</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__functor.html</anchorfile>
      <anchor>a5087d8b4864c11394dc4ced4fc217cdd</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__functor.html</anchorfile>
      <anchor>a7f0891e8c8e0835c300b085d5efd65b0</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__functor.html</anchorfile>
      <anchor>add2bd05fe3b1c56fd479e71d8c6cac57</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__functor.html</anchorfile>
      <anchor>a3d24c16cca177f4fed4fcc6b6f5b7a6e</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5, T_arg6 _A_a6)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__functor.html</anchorfile>
      <anchor>ac6def31b008243bf0974884fe2304fed</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5, T_arg6 _A_a6, T_arg7 _A_a7)</arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::retype_return_functor</name>
    <filename>structsigc_1_1retype__return__functor.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_functor</templarg>
    <base>sigc::adapts</base>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>structsigc_1_1retype__return__functor.html</anchorfile>
      <anchor>aa8421dc266ad653de395e7d01e631fdc</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>retype_return_functor</name>
      <anchorfile>structsigc_1_1retype__return__functor.html</anchorfile>
      <anchor>aa9546db86a6d1cfa7224a3a0cbad4827</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>retype_return_functor</name>
      <anchorfile>structsigc_1_1retype__return__functor.html</anchorfile>
      <anchor>a9ebfb2a6cfb5125b0705c0adef2cbfb8</anchor>
      <arglist>(type_trait_take_t&lt; T_functor &gt; _A_functor)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__return__functor.html</anchorfile>
      <anchor>a4cf9725b7ac4fdfeded4ab3f56d61a88</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__return__functor.html</anchorfile>
      <anchor>aa6beb1654c027400d852e2df0fafb6aa</anchor>
      <arglist>(T_arg1 _A_a1)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__return__functor.html</anchorfile>
      <anchor>a1352125cef26032af138aa2a327f8f66</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__return__functor.html</anchorfile>
      <anchor>a0bcbf84c24c2195626bf4e6a2d1353b1</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__return__functor.html</anchorfile>
      <anchor>a7e3b161bfa746f69a2af64a00af7cbd2</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__return__functor.html</anchorfile>
      <anchor>a741b3fd8c423d3e63bdefa810e65ef44</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__return__functor.html</anchorfile>
      <anchor>ab6c4d0b29bbcbca2e64db8249db54171</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5, T_arg6 _A_a6)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__return__functor.html</anchorfile>
      <anchor>a68bdb4e6cf7d505f210017ab744603f0</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5, T_arg6 _A_a6, T_arg7 _A_a7)</arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::retype_return_functor&lt; void, T_functor &gt;</name>
    <filename>structsigc_1_1retype__return__functor_3_01void_00_01T__functor_01_4.html</filename>
    <templarg>class T_functor</templarg>
    <base>sigc::adapts</base>
    <member kind="typedef">
      <type>void</type>
      <name>result_type</name>
      <anchorfile>structsigc_1_1retype__return__functor_3_01void_00_01T__functor_01_4.html</anchorfile>
      <anchor>a64bccc59fc20fdf0fd80281597d350b2</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>retype_return_functor</name>
      <anchorfile>structsigc_1_1retype__return__functor_3_01void_00_01T__functor_01_4.html</anchorfile>
      <anchor>a720e802de29a72d1e15626b1719844bc</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>retype_return_functor</name>
      <anchorfile>structsigc_1_1retype__return__functor_3_01void_00_01T__functor_01_4.html</anchorfile>
      <anchor>acd4789babb601ac5bee163651d89f3c8</anchor>
      <arglist>(type_trait_take_t&lt; T_functor &gt; _A_functor)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__return__functor_3_01void_00_01T__functor_01_4.html</anchorfile>
      <anchor>af181f5a8134c5a834e2ad0ed7590fbfe</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__return__functor_3_01void_00_01T__functor_01_4.html</anchorfile>
      <anchor>a2ad16a9f8f247e6f7661838fb084ffd0</anchor>
      <arglist>(T_arg1 _A_a1)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__return__functor_3_01void_00_01T__functor_01_4.html</anchorfile>
      <anchor>abf17761c3eefdb3167a8562f009a8491</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__return__functor_3_01void_00_01T__functor_01_4.html</anchorfile>
      <anchor>adb392f4717b522668eb5236dbaf48e68</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__return__functor_3_01void_00_01T__functor_01_4.html</anchorfile>
      <anchor>a2c32e33b12c18d0533d4305ddd98dabe</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__return__functor_3_01void_00_01T__functor_01_4.html</anchorfile>
      <anchor>a24d383a5100302678a9a18dc5a138e51</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__return__functor_3_01void_00_01T__functor_01_4.html</anchorfile>
      <anchor>af0c3d23d0216aa0631720eb00ca8f7ef</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5, T_arg6 _A_a6)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>operator()</name>
      <anchorfile>structsigc_1_1retype__return__functor_3_01void_00_01T__functor_01_4.html</anchorfile>
      <anchor>a73a475fd2fe5e4d9e184ca5092b0ced4</anchor>
      <arglist>(T_arg1 _A_a1, T_arg2 _A_a2, T_arg3 _A_a3, T_arg4 _A_a4, T_arg5 _A_a5, T_arg6 _A_a6, T_arg7 _A_a7)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal</name>
    <filename>classsigc_1_1signal.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <templarg>class T_arg7</templarg>
    <base>signal7&lt; T_return, nil, nil, nil, nil, nil, nil, nil, nil &gt;</base>
    <class kind="class">sigc::signal::accumulated</class>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal.html</anchorfile>
      <anchor>a50432d1aebfbee5ef17a3f434d0c50bf</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal.html</anchorfile>
      <anchor>a271b486daa2bf801ed7d019da9aa33a1</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal.html</anchorfile>
      <anchor>abc17a093db8ae8a0a8333c7f35f64bd6</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal.html</anchorfile>
      <anchor>abc5e325959a67e1e0d4afa894136669d</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal.html</anchorfile>
      <anchor>a65b6aa92e1644d3c629c59803a1659b0</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal0</name>
    <filename>classsigc_1_1signal0.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_accumulator</templarg>
    <base>sigc::signal_base</base>
    <member kind="typedef">
      <type>slot_list_type::const_iterator</type>
      <name>const_iterator</name>
      <anchorfile>classsigc_1_1signal0.html</anchorfile>
      <anchor>ad4f7c62954f5c270e115d9b2a2df15ea</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::const_reverse_iterator</type>
      <name>const_reverse_iterator</name>
      <anchorfile>classsigc_1_1signal0.html</anchorfile>
      <anchor>a476f559a69eef5999c99cd6262a9aa2f</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>internal::signal_emit0&lt; T_return, T_accumulator &gt;</type>
      <name>emitter_type</name>
      <anchorfile>classsigc_1_1signal0.html</anchorfile>
      <anchor>ac7eafdced2d325d6003327b4360bc2dd</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::iterator</type>
      <name>iterator</name>
      <anchorfile>classsigc_1_1signal0.html</anchorfile>
      <anchor>ad61e875748cf4e1c2a6d89a930ae093e</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>emitter_type::result_type</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1signal0.html</anchorfile>
      <anchor>ae291a90c83f8ad1cdcc7c2a4cdd958de</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::reverse_iterator</type>
      <name>reverse_iterator</name>
      <anchorfile>classsigc_1_1signal0.html</anchorfile>
      <anchor>a1d9c390974304392ed12ee81543ab997</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list&lt; slot_type &gt;</type>
      <name>slot_list_type</name>
      <anchorfile>classsigc_1_1signal0.html</anchorfile>
      <anchor>add195c1c738ee8efe10294f21d258b77</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot&lt; T_return()&gt;</type>
      <name>slot_type</name>
      <anchorfile>classsigc_1_1signal0.html</anchorfile>
      <anchor>ae3fc90cec344b6585979e77d2b359287</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal0</name>
      <anchorfile>classsigc_1_1signal0.html</anchorfile>
      <anchor>a2fb24e11a8f645e5122646ea2b4a5d2f</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal0</name>
      <anchorfile>classsigc_1_1signal0.html</anchorfile>
      <anchor>a7dc687f1afb4088a3d888aa05dbf56d9</anchor>
      <arglist>(const signal0 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal0</name>
      <anchorfile>classsigc_1_1signal0.html</anchorfile>
      <anchor>ac1b915a86d0b75fd4e90c2a92f7ebc49</anchor>
      <arglist>(signal0 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>iterator</type>
      <name>connect</name>
      <anchorfile>classsigc_1_1signal0.html</anchorfile>
      <anchor>a609b1e0770f47c9081a3de56b65314d2</anchor>
      <arglist>(const slot_type &amp;slot_)</arglist>
    </member>
    <member kind="function">
      <type>iterator</type>
      <name>connect</name>
      <anchorfile>classsigc_1_1signal0.html</anchorfile>
      <anchor>a9b78954271b6dba5e926bd960f3e7905</anchor>
      <arglist>(slot_type &amp;&amp;slot_)</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>emit</name>
      <anchorfile>classsigc_1_1signal0.html</anchorfile>
      <anchor>a655829125186645bcbc61db8252134a8</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>emit_reverse</name>
      <anchorfile>classsigc_1_1signal0.html</anchorfile>
      <anchor>abdae39f9a7abd6133c03d65224c227d6</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor0&lt; result_type, signal0 &gt;</type>
      <name>make_slot</name>
      <anchorfile>classsigc_1_1signal0.html</anchorfile>
      <anchor>ab38c6bcc85d44fa542d086a3b527a23a</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1signal0.html</anchorfile>
      <anchor>a2dd3042c0681542ed6f2de5840f713a1</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>signal0 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal0.html</anchorfile>
      <anchor>ae2c5ac20ded2ed0968638928d4eba829</anchor>
      <arglist>(const signal0 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal0 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal0.html</anchorfile>
      <anchor>a5dbbd697483ab2de7a3b0df3958da876</anchor>
      <arglist>(signal0 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot_list_type</type>
      <name>slots</name>
      <anchorfile>classsigc_1_1signal0.html</anchorfile>
      <anchor>a5576113ddfd6b92a96f86072262307f9</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const slot_list_type</type>
      <name>slots</name>
      <anchorfile>classsigc_1_1signal0.html</anchorfile>
      <anchor>a73523d71edd7fb4294324e9561db6f3c</anchor>
      <arglist>() const</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal1</name>
    <filename>classsigc_1_1signal1.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_accumulator</templarg>
    <base>sigc::signal_base</base>
    <member kind="typedef">
      <type>slot_list_type::const_iterator</type>
      <name>const_iterator</name>
      <anchorfile>classsigc_1_1signal1.html</anchorfile>
      <anchor>af1e262b35c9574e65b2607cdfcaad707</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::const_reverse_iterator</type>
      <name>const_reverse_iterator</name>
      <anchorfile>classsigc_1_1signal1.html</anchorfile>
      <anchor>aeb327519f808dfec9a723511ef82caa3</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>internal::signal_emit1&lt; T_return, T_arg1, T_accumulator &gt;</type>
      <name>emitter_type</name>
      <anchorfile>classsigc_1_1signal1.html</anchorfile>
      <anchor>a63c6e2b55c8c3af083402bb7f5a66593</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::iterator</type>
      <name>iterator</name>
      <anchorfile>classsigc_1_1signal1.html</anchorfile>
      <anchor>ab61e2d1fcaf903dffbb26b01800907fb</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>emitter_type::result_type</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1signal1.html</anchorfile>
      <anchor>adcdcfa50d60e1832ce038a4a5554fce1</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::reverse_iterator</type>
      <name>reverse_iterator</name>
      <anchorfile>classsigc_1_1signal1.html</anchorfile>
      <anchor>ab0443049aa736d88770d0f534600b2bc</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list&lt; slot_type &gt;</type>
      <name>slot_list_type</name>
      <anchorfile>classsigc_1_1signal1.html</anchorfile>
      <anchor>a5fadeb350140d6aaf560b217e7e7c4b4</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot&lt; T_return(T_arg1)&gt;</type>
      <name>slot_type</name>
      <anchorfile>classsigc_1_1signal1.html</anchorfile>
      <anchor>a310736e1415c2cf4578892ffff35915c</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal1</name>
      <anchorfile>classsigc_1_1signal1.html</anchorfile>
      <anchor>aba62d8d0b9591bcfd728f8ae8a22d600</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal1</name>
      <anchorfile>classsigc_1_1signal1.html</anchorfile>
      <anchor>ab3378dd754ffddb4760f2a3afb271dbe</anchor>
      <arglist>(const signal1 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal1</name>
      <anchorfile>classsigc_1_1signal1.html</anchorfile>
      <anchor>a85ec968e0b25ee9285f297da5416b2a4</anchor>
      <arglist>(signal1 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>iterator</type>
      <name>connect</name>
      <anchorfile>classsigc_1_1signal1.html</anchorfile>
      <anchor>aac2ade0896bd4a982777d5dd6ac75888</anchor>
      <arglist>(const slot_type &amp;slot_)</arglist>
    </member>
    <member kind="function">
      <type>iterator</type>
      <name>connect</name>
      <anchorfile>classsigc_1_1signal1.html</anchorfile>
      <anchor>ac69d2681c586b310d8c056a319bb65fe</anchor>
      <arglist>(slot_type &amp;&amp;slot_)</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>emit</name>
      <anchorfile>classsigc_1_1signal1.html</anchorfile>
      <anchor>affe595f8b70b4f43a21be7192c0cba42</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1) const</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>emit_reverse</name>
      <anchorfile>classsigc_1_1signal1.html</anchorfile>
      <anchor>a449fc940ae822c4b6ea9282b9b292015</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1) const</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor1&lt; result_type, signal1, type_trait_take_t&lt; T_arg1 &gt; &gt;</type>
      <name>make_slot</name>
      <anchorfile>classsigc_1_1signal1.html</anchorfile>
      <anchor>a0e03446369fd979715ec15b77ae66133</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1signal1.html</anchorfile>
      <anchor>a828907c11f5c18d9522e5d5139484620</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1) const</arglist>
    </member>
    <member kind="function">
      <type>signal1 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal1.html</anchorfile>
      <anchor>ac7953e8b18121f5ba0c70f003c492124</anchor>
      <arglist>(const signal1 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal1 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal1.html</anchorfile>
      <anchor>a46fe3e12f84545326696b303f9836d39</anchor>
      <arglist>(signal1 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot_list_type</type>
      <name>slots</name>
      <anchorfile>classsigc_1_1signal1.html</anchorfile>
      <anchor>a7653b68e6a3b8445de91f89060bf2600</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const slot_list_type</type>
      <name>slots</name>
      <anchorfile>classsigc_1_1signal1.html</anchorfile>
      <anchor>a7777660b21fef2a6941c7dff23964604</anchor>
      <arglist>() const</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal2</name>
    <filename>classsigc_1_1signal2.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_accumulator</templarg>
    <base>sigc::signal_base</base>
    <member kind="typedef">
      <type>slot_list_type::const_iterator</type>
      <name>const_iterator</name>
      <anchorfile>classsigc_1_1signal2.html</anchorfile>
      <anchor>ad507bc5ea29adb2305f8fa91acbd30ee</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::const_reverse_iterator</type>
      <name>const_reverse_iterator</name>
      <anchorfile>classsigc_1_1signal2.html</anchorfile>
      <anchor>aacb8fe57ffe01dea5c5fb5af44634287</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>internal::signal_emit2&lt; T_return, T_arg1, T_arg2, T_accumulator &gt;</type>
      <name>emitter_type</name>
      <anchorfile>classsigc_1_1signal2.html</anchorfile>
      <anchor>a01379d580d21de8bc8d0d2d62e6324ea</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::iterator</type>
      <name>iterator</name>
      <anchorfile>classsigc_1_1signal2.html</anchorfile>
      <anchor>a658ba1c6468882c9b1d480be2bbaf55e</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>emitter_type::result_type</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1signal2.html</anchorfile>
      <anchor>a55151695417c33540357ff524bfe2665</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::reverse_iterator</type>
      <name>reverse_iterator</name>
      <anchorfile>classsigc_1_1signal2.html</anchorfile>
      <anchor>a6710759bdeb8e626fc09d8c448e6613f</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list&lt; slot_type &gt;</type>
      <name>slot_list_type</name>
      <anchorfile>classsigc_1_1signal2.html</anchorfile>
      <anchor>af31262f54dfb2a97540de9c4a1fc5726</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot&lt; T_return(T_arg1, T_arg2)&gt;</type>
      <name>slot_type</name>
      <anchorfile>classsigc_1_1signal2.html</anchorfile>
      <anchor>af7797ae10e76307f8d230588e760f119</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal2</name>
      <anchorfile>classsigc_1_1signal2.html</anchorfile>
      <anchor>a47aba9b19bc2bef0be7183022567e3ea</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal2</name>
      <anchorfile>classsigc_1_1signal2.html</anchorfile>
      <anchor>aa634515507f2ea4a35584e12e2dc92e7</anchor>
      <arglist>(const signal2 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal2</name>
      <anchorfile>classsigc_1_1signal2.html</anchorfile>
      <anchor>a20c59f06175d4c48394c65035d2c3376</anchor>
      <arglist>(signal2 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>iterator</type>
      <name>connect</name>
      <anchorfile>classsigc_1_1signal2.html</anchorfile>
      <anchor>aa686af4f961b098a23d4f7276437c2b0</anchor>
      <arglist>(const slot_type &amp;slot_)</arglist>
    </member>
    <member kind="function">
      <type>iterator</type>
      <name>connect</name>
      <anchorfile>classsigc_1_1signal2.html</anchorfile>
      <anchor>ab89b1876c69ea40954b0af37e75a21b4</anchor>
      <arglist>(slot_type &amp;&amp;slot_)</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>emit</name>
      <anchorfile>classsigc_1_1signal2.html</anchorfile>
      <anchor>afd12e2a266a6399cc32e888d6f5e6f2f</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2) const</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>emit_reverse</name>
      <anchorfile>classsigc_1_1signal2.html</anchorfile>
      <anchor>ad2d5f3169ba147de8d43fde9e93bac98</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2) const</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor2&lt; result_type, signal2, type_trait_take_t&lt; T_arg1 &gt;, type_trait_take_t&lt; T_arg2 &gt; &gt;</type>
      <name>make_slot</name>
      <anchorfile>classsigc_1_1signal2.html</anchorfile>
      <anchor>a008f27cf99376de3ef425397f718f7ce</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1signal2.html</anchorfile>
      <anchor>ac8b73c0624273b8dae819255961ea6a3</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2) const</arglist>
    </member>
    <member kind="function">
      <type>signal2 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal2.html</anchorfile>
      <anchor>a33b5b3f132d1534de9d385a2ca5171f8</anchor>
      <arglist>(const signal2 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal2 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal2.html</anchorfile>
      <anchor>ac15d7fd3298b3402864c1d6a126fd3f6</anchor>
      <arglist>(signal2 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot_list_type</type>
      <name>slots</name>
      <anchorfile>classsigc_1_1signal2.html</anchorfile>
      <anchor>ac28b0205aa1e60cc5ce062d4d8545323</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const slot_list_type</type>
      <name>slots</name>
      <anchorfile>classsigc_1_1signal2.html</anchorfile>
      <anchor>aa6be4804147afd56657abf5b4cf8ce3d</anchor>
      <arglist>() const</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal3</name>
    <filename>classsigc_1_1signal3.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_accumulator</templarg>
    <base>sigc::signal_base</base>
    <member kind="typedef">
      <type>slot_list_type::const_iterator</type>
      <name>const_iterator</name>
      <anchorfile>classsigc_1_1signal3.html</anchorfile>
      <anchor>a60e1ef95f82cd8981d61576d1e3f8e94</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::const_reverse_iterator</type>
      <name>const_reverse_iterator</name>
      <anchorfile>classsigc_1_1signal3.html</anchorfile>
      <anchor>a4ba3eb58c4c5ac2c25f49c48fd0af264</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>internal::signal_emit3&lt; T_return, T_arg1, T_arg2, T_arg3, T_accumulator &gt;</type>
      <name>emitter_type</name>
      <anchorfile>classsigc_1_1signal3.html</anchorfile>
      <anchor>adf54ec96c5fb78d4c8b7fc032a1937ad</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::iterator</type>
      <name>iterator</name>
      <anchorfile>classsigc_1_1signal3.html</anchorfile>
      <anchor>a8029a48126a2018947a2b6680ddabe6b</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>emitter_type::result_type</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1signal3.html</anchorfile>
      <anchor>a57c79755fc4c4b04196a9bf6742a0cc6</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::reverse_iterator</type>
      <name>reverse_iterator</name>
      <anchorfile>classsigc_1_1signal3.html</anchorfile>
      <anchor>acc453f0d5fc7f277494b2d6e737f6f68</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list&lt; slot_type &gt;</type>
      <name>slot_list_type</name>
      <anchorfile>classsigc_1_1signal3.html</anchorfile>
      <anchor>a3bc0616e7ac933e702a889a2a84e92d4</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot&lt; T_return(T_arg1, T_arg2, T_arg3)&gt;</type>
      <name>slot_type</name>
      <anchorfile>classsigc_1_1signal3.html</anchorfile>
      <anchor>afe37478128b40fb4efedcd3c0eb05b6b</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal3</name>
      <anchorfile>classsigc_1_1signal3.html</anchorfile>
      <anchor>a52731959f272612fd6abfe8850c5c8cf</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal3</name>
      <anchorfile>classsigc_1_1signal3.html</anchorfile>
      <anchor>afe2c4320927b403b011a2538317e6c70</anchor>
      <arglist>(const signal3 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal3</name>
      <anchorfile>classsigc_1_1signal3.html</anchorfile>
      <anchor>acd69c2a1d993f0b8993f82998f76020d</anchor>
      <arglist>(signal3 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>iterator</type>
      <name>connect</name>
      <anchorfile>classsigc_1_1signal3.html</anchorfile>
      <anchor>a3eae0b3796b2736be847f33a5124aacd</anchor>
      <arglist>(const slot_type &amp;slot_)</arglist>
    </member>
    <member kind="function">
      <type>iterator</type>
      <name>connect</name>
      <anchorfile>classsigc_1_1signal3.html</anchorfile>
      <anchor>ad71389c6d6ea60e745897579b3344d00</anchor>
      <arglist>(slot_type &amp;&amp;slot_)</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>emit</name>
      <anchorfile>classsigc_1_1signal3.html</anchorfile>
      <anchor>a8592e22e3780f2cdf19a568a8a116bbb</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3) const</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>emit_reverse</name>
      <anchorfile>classsigc_1_1signal3.html</anchorfile>
      <anchor>a97ff4f22c97920a81e3f27aa5d39ba99</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3) const</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor3&lt; result_type, signal3, type_trait_take_t&lt; T_arg1 &gt;, type_trait_take_t&lt; T_arg2 &gt;, type_trait_take_t&lt; T_arg3 &gt; &gt;</type>
      <name>make_slot</name>
      <anchorfile>classsigc_1_1signal3.html</anchorfile>
      <anchor>adec89191668f27c520ad573cc2d6b917</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1signal3.html</anchorfile>
      <anchor>aa7ae5338d6a883a28c61ff202e43547f</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3) const</arglist>
    </member>
    <member kind="function">
      <type>signal3 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal3.html</anchorfile>
      <anchor>a0f457655d76983c4e6402f80af3df18b</anchor>
      <arglist>(const signal3 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal3 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal3.html</anchorfile>
      <anchor>ae2062cbf4e89a056d9e699a29d5037fc</anchor>
      <arglist>(signal3 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot_list_type</type>
      <name>slots</name>
      <anchorfile>classsigc_1_1signal3.html</anchorfile>
      <anchor>ab9606b708078956a758b81503f956bee</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const slot_list_type</type>
      <name>slots</name>
      <anchorfile>classsigc_1_1signal3.html</anchorfile>
      <anchor>a742eb282312187bf8ee6992df1114781</anchor>
      <arglist>() const</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal4</name>
    <filename>classsigc_1_1signal4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_accumulator</templarg>
    <base>sigc::signal_base</base>
    <member kind="typedef">
      <type>slot_list_type::const_iterator</type>
      <name>const_iterator</name>
      <anchorfile>classsigc_1_1signal4.html</anchorfile>
      <anchor>a3d2626edc726047c04c8fe5b9824b958</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::const_reverse_iterator</type>
      <name>const_reverse_iterator</name>
      <anchorfile>classsigc_1_1signal4.html</anchorfile>
      <anchor>a555ce030884fdf2bde788b75db01bedf</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>internal::signal_emit4&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_accumulator &gt;</type>
      <name>emitter_type</name>
      <anchorfile>classsigc_1_1signal4.html</anchorfile>
      <anchor>acf3d1e6d6487c0ecc13ed3eab949eec7</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::iterator</type>
      <name>iterator</name>
      <anchorfile>classsigc_1_1signal4.html</anchorfile>
      <anchor>a31e8354263a3097bba9c63b8494143f0</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>emitter_type::result_type</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1signal4.html</anchorfile>
      <anchor>af32418ba14001a63d28af08abb7407f0</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::reverse_iterator</type>
      <name>reverse_iterator</name>
      <anchorfile>classsigc_1_1signal4.html</anchorfile>
      <anchor>a1395da7d3283b0166af135193a4047c8</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list&lt; slot_type &gt;</type>
      <name>slot_list_type</name>
      <anchorfile>classsigc_1_1signal4.html</anchorfile>
      <anchor>a0ad0f56a43825c6d77d36dd2f06ef828</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4)&gt;</type>
      <name>slot_type</name>
      <anchorfile>classsigc_1_1signal4.html</anchorfile>
      <anchor>aa93452fe80399184444d094786be851c</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal4</name>
      <anchorfile>classsigc_1_1signal4.html</anchorfile>
      <anchor>a2d469f516a9edac2b20d7f6cf46e821a</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal4</name>
      <anchorfile>classsigc_1_1signal4.html</anchorfile>
      <anchor>a2d29b39c12c6c014ed7166190e9c8e22</anchor>
      <arglist>(const signal4 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal4</name>
      <anchorfile>classsigc_1_1signal4.html</anchorfile>
      <anchor>a2197974bac2b5e8e7b1c417580686e9e</anchor>
      <arglist>(signal4 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>iterator</type>
      <name>connect</name>
      <anchorfile>classsigc_1_1signal4.html</anchorfile>
      <anchor>a5fdb6df3cf74f5c96fb6319eef4d0a39</anchor>
      <arglist>(const slot_type &amp;slot_)</arglist>
    </member>
    <member kind="function">
      <type>iterator</type>
      <name>connect</name>
      <anchorfile>classsigc_1_1signal4.html</anchorfile>
      <anchor>a5c8d2d9c91a134650a52631d49ecdaac</anchor>
      <arglist>(slot_type &amp;&amp;slot_)</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>emit</name>
      <anchorfile>classsigc_1_1signal4.html</anchorfile>
      <anchor>aa7774ba75b5e2391a6fe2841f8b3b0ef</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4) const</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>emit_reverse</name>
      <anchorfile>classsigc_1_1signal4.html</anchorfile>
      <anchor>a0aaf27875cdb8a0ae381372d98871ae1</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4) const</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor4&lt; result_type, signal4, type_trait_take_t&lt; T_arg1 &gt;, type_trait_take_t&lt; T_arg2 &gt;, type_trait_take_t&lt; T_arg3 &gt;, type_trait_take_t&lt; T_arg4 &gt; &gt;</type>
      <name>make_slot</name>
      <anchorfile>classsigc_1_1signal4.html</anchorfile>
      <anchor>a67a2cf647b87346f4d2ed80d10fc5d88</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1signal4.html</anchorfile>
      <anchor>a8523a4d47c3a6469fcc50da9977afdb8</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4) const</arglist>
    </member>
    <member kind="function">
      <type>signal4 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal4.html</anchorfile>
      <anchor>a54e8647ee68009278b0f6fb23fb8d04a</anchor>
      <arglist>(const signal4 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal4 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal4.html</anchorfile>
      <anchor>aacb67e8705aff5a6af520577fa870798</anchor>
      <arglist>(signal4 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot_list_type</type>
      <name>slots</name>
      <anchorfile>classsigc_1_1signal4.html</anchorfile>
      <anchor>ae490f1a6802c40a4c3b12e1580520c88</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const slot_list_type</type>
      <name>slots</name>
      <anchorfile>classsigc_1_1signal4.html</anchorfile>
      <anchor>a35f2cebe3804d3e04d3253b7cc8d2a72</anchor>
      <arglist>() const</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal5</name>
    <filename>classsigc_1_1signal5.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_accumulator</templarg>
    <base>sigc::signal_base</base>
    <member kind="typedef">
      <type>slot_list_type::const_iterator</type>
      <name>const_iterator</name>
      <anchorfile>classsigc_1_1signal5.html</anchorfile>
      <anchor>a17e79eed46f178a12d2751eddcf85290</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::const_reverse_iterator</type>
      <name>const_reverse_iterator</name>
      <anchorfile>classsigc_1_1signal5.html</anchorfile>
      <anchor>ad5ba46907fe236e0cff806888696d569</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>internal::signal_emit5&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_accumulator &gt;</type>
      <name>emitter_type</name>
      <anchorfile>classsigc_1_1signal5.html</anchorfile>
      <anchor>a7d77e5fa748b024842bf92e28cf0f4ab</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::iterator</type>
      <name>iterator</name>
      <anchorfile>classsigc_1_1signal5.html</anchorfile>
      <anchor>acee689b441305fcee098345729fc28f3</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>emitter_type::result_type</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1signal5.html</anchorfile>
      <anchor>aceb959897dcf8e3c7209c283d4848b94</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::reverse_iterator</type>
      <name>reverse_iterator</name>
      <anchorfile>classsigc_1_1signal5.html</anchorfile>
      <anchor>ab684cb9920d0f7949f28c03d50b58275</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list&lt; slot_type &gt;</type>
      <name>slot_list_type</name>
      <anchorfile>classsigc_1_1signal5.html</anchorfile>
      <anchor>a4c79ab227fc3b31b990e925636f7788e</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5)&gt;</type>
      <name>slot_type</name>
      <anchorfile>classsigc_1_1signal5.html</anchorfile>
      <anchor>ae73737aad5d854c6466e8b13e7963b9e</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal5</name>
      <anchorfile>classsigc_1_1signal5.html</anchorfile>
      <anchor>af717d1a6fd8612da84dce33fe6640b7a</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal5</name>
      <anchorfile>classsigc_1_1signal5.html</anchorfile>
      <anchor>a7885861b9cdbacbe2d58a13cd96ec265</anchor>
      <arglist>(const signal5 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal5</name>
      <anchorfile>classsigc_1_1signal5.html</anchorfile>
      <anchor>af39141aeec9dc870dd28926202493de4</anchor>
      <arglist>(signal5 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>iterator</type>
      <name>connect</name>
      <anchorfile>classsigc_1_1signal5.html</anchorfile>
      <anchor>a057789cc27a920700e240f8f3d78dd65</anchor>
      <arglist>(const slot_type &amp;slot_)</arglist>
    </member>
    <member kind="function">
      <type>iterator</type>
      <name>connect</name>
      <anchorfile>classsigc_1_1signal5.html</anchorfile>
      <anchor>a05cfed3d3e29158424bc810168d78153</anchor>
      <arglist>(slot_type &amp;&amp;slot_)</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>emit</name>
      <anchorfile>classsigc_1_1signal5.html</anchorfile>
      <anchor>a8772fef879632c4ff45e82b4b00b0157</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5) const</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>emit_reverse</name>
      <anchorfile>classsigc_1_1signal5.html</anchorfile>
      <anchor>aa6d2e202263e3879f0d3949612d7fcdf</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5) const</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor5&lt; result_type, signal5, type_trait_take_t&lt; T_arg1 &gt;, type_trait_take_t&lt; T_arg2 &gt;, type_trait_take_t&lt; T_arg3 &gt;, type_trait_take_t&lt; T_arg4 &gt;, type_trait_take_t&lt; T_arg5 &gt; &gt;</type>
      <name>make_slot</name>
      <anchorfile>classsigc_1_1signal5.html</anchorfile>
      <anchor>a3fa54ccdb62d5f454dd20c367f25f3dd</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1signal5.html</anchorfile>
      <anchor>a7a5bb7b92f49e99354caf50bfef16907</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5) const</arglist>
    </member>
    <member kind="function">
      <type>signal5 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal5.html</anchorfile>
      <anchor>a6941fe2c781ece780c8c6d0f43ee69a2</anchor>
      <arglist>(const signal5 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal5 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal5.html</anchorfile>
      <anchor>a6e611846cb5b47eff1859d0ede78bf77</anchor>
      <arglist>(signal5 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot_list_type</type>
      <name>slots</name>
      <anchorfile>classsigc_1_1signal5.html</anchorfile>
      <anchor>ad6a4ae2a214d8710be6e36bb425587fc</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const slot_list_type</type>
      <name>slots</name>
      <anchorfile>classsigc_1_1signal5.html</anchorfile>
      <anchor>a32af276c9c56abbb0386f54262b40be5</anchor>
      <arglist>() const</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal6</name>
    <filename>classsigc_1_1signal6.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <templarg>class T_accumulator</templarg>
    <base>sigc::signal_base</base>
    <member kind="typedef">
      <type>slot_list_type::const_iterator</type>
      <name>const_iterator</name>
      <anchorfile>classsigc_1_1signal6.html</anchorfile>
      <anchor>ac88a9c4e9bab5ad04c66d3f5d3978f0f</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::const_reverse_iterator</type>
      <name>const_reverse_iterator</name>
      <anchorfile>classsigc_1_1signal6.html</anchorfile>
      <anchor>aff490e7f75a83aa2f324a859f9071a79</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>internal::signal_emit6&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_accumulator &gt;</type>
      <name>emitter_type</name>
      <anchorfile>classsigc_1_1signal6.html</anchorfile>
      <anchor>acdd2683223e4701f58350152f32f4488</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::iterator</type>
      <name>iterator</name>
      <anchorfile>classsigc_1_1signal6.html</anchorfile>
      <anchor>a1acee11287974cdac1bc63c856e5331d</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>emitter_type::result_type</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1signal6.html</anchorfile>
      <anchor>a56f1acca230e676dae665d41a10acc8f</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::reverse_iterator</type>
      <name>reverse_iterator</name>
      <anchorfile>classsigc_1_1signal6.html</anchorfile>
      <anchor>a79b741b3f0def8f52fc185ad50b60673</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list&lt; slot_type &gt;</type>
      <name>slot_list_type</name>
      <anchorfile>classsigc_1_1signal6.html</anchorfile>
      <anchor>a0e4fea9bd1ed35f9d60bbc26c4fae007</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6)&gt;</type>
      <name>slot_type</name>
      <anchorfile>classsigc_1_1signal6.html</anchorfile>
      <anchor>ac62cdf4db7dcd5e30975e51e978f03db</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal6</name>
      <anchorfile>classsigc_1_1signal6.html</anchorfile>
      <anchor>af7f529bbd9cf26d468ed18426b9b51ea</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal6</name>
      <anchorfile>classsigc_1_1signal6.html</anchorfile>
      <anchor>a0244dde296bd892c590c86ced5281e3b</anchor>
      <arglist>(const signal6 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal6</name>
      <anchorfile>classsigc_1_1signal6.html</anchorfile>
      <anchor>ab717ce413bda79e1de41944d0675a8ca</anchor>
      <arglist>(signal6 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>iterator</type>
      <name>connect</name>
      <anchorfile>classsigc_1_1signal6.html</anchorfile>
      <anchor>a66c302607cf4fb74f5d3352f9c394c9b</anchor>
      <arglist>(const slot_type &amp;slot_)</arglist>
    </member>
    <member kind="function">
      <type>iterator</type>
      <name>connect</name>
      <anchorfile>classsigc_1_1signal6.html</anchorfile>
      <anchor>a1754aa5a8959da0bb55e42864a8365af</anchor>
      <arglist>(slot_type &amp;&amp;slot_)</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>emit</name>
      <anchorfile>classsigc_1_1signal6.html</anchorfile>
      <anchor>a6361a9230323e7c7e86e2c9e6c8fe21b</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6) const</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>emit_reverse</name>
      <anchorfile>classsigc_1_1signal6.html</anchorfile>
      <anchor>a2e8b355902f0646fb34b52b495123167</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6) const</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor6&lt; result_type, signal6, type_trait_take_t&lt; T_arg1 &gt;, type_trait_take_t&lt; T_arg2 &gt;, type_trait_take_t&lt; T_arg3 &gt;, type_trait_take_t&lt; T_arg4 &gt;, type_trait_take_t&lt; T_arg5 &gt;, type_trait_take_t&lt; T_arg6 &gt; &gt;</type>
      <name>make_slot</name>
      <anchorfile>classsigc_1_1signal6.html</anchorfile>
      <anchor>ae84f71c390c4835ae62e2e24ae95c104</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1signal6.html</anchorfile>
      <anchor>affec011fd6e9605f10e50fdd4db424d8</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6) const</arglist>
    </member>
    <member kind="function">
      <type>signal6 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal6.html</anchorfile>
      <anchor>a969e72d61c5ef1df804578d666247d58</anchor>
      <arglist>(const signal6 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal6 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal6.html</anchorfile>
      <anchor>a0a4b19a3b78cabcbced2fcd8b8fea992</anchor>
      <arglist>(signal6 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot_list_type</type>
      <name>slots</name>
      <anchorfile>classsigc_1_1signal6.html</anchorfile>
      <anchor>af44115a7bfa4586fc5312259a1df9567</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const slot_list_type</type>
      <name>slots</name>
      <anchorfile>classsigc_1_1signal6.html</anchorfile>
      <anchor>ac66109f683ae86898ae10109a80b28a4</anchor>
      <arglist>() const</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal7</name>
    <filename>classsigc_1_1signal7.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <templarg>class T_arg7</templarg>
    <templarg>class T_accumulator</templarg>
    <base>sigc::signal_base</base>
    <member kind="typedef">
      <type>slot_list_type::const_iterator</type>
      <name>const_iterator</name>
      <anchorfile>classsigc_1_1signal7.html</anchorfile>
      <anchor>a6eef6225eba66a86dd32c3f3b79845f7</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::const_reverse_iterator</type>
      <name>const_reverse_iterator</name>
      <anchorfile>classsigc_1_1signal7.html</anchorfile>
      <anchor>ad1ba32ad7dae0c05a4012ada78077505</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>internal::signal_emit7&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7, T_accumulator &gt;</type>
      <name>emitter_type</name>
      <anchorfile>classsigc_1_1signal7.html</anchorfile>
      <anchor>a7fa856e67a31c86538db7c289a6870e3</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::iterator</type>
      <name>iterator</name>
      <anchorfile>classsigc_1_1signal7.html</anchorfile>
      <anchor>abc62e52cc684f917577a2fe3cd914d4a</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>emitter_type::result_type</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1signal7.html</anchorfile>
      <anchor>a5a75d73a254cf91a0f3ad1cd3545e29f</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list_type::reverse_iterator</type>
      <name>reverse_iterator</name>
      <anchorfile>classsigc_1_1signal7.html</anchorfile>
      <anchor>a59c9c9fee7a98528839df592241351a9</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_list&lt; slot_type &gt;</type>
      <name>slot_list_type</name>
      <anchorfile>classsigc_1_1signal7.html</anchorfile>
      <anchor>a79686c2174ab01dc23394953955ff003</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7)&gt;</type>
      <name>slot_type</name>
      <anchorfile>classsigc_1_1signal7.html</anchorfile>
      <anchor>a72ee8c51eea3d1ba99eb9b512dfccd81</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal7</name>
      <anchorfile>classsigc_1_1signal7.html</anchorfile>
      <anchor>ab6d54db53a164fb459fcb342d4b45ff0</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal7</name>
      <anchorfile>classsigc_1_1signal7.html</anchorfile>
      <anchor>a12d6e064d0a5c2a8c09d60a64184a823</anchor>
      <arglist>(const signal7 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal7</name>
      <anchorfile>classsigc_1_1signal7.html</anchorfile>
      <anchor>a5a5893dd4f97d77b7945819f5ada2aee</anchor>
      <arglist>(signal7 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>iterator</type>
      <name>connect</name>
      <anchorfile>classsigc_1_1signal7.html</anchorfile>
      <anchor>adc55ac9b0f935fd87a67904022e03cb2</anchor>
      <arglist>(const slot_type &amp;slot_)</arglist>
    </member>
    <member kind="function">
      <type>iterator</type>
      <name>connect</name>
      <anchorfile>classsigc_1_1signal7.html</anchorfile>
      <anchor>a5aed4bdb8d85c3d854f01410d2d9d3a4</anchor>
      <arglist>(slot_type &amp;&amp;slot_)</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>emit</name>
      <anchorfile>classsigc_1_1signal7.html</anchorfile>
      <anchor>aead3b0e97ed0bd95f870b1956bff83c2</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6, type_trait_take_t&lt; T_arg7 &gt; _A_a7) const</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>emit_reverse</name>
      <anchorfile>classsigc_1_1signal7.html</anchorfile>
      <anchor>a192581feb2dbcfc9c56692e72e91e9a8</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6, type_trait_take_t&lt; T_arg7 &gt; _A_a7) const</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor7&lt; result_type, signal7, type_trait_take_t&lt; T_arg1 &gt;, type_trait_take_t&lt; T_arg2 &gt;, type_trait_take_t&lt; T_arg3 &gt;, type_trait_take_t&lt; T_arg4 &gt;, type_trait_take_t&lt; T_arg5 &gt;, type_trait_take_t&lt; T_arg6 &gt;, type_trait_take_t&lt; T_arg7 &gt; &gt;</type>
      <name>make_slot</name>
      <anchorfile>classsigc_1_1signal7.html</anchorfile>
      <anchor>ac8aecd73f6a77e764b3f7c4d8c46d8c6</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1signal7.html</anchorfile>
      <anchor>ac6fd43215c8f19082402387359330071</anchor>
      <arglist>(type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6, type_trait_take_t&lt; T_arg7 &gt; _A_a7) const</arglist>
    </member>
    <member kind="function">
      <type>signal7 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal7.html</anchorfile>
      <anchor>a80e54f86436b8b62cd233c95544aade2</anchor>
      <arglist>(const signal7 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal7 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal7.html</anchorfile>
      <anchor>aa6b0d4e35b28b2252864ab7cb9b6ad3a</anchor>
      <arglist>(signal7 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot_list_type</type>
      <name>slots</name>
      <anchorfile>classsigc_1_1signal7.html</anchorfile>
      <anchor>a68153d9079b4881352113079cd6216f7</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const slot_list_type</type>
      <name>slots</name>
      <anchorfile>classsigc_1_1signal7.html</anchorfile>
      <anchor>a42509108239296e424844df2cd330aca</anchor>
      <arglist>() const</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal::accumulated</name>
    <filename>classsigc_1_1signal_1_1accumulated.html</filename>
    <templarg>class T_accumulator</templarg>
    <base>signal7&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7, T_accumulator &gt;</base>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_1_1accumulated.html</anchorfile>
      <anchor>a46bed3515606e0a5807f08e239891ca0</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_1_1accumulated.html</anchorfile>
      <anchor>a032428476a190d9dea6313f70e5b8a10</anchor>
      <arglist>(const accumulated &amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return()&gt;</name>
    <filename>classsigc_1_1signal_3_01T__return_07_08_4.html</filename>
    <templarg>class T_return</templarg>
    <base>signal0&lt; T_return, nil &gt;</base>
    <class kind="class">sigc::signal&lt; T_return()&gt;::accumulated</class>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07_08_4.html</anchorfile>
      <anchor>aefdfdd54adc65612b58929298274453c</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07_08_4.html</anchorfile>
      <anchor>aba571147db7b805fad8da3c0c82fea0b</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07_08_4.html</anchorfile>
      <anchor>a2656448f8eb3cf4d9043009f56b08104</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07_08_4.html</anchorfile>
      <anchor>a9eb9b68e440f3b7059ffae0d7ca2f813</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07_08_4.html</anchorfile>
      <anchor>a9f5b0d56860ebdbe4cb7d35f848a6c58</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return()&gt;::accumulated</name>
    <filename>classsigc_1_1signal_3_01T__return_07_08_4_1_1accumulated.html</filename>
    <templarg>class T_accumulator</templarg>
    <base>signal0&lt; T_return, T_accumulator &gt;</base>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07_08_4_1_1accumulated.html</anchorfile>
      <anchor>a601feadb67ac4aaa7af709af51f654ca</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07_08_4_1_1accumulated.html</anchorfile>
      <anchor>a219dd919cd64e95ad89c5a501b3abcf6</anchor>
      <arglist>(const accumulated &amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return(T_arg1)&gt;</name>
    <filename>classsigc_1_1signal_3_01T__return_07T__arg1_08_4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <base>signal1&lt; T_return, T_arg1, nil &gt;</base>
    <class kind="class">sigc::signal&lt; T_return(T_arg1)&gt;::accumulated</class>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_08_4.html</anchorfile>
      <anchor>a2e6e6d55741d1ef7e4ef3cf1a385ccf1</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_08_4.html</anchorfile>
      <anchor>a41a5c99993530756404583e4fbc748ba</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_08_4.html</anchorfile>
      <anchor>acc30f0949e699fbff85d341162298761</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_08_4.html</anchorfile>
      <anchor>a098026bea4a0efb1c0d44dc8fb615db4</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_08_4.html</anchorfile>
      <anchor>ac867e06adf72fccfbc5d53f5a756a9c0</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return(T_arg1)&gt;::accumulated</name>
    <filename>classsigc_1_1signal_3_01T__return_07T__arg1_08_4_1_1accumulated.html</filename>
    <templarg>class T_accumulator</templarg>
    <base>signal1&lt; T_return, T_arg1, T_accumulator &gt;</base>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_08_4_1_1accumulated.html</anchorfile>
      <anchor>a31b87e65e2e6be201c18ff7c7c3e87e9</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_08_4_1_1accumulated.html</anchorfile>
      <anchor>abbb5481dc26b9efce3b8604eb0f6ea27</anchor>
      <arglist>(const accumulated &amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return(T_arg1, T_arg2)&gt;</name>
    <filename>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_08_4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <base>signal2&lt; T_return, T_arg1, T_arg2, nil &gt;</base>
    <class kind="class">sigc::signal&lt; T_return(T_arg1, T_arg2)&gt;::accumulated</class>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_08_4.html</anchorfile>
      <anchor>a9d8fa2e7dd971a359c53c5ed19310f00</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_08_4.html</anchorfile>
      <anchor>a13d95a6b3058ddbd0f55fd00953cdee5</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_08_4.html</anchorfile>
      <anchor>acc41707d3187fe1ac6bb9180f82428a7</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_08_4.html</anchorfile>
      <anchor>a3476a1d701e9d9501ecf7b56842ac89a</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_08_4.html</anchorfile>
      <anchor>aab1056aa6c7f625d081972faa727d73a</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return(T_arg1, T_arg2)&gt;::accumulated</name>
    <filename>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_08_4_1_1accumulated.html</filename>
    <templarg>class T_accumulator</templarg>
    <base>signal2&lt; T_return, T_arg1, T_arg2, T_accumulator &gt;</base>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_08_4_1_1accumulated.html</anchorfile>
      <anchor>abf5d54ba4c8e7f2792be010df45df59b</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_08_4_1_1accumulated.html</anchorfile>
      <anchor>af6082d36c41f676b54f271f31ca781b6</anchor>
      <arglist>(const accumulated &amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3)&gt;</name>
    <filename>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_08_4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <base>signal3&lt; T_return, T_arg1, T_arg2, T_arg3, nil &gt;</base>
    <class kind="class">sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3)&gt;::accumulated</class>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_08_4.html</anchorfile>
      <anchor>a27d493742451c292a6c001b9353c08d9</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_08_4.html</anchorfile>
      <anchor>a51bd913df6a849d6dd720e8c19532149</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_08_4.html</anchorfile>
      <anchor>ac22b59e41db40b6cbe6ac4b71d048170</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_08_4.html</anchorfile>
      <anchor>a1a1fe5a1c4f9728bf09bd233d8aa547e</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_08_4.html</anchorfile>
      <anchor>aadf9306306e8e7c53067dbda7df56215</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3)&gt;::accumulated</name>
    <filename>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_08_4_1_1accumulated.html</filename>
    <templarg>class T_accumulator</templarg>
    <base>signal3&lt; T_return, T_arg1, T_arg2, T_arg3, T_accumulator &gt;</base>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_08_4_1_1accumulated.html</anchorfile>
      <anchor>a096e447ba082bebd28601309d595807c</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_08_4_1_1accumulated.html</anchorfile>
      <anchor>ad47d6448e3137d45649656d23b19f89a</anchor>
      <arglist>(const accumulated &amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4)&gt;</name>
    <filename>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_08_4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <base>signal4&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, nil &gt;</base>
    <class kind="class">sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4)&gt;::accumulated</class>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_08_4.html</anchorfile>
      <anchor>a1569f4348e140681f696a49028309042</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_08_4.html</anchorfile>
      <anchor>a435444e5772da8ddb74edb7f901f3ae6</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_08_4.html</anchorfile>
      <anchor>a8d26e7db0ca474d71736c778e0264f4c</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_08_4.html</anchorfile>
      <anchor>ab28ae7eff330d0ca7036df8c6ce243af</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_08_4.html</anchorfile>
      <anchor>a104be155552b356afb30e079b01f5abc</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4)&gt;::accumulated</name>
    <filename>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_08_4_1_1accumulated.html</filename>
    <templarg>class T_accumulator</templarg>
    <base>signal4&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_accumulator &gt;</base>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_08_4_1_1accumulated.html</anchorfile>
      <anchor>acd7fd012dcc073e9a6770af949517040</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_08_4_1_1accumulated.html</anchorfile>
      <anchor>a3197013a55f3afc0fb9451b033c3fe47</anchor>
      <arglist>(const accumulated &amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5)&gt;</name>
    <filename>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_08_4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <base>signal5&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, nil &gt;</base>
    <class kind="class">sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5)&gt;::accumulated</class>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_08_4.html</anchorfile>
      <anchor>a7006442d66ee8f812ffdff15cd5694a3</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_08_4.html</anchorfile>
      <anchor>a7d61f31c6577339602b629bff20f0248</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_08_4.html</anchorfile>
      <anchor>a016fcefe1eb805926dafad10f970f826</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_08_4.html</anchorfile>
      <anchor>a8be0bee8dd0e0f60f8a696f975b9b231</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_08_4.html</anchorfile>
      <anchor>a2ff5481d68e36514082c5aeb868c40b6</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5)&gt;::accumulated</name>
    <filename>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_08_4_1_1accumulated.html</filename>
    <templarg>class T_accumulator</templarg>
    <base>signal5&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_accumulator &gt;</base>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_08_4_1_1accumulated.html</anchorfile>
      <anchor>a77a966e973f4ab159f0dbb92737dd02e</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_08_4_1_1accumulated.html</anchorfile>
      <anchor>a3b820b8e12b845648ff1eeff72bf97fa</anchor>
      <arglist>(const accumulated &amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6)&gt;</name>
    <filename>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_08_4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <base>signal6&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, nil &gt;</base>
    <class kind="class">sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6)&gt;::accumulated</class>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_08_4.html</anchorfile>
      <anchor>a6ec07b9037eeeab8094beb440d80407b</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_08_4.html</anchorfile>
      <anchor>a975a2a33c137e6b662a31933d80563d6</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_08_4.html</anchorfile>
      <anchor>a16f865ba75270a1808ed8f3a37e53a48</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_08_4.html</anchorfile>
      <anchor>a827eda4e6199ee04d70c2c44a6b3fb8a</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_08_4.html</anchorfile>
      <anchor>a631015b9c307a63dcbf324f84a225bd5</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6)&gt;::accumulated</name>
    <filename>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_dace8c5b03b250e13cd615dbc3de0ac4.html</filename>
    <templarg>class T_accumulator</templarg>
    <base>signal6&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_accumulator &gt;</base>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_dace8c5b03b250e13cd615dbc3de0ac4.html</anchorfile>
      <anchor>a3daa5943f5b629a17a547b75743b8829</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_dace8c5b03b250e13cd615dbc3de0ac4.html</anchorfile>
      <anchor>afe1cea16b0f0296ff874a2793cc51b53</anchor>
      <arglist>(const accumulated &amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7)&gt;</name>
    <filename>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_00_01T__arg7_08_4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <templarg>class T_arg7</templarg>
    <base>signal7&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7, nil &gt;</base>
    <class kind="class">sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7)&gt;::accumulated</class>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_00_01T__arg7_08_4.html</anchorfile>
      <anchor>ac3cad4e400bacfc4a539cb7a31cd0e01</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_00_01T__arg7_08_4.html</anchorfile>
      <anchor>a9b9928bf9b40cae47599be1f4f7f85dc</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_00_01T__arg7_08_4.html</anchorfile>
      <anchor>a5595334118f67137ded1af1720743da8</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_00_01T__arg7_08_4.html</anchorfile>
      <anchor>a55f783a4c35d35f867b7d1fad661354e</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_00_01T__arg7_08_4.html</anchorfile>
      <anchor>a0cc56c7900532664062d2bb1bff86d0b</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7)&gt;::accumulated</name>
    <filename>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_e94644748df11174db4187c0801a1d95.html</filename>
    <templarg>class T_accumulator</templarg>
    <base>signal7&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7, T_accumulator &gt;</base>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_e94644748df11174db4187c0801a1d95.html</anchorfile>
      <anchor>a33552c46e4db86b98bea128fd32d2c08</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_07T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_e94644748df11174db4187c0801a1d95.html</anchorfile>
      <anchor>afc104f4e3d7a445cf4f7989c52f1d93c</anchor>
      <arglist>(const accumulated &amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return, nil, nil, nil, nil, nil, nil, nil &gt;</name>
    <filename>classsigc_1_1signal_3_01T__return_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</filename>
    <templarg>class T_return</templarg>
    <base>signal0&lt; T_return, nil &gt;</base>
    <class kind="class">sigc::signal&lt; T_return, nil, nil, nil, nil, nil, nil, nil &gt;::accumulated</class>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a69bd320a61ade13046ae3ed20498ab83</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a3dcbc7a6481f46f08a366e489876a7a0</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a59107d243fe3408d64e4e963d5023dcb</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a5064d5e47d363f3ecb03c7425170e404</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>aae230403feada4840cd7304e8faf8676</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return, nil, nil, nil, nil, nil, nil, nil &gt;::accumulated</name>
    <filename>classsigc_1_1signal_3_01T__return_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4_1_1accumulated.html</filename>
    <templarg>class T_accumulator</templarg>
    <base>signal0&lt; T_return, T_accumulator &gt;</base>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4_1_1accumulated.html</anchorfile>
      <anchor>a54763bd7352a9c84b5e5956b4f65c914</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4_1_1accumulated.html</anchorfile>
      <anchor>a1cea5890a6ac54f475ae28062c99e4f4</anchor>
      <arglist>(const accumulated &amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return, T_arg1, nil, nil, nil, nil, nil, nil &gt;</name>
    <filename>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <base>signal1&lt; T_return, T_arg1, nil &gt;</base>
    <class kind="class">sigc::signal&lt; T_return, T_arg1, nil, nil, nil, nil, nil, nil &gt;::accumulated</class>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a7561df6caf1f508eff71f035db8260c1</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>ae55caf393287987076a093a17cd2a272</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>aee2249d4e36771d4f2d5f6c8848a95ce</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>ac255e001c69a07aa65d99bb13835983b</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a82dcc43428cf06fa6a8433f8f014545b</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return, T_arg1, nil, nil, nil, nil, nil, nil &gt;::accumulated</name>
    <filename>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4_1_1accumulated.html</filename>
    <templarg>class T_accumulator</templarg>
    <base>signal1&lt; T_return, T_arg1, T_accumulator &gt;</base>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4_1_1accumulated.html</anchorfile>
      <anchor>a772b7939dc0552087c6b52a98d97eab8</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4_1_1accumulated.html</anchorfile>
      <anchor>a94b30a9ffefefc43cb79b4f30ad65237</anchor>
      <arglist>(const accumulated &amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return, T_arg1, T_arg2, nil, nil, nil, nil, nil &gt;</name>
    <filename>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <base>signal2&lt; T_return, T_arg1, T_arg2, nil &gt;</base>
    <class kind="class">sigc::signal&lt; T_return, T_arg1, T_arg2, nil, nil, nil, nil, nil &gt;::accumulated</class>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a3ad9be2894fd3f78bfde9488207ff502</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a199611dacb9e03614c9203ad27597667</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>ae7f76745ea92595cdd179725425487ea</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a91d599ac85cd90d6fd0c65f3c4db5084</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a57045c3217246bd68f2d9dba6dc23641</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return, T_arg1, T_arg2, nil, nil, nil, nil, nil &gt;::accumulated</name>
    <filename>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4_1_1accumulated.html</filename>
    <templarg>class T_accumulator</templarg>
    <base>signal2&lt; T_return, T_arg1, T_arg2, T_accumulator &gt;</base>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4_1_1accumulated.html</anchorfile>
      <anchor>a83f917545362d71b7d08fee23e619eaf</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4_1_1accumulated.html</anchorfile>
      <anchor>aa462577f7f52f54b2bf2c87cbb7aa9bc</anchor>
      <arglist>(const accumulated &amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return, T_arg1, T_arg2, T_arg3, nil, nil, nil, nil &gt;</name>
    <filename>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <base>signal3&lt; T_return, T_arg1, T_arg2, T_arg3, nil &gt;</base>
    <class kind="class">sigc::signal&lt; T_return, T_arg1, T_arg2, T_arg3, nil, nil, nil, nil &gt;::accumulated</class>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a3866d625025ecae063d59e81f86ec836</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a80e31f482db26fc380264b7dea1041d7</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a84d26ae312afec80b6a921894a52e9a8</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a3f69e31ba64956fb132bba3c3a1d855e</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a440d568eb084f7375e5fcaa313157a4c</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return, T_arg1, T_arg2, T_arg3, nil, nil, nil, nil &gt;::accumulated</name>
    <filename>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01nil_00_01nil_00_01852c349c390cefa04662a850d84c0a94.html</filename>
    <templarg>class T_accumulator</templarg>
    <base>signal3&lt; T_return, T_arg1, T_arg2, T_arg3, T_accumulator &gt;</base>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01nil_00_01nil_00_01852c349c390cefa04662a850d84c0a94.html</anchorfile>
      <anchor>a86aae36f669ce2f9d7f1f0ac9a696f6c</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01nil_00_01nil_00_01852c349c390cefa04662a850d84c0a94.html</anchorfile>
      <anchor>ab20d2ddd7330aa974d61ddec753413b6</anchor>
      <arglist>(const accumulated &amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, nil, nil, nil &gt;</name>
    <filename>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01nil_00_01nil_00_01nil_01_4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <base>signal4&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, nil &gt;</base>
    <class kind="class">sigc::signal&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, nil, nil, nil &gt;::accumulated</class>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a76731fb4092ef8d9b459c8c32c5433dc</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a299bbe1b511723c6c854e516aaf0a926</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a51f9443b48b006a65114bdd18d13cd4b</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a6a5b8211c5521f8f7eba2904baecd35f</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a32c3764f4288312ad0e6113a2ae671b1</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, nil, nil, nil &gt;::accumulated</name>
    <filename>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01nil_0d729ce48b1328d982e0ee754652fed04.html</filename>
    <templarg>class T_accumulator</templarg>
    <base>signal4&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_accumulator &gt;</base>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01nil_0d729ce48b1328d982e0ee754652fed04.html</anchorfile>
      <anchor>a994494b04443cda13eef81e13321db83</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01nil_0d729ce48b1328d982e0ee754652fed04.html</anchorfile>
      <anchor>a2d21852efcef1d59cc96c8c873e6ce37</anchor>
      <arglist>(const accumulated &amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, nil, nil &gt;</name>
    <filename>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01nil_00_01nil_01_4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <base>signal5&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, nil &gt;</base>
    <class kind="class">sigc::signal&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, nil, nil &gt;::accumulated</class>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a5e64ba037f3567ab5dbb49811a447b2c</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a2f45d321526546618c56c1d5400507d2</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a3447b5d32b839fa22ac7845ea448d2b4</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>ac0dab5577f6bbc3f129fb3bcfcaa9231</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a61e3579ddc2dd7859c1884aebc733d85</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, nil, nil &gt;::accumulated</name>
    <filename>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arcf6cb51783c363bfae7c4a91d9685109.html</filename>
    <templarg>class T_accumulator</templarg>
    <base>signal5&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_accumulator &gt;</base>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arcf6cb51783c363bfae7c4a91d9685109.html</anchorfile>
      <anchor>a0b18943e223f1ae150ee5541673a2e29</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arcf6cb51783c363bfae7c4a91d9685109.html</anchorfile>
      <anchor>a3e41ce87d15bc90960abd857ca80aed9</anchor>
      <arglist>(const accumulated &amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, nil &gt;</name>
    <filename>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_00_01nil_01_4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <base>signal6&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, nil &gt;</base>
    <class kind="class">sigc::signal&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, nil &gt;::accumulated</class>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_00_01nil_01_4.html</anchorfile>
      <anchor>a1dd1e779ef29d6df2b570847c4f2819e</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_00_01nil_01_4.html</anchorfile>
      <anchor>aa070e4d37a8a06ef9fc02256d236472c</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_00_01nil_01_4.html</anchorfile>
      <anchor>a09609c04d7601601c9726aef1c74ecc7</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_00_01nil_01_4.html</anchorfile>
      <anchor>afc6e772cb628f88e8ed1a1efb2147c96</anchor>
      <arglist>(const signal &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_00_01nil_01_4.html</anchorfile>
      <anchor>aff3afec999a59d9be283fee62794dc59</anchor>
      <arglist>(signal &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::signal&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, nil &gt;::accumulated</name>
    <filename>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__are33def4d0c1a12dcbfd220489302db67.html</filename>
    <templarg>class T_accumulator</templarg>
    <base>signal6&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_accumulator &gt;</base>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__are33def4d0c1a12dcbfd220489302db67.html</anchorfile>
      <anchor>a0f2cc39e9f222a296072f8c05ad98796</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>accumulated</name>
      <anchorfile>classsigc_1_1signal_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__are33def4d0c1a12dcbfd220489302db67.html</anchorfile>
      <anchor>a239f7a4fefc7cb2cc6c4fb6c9c332d2f</anchor>
      <arglist>(const accumulated &amp;src)</arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::signal_base</name>
    <filename>structsigc_1_1signal__base.html</filename>
    <base>sigc::trackable</base>
    <member kind="typedef">
      <type>std::size_t</type>
      <name>size_type</name>
      <anchorfile>structsigc_1_1signal__base.html</anchorfile>
      <anchor>aa60e22abd088b6cde2dd50fb3f228aa4</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal_base</name>
      <anchorfile>structsigc_1_1signal__base.html</anchorfile>
      <anchor>aff65198ddcb4fbccb644ff853e663e0e</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal_base</name>
      <anchorfile>structsigc_1_1signal__base.html</anchorfile>
      <anchor>a761e95b8c7b460664d3338ed3eb39543</anchor>
      <arglist>(const signal_base &amp;src) noexcept</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>signal_base</name>
      <anchorfile>structsigc_1_1signal__base.html</anchorfile>
      <anchor>a9f8570c89cd5c0b35613570a5ea80154</anchor>
      <arglist>(signal_base &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~signal_base</name>
      <anchorfile>structsigc_1_1signal__base.html</anchorfile>
      <anchor>afa2e5807537c989b430015e5ae05a357</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>block</name>
      <anchorfile>structsigc_1_1signal__base.html</anchorfile>
      <anchor>a52fda4806ec9dbc02baa95ce70c13fb0</anchor>
      <arglist>(bool should_block=true) noexcept</arglist>
    </member>
    <member kind="function">
      <type>bool</type>
      <name>blocked</name>
      <anchorfile>structsigc_1_1signal__base.html</anchorfile>
      <anchor>a228da4dd1eac6905dafbc5697086e503</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>clear</name>
      <anchorfile>structsigc_1_1signal__base.html</anchorfile>
      <anchor>a17597d66e680d222248c523985f0afd6</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>bool</type>
      <name>empty</name>
      <anchorfile>structsigc_1_1signal__base.html</anchorfile>
      <anchor>a24e7fc4e07ac19cebafe8e3bd71bfe94</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>signal_base &amp;</type>
      <name>operator=</name>
      <anchorfile>structsigc_1_1signal__base.html</anchorfile>
      <anchor>a619e3f0f2b09946bc8b4b842bcd20b96</anchor>
      <arglist>(const signal_base &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>signal_base &amp;</type>
      <name>operator=</name>
      <anchorfile>structsigc_1_1signal__base.html</anchorfile>
      <anchor>a25f18727fa8e21611afd67757ebaec2f</anchor>
      <arglist>(signal_base &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>size_type</type>
      <name>size</name>
      <anchorfile>structsigc_1_1signal__base.html</anchorfile>
      <anchor>a0725416f747d6db3c57fa318a9f887a8</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>unblock</name>
      <anchorfile>structsigc_1_1signal__base.html</anchorfile>
      <anchor>aebb7ac69ea745cd60c0505f8d553d27f</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="typedef" protection="protected">
      <type>internal::signal_impl::iterator_type</type>
      <name>iterator_type</name>
      <anchorfile>structsigc_1_1signal__base.html</anchorfile>
      <anchor>a328b132e5dfb99dbc3aae1e5c3bb0981</anchor>
      <arglist></arglist>
    </member>
    <member kind="function" protection="protected">
      <type>iterator_type</type>
      <name>connect</name>
      <anchorfile>structsigc_1_1signal__base.html</anchorfile>
      <anchor>a5c89a76a27d69c512f554b841b1bd08a</anchor>
      <arglist>(const slot_base &amp;slot_)</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>iterator_type</type>
      <name>connect</name>
      <anchorfile>structsigc_1_1signal__base.html</anchorfile>
      <anchor>a50eab6d37728bbbf3beb21d684a72e6c</anchor>
      <arglist>(slot_base &amp;&amp;slot_)</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>iterator_type</type>
      <name>erase</name>
      <anchorfile>structsigc_1_1signal__base.html</anchorfile>
      <anchor>a21efc57eea29c3139855909ad4807984</anchor>
      <arglist>(iterator_type i)</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>internal::signal_impl *</type>
      <name>impl</name>
      <anchorfile>structsigc_1_1signal__base.html</anchorfile>
      <anchor>adade2c15a96d1698b7e24bf64e72f78a</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>iterator_type</type>
      <name>insert</name>
      <anchorfile>structsigc_1_1signal__base.html</anchorfile>
      <anchor>a87da23ad801faa9e2b6b4be2a747e757</anchor>
      <arglist>(iterator_type i, const slot_base &amp;slot_)</arglist>
    </member>
    <member kind="function" protection="protected">
      <type>iterator_type</type>
      <name>insert</name>
      <anchorfile>structsigc_1_1signal__base.html</anchorfile>
      <anchor>aa80c33868910139dd2f511afcc31b687</anchor>
      <arglist>(iterator_type i, slot_base &amp;&amp;slot_)</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>internal::signal_impl *</type>
      <name>impl_</name>
      <anchorfile>structsigc_1_1signal__base.html</anchorfile>
      <anchor>a747d448c28fd256ef580d165eb69f17a</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::slot</name>
    <filename>classsigc_1_1slot.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <templarg>class T_arg7</templarg>
    <base>slot7&lt; T_return, nil, nil, nil, nil, nil, nil, nil &gt;</base>
    <member kind="typedef">
      <type>slot7&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>parent_type</name>
      <anchorfile>classsigc_1_1slot.html</anchorfile>
      <anchor>a1966941e9654adfb3af4b994fd18a7f3</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot.html</anchorfile>
      <anchor>af643a8ef3eafd24f738224bbd6056fa3</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot.html</anchorfile>
      <anchor>ac53122c7f0f1f4dd9493e9ac88837ae2</anchor>
      <arglist>(const slot &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot.html</anchorfile>
      <anchor>ad790b9eb2c959f0f266dc94c0e84dd35</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot.html</anchorfile>
      <anchor>a445f8243e1eac20f8f925824c4acf4cf</anchor>
      <arglist>(slot &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot.html</anchorfile>
      <anchor>ae469689115f080a72c44f772fa2b7b3f</anchor>
      <arglist>(const slot &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot.html</anchorfile>
      <anchor>a4f7dd76719a63b80c6c71479d67209ab</anchor>
      <arglist>(slot &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::slot0</name>
    <filename>classsigc_1_1slot0.html</filename>
    <templarg>class T_return</templarg>
    <base>sigc::slot_base</base>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1slot0.html</anchorfile>
      <anchor>aca0c967b605e09d5a87015d95e93d4f7</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot0</name>
      <anchorfile>classsigc_1_1slot0.html</anchorfile>
      <anchor>a8681082ecd439d5b294922e4d27a3f49</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot0</name>
      <anchorfile>classsigc_1_1slot0.html</anchorfile>
      <anchor>acce9a5d9a4f939e405383092ba717f72</anchor>
      <arglist>(const slot0 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot0</name>
      <anchorfile>classsigc_1_1slot0.html</anchorfile>
      <anchor>a83a247c06b93ef644bdfe0bf119929c0</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot0</name>
      <anchorfile>classsigc_1_1slot0.html</anchorfile>
      <anchor>ac93b53e3d90df14b2b003ad0c685b160</anchor>
      <arglist>(slot0 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1slot0.html</anchorfile>
      <anchor>afa926436a4b0734f0adc2a485ccfe36a</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>slot0 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot0.html</anchorfile>
      <anchor>ab4776fb017b06c87dd3326465bd39eac</anchor>
      <arglist>(const slot0 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot0 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot0.html</anchorfile>
      <anchor>a5178e6467f5a71ebbd30853cbdccc455</anchor>
      <arglist>(slot0 &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::slot1</name>
    <filename>classsigc_1_1slot1.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <base>sigc::slot_base</base>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg1 &gt;</type>
      <name>arg1_type_</name>
      <anchorfile>classsigc_1_1slot1.html</anchorfile>
      <anchor>a4d81838957a9ccc6cb4c104706a37a89</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1slot1.html</anchorfile>
      <anchor>ab4991fe5d80761ddab482fda9ebe6d17</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot1</name>
      <anchorfile>classsigc_1_1slot1.html</anchorfile>
      <anchor>aa8ac5eadba778c11a424e255889e67f6</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot1</name>
      <anchorfile>classsigc_1_1slot1.html</anchorfile>
      <anchor>ac6ecaff0a20a57d2168ea126e565e36a</anchor>
      <arglist>(const slot1 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot1</name>
      <anchorfile>classsigc_1_1slot1.html</anchorfile>
      <anchor>a20999708c6db16a3015beca7d4ad866e</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot1</name>
      <anchorfile>classsigc_1_1slot1.html</anchorfile>
      <anchor>a4ab8f18f97f843558f11adb9d1e8e478</anchor>
      <arglist>(slot1 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1slot1.html</anchorfile>
      <anchor>ae9082daf31fdbb57da71e8c38a9ae1ab</anchor>
      <arglist>(arg1_type_ _A_a1) const</arglist>
    </member>
    <member kind="function">
      <type>slot1 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot1.html</anchorfile>
      <anchor>aae127d702069a07ee5e4d1d4acc75fd7</anchor>
      <arglist>(const slot1 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot1 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot1.html</anchorfile>
      <anchor>a81be6fbb60977deefa0317bb73114d34</anchor>
      <arglist>(slot1 &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::slot2</name>
    <filename>classsigc_1_1slot2.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <base>sigc::slot_base</base>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg1 &gt;</type>
      <name>arg1_type_</name>
      <anchorfile>classsigc_1_1slot2.html</anchorfile>
      <anchor>ae69b03a4119d61a0a521b0ad5ddaae46</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg2 &gt;</type>
      <name>arg2_type_</name>
      <anchorfile>classsigc_1_1slot2.html</anchorfile>
      <anchor>af03b1377bbfcdc742a7c00f4c2c419f7</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1slot2.html</anchorfile>
      <anchor>a0bb920e3d5628c3d01a4337a2a8a97fc</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot2</name>
      <anchorfile>classsigc_1_1slot2.html</anchorfile>
      <anchor>a3f9f6cf199bbb40011eca25eb9da67c2</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot2</name>
      <anchorfile>classsigc_1_1slot2.html</anchorfile>
      <anchor>a868deef9d947dfa4fcbb0cfe64cbd42e</anchor>
      <arglist>(const slot2 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot2</name>
      <anchorfile>classsigc_1_1slot2.html</anchorfile>
      <anchor>a14641110a8fdbb060a58c037b9000730</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot2</name>
      <anchorfile>classsigc_1_1slot2.html</anchorfile>
      <anchor>a4719ba9494f87e682b6a6d04b02413e7</anchor>
      <arglist>(slot2 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1slot2.html</anchorfile>
      <anchor>aa2abda2a910db19bbb7a2a08d867e358</anchor>
      <arglist>(arg1_type_ _A_a1, arg2_type_ _A_a2) const</arglist>
    </member>
    <member kind="function">
      <type>slot2 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot2.html</anchorfile>
      <anchor>a760b7000a990c9def29a734e544dc9d3</anchor>
      <arglist>(const slot2 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot2 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot2.html</anchorfile>
      <anchor>ad52c25741f1009fa0d5242992f622837</anchor>
      <arglist>(slot2 &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::slot3</name>
    <filename>classsigc_1_1slot3.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <base>sigc::slot_base</base>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg1 &gt;</type>
      <name>arg1_type_</name>
      <anchorfile>classsigc_1_1slot3.html</anchorfile>
      <anchor>ac6791fffc805aa2303713fea377dbaae</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg2 &gt;</type>
      <name>arg2_type_</name>
      <anchorfile>classsigc_1_1slot3.html</anchorfile>
      <anchor>a7390ac1945e87a1e0d172fe266a58d72</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg3 &gt;</type>
      <name>arg3_type_</name>
      <anchorfile>classsigc_1_1slot3.html</anchorfile>
      <anchor>a54a09bfe0dd9c518ec22cc14a7e43a23</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1slot3.html</anchorfile>
      <anchor>a69cca26f164c63de6ffa70a3806fb936</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot3</name>
      <anchorfile>classsigc_1_1slot3.html</anchorfile>
      <anchor>ac477d74beed45b2b3e26d19b083147ad</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot3</name>
      <anchorfile>classsigc_1_1slot3.html</anchorfile>
      <anchor>afa87acf0475e178f8d970bf05f84b04b</anchor>
      <arglist>(const slot3 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot3</name>
      <anchorfile>classsigc_1_1slot3.html</anchorfile>
      <anchor>aeb40907cf0589e97fd541c71e368ad03</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot3</name>
      <anchorfile>classsigc_1_1slot3.html</anchorfile>
      <anchor>a74644090c829923a4dda5e09f932d4f9</anchor>
      <arglist>(slot3 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1slot3.html</anchorfile>
      <anchor>addbe340b1f547308035707236e690e66</anchor>
      <arglist>(arg1_type_ _A_a1, arg2_type_ _A_a2, arg3_type_ _A_a3) const</arglist>
    </member>
    <member kind="function">
      <type>slot3 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot3.html</anchorfile>
      <anchor>a08be953246a4309b91720d9679d79754</anchor>
      <arglist>(const slot3 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot3 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot3.html</anchorfile>
      <anchor>af08f9e4c32e8274403096295001cb956</anchor>
      <arglist>(slot3 &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::slot4</name>
    <filename>classsigc_1_1slot4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <base>sigc::slot_base</base>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg1 &gt;</type>
      <name>arg1_type_</name>
      <anchorfile>classsigc_1_1slot4.html</anchorfile>
      <anchor>a4426d0dcf517d0d815d6add3c9490437</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg2 &gt;</type>
      <name>arg2_type_</name>
      <anchorfile>classsigc_1_1slot4.html</anchorfile>
      <anchor>abf1d276525f0120a734b2b054b9cfb3f</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg3 &gt;</type>
      <name>arg3_type_</name>
      <anchorfile>classsigc_1_1slot4.html</anchorfile>
      <anchor>ae1af3fbe3981779b68f5676f46f6085c</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg4 &gt;</type>
      <name>arg4_type_</name>
      <anchorfile>classsigc_1_1slot4.html</anchorfile>
      <anchor>aec7f4747dbe5b581c65c07033ca1bfe5</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1slot4.html</anchorfile>
      <anchor>a3f6b5b11385536c1c199ca29468c638a</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot4</name>
      <anchorfile>classsigc_1_1slot4.html</anchorfile>
      <anchor>a4b8ef0494eea86c0d787486ce121db91</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot4</name>
      <anchorfile>classsigc_1_1slot4.html</anchorfile>
      <anchor>a7b7080168e769cdec8d916f71fa58d21</anchor>
      <arglist>(const slot4 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot4</name>
      <anchorfile>classsigc_1_1slot4.html</anchorfile>
      <anchor>a50d331d378ba1f3cb03f39a42a4aa3cf</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot4</name>
      <anchorfile>classsigc_1_1slot4.html</anchorfile>
      <anchor>acf9e9b169fddb40079618f870172f535</anchor>
      <arglist>(slot4 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1slot4.html</anchorfile>
      <anchor>a02b0d861a47418b9dbf73ab7db67b0a9</anchor>
      <arglist>(arg1_type_ _A_a1, arg2_type_ _A_a2, arg3_type_ _A_a3, arg4_type_ _A_a4) const</arglist>
    </member>
    <member kind="function">
      <type>slot4 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot4.html</anchorfile>
      <anchor>aa112468d972281bff5301d042d929805</anchor>
      <arglist>(const slot4 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot4 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot4.html</anchorfile>
      <anchor>a1bf76685a7e19b965550c828a955a591</anchor>
      <arglist>(slot4 &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::slot5</name>
    <filename>classsigc_1_1slot5.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <base>sigc::slot_base</base>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg1 &gt;</type>
      <name>arg1_type_</name>
      <anchorfile>classsigc_1_1slot5.html</anchorfile>
      <anchor>aeda4706cbac7cb87a276ffeb8bdada16</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg2 &gt;</type>
      <name>arg2_type_</name>
      <anchorfile>classsigc_1_1slot5.html</anchorfile>
      <anchor>ad93d2b3cdce1c3990bde0f49693096e1</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg3 &gt;</type>
      <name>arg3_type_</name>
      <anchorfile>classsigc_1_1slot5.html</anchorfile>
      <anchor>aab17d4f2a38e02219c1a4757ba268baf</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg4 &gt;</type>
      <name>arg4_type_</name>
      <anchorfile>classsigc_1_1slot5.html</anchorfile>
      <anchor>afe7fd46dc4b01397db2c2a9c70b02735</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg5 &gt;</type>
      <name>arg5_type_</name>
      <anchorfile>classsigc_1_1slot5.html</anchorfile>
      <anchor>ade67aef04bbfd7c6af63e93afc709321</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1slot5.html</anchorfile>
      <anchor>aac50a6486dddcac3a42022a6f2189f09</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot5</name>
      <anchorfile>classsigc_1_1slot5.html</anchorfile>
      <anchor>a7548f0d175acd8296064c9bc6d76ea88</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot5</name>
      <anchorfile>classsigc_1_1slot5.html</anchorfile>
      <anchor>ad54fd2ef5f50844c214f1a5fbaef9299</anchor>
      <arglist>(const slot5 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot5</name>
      <anchorfile>classsigc_1_1slot5.html</anchorfile>
      <anchor>abcf315edb57a1a23ab7f4a0d25e57736</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot5</name>
      <anchorfile>classsigc_1_1slot5.html</anchorfile>
      <anchor>a9c7dc2f187084d174ea9f834178d491d</anchor>
      <arglist>(slot5 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1slot5.html</anchorfile>
      <anchor>a3f2d9fa2c9747d6c7fc329213446c71d</anchor>
      <arglist>(arg1_type_ _A_a1, arg2_type_ _A_a2, arg3_type_ _A_a3, arg4_type_ _A_a4, arg5_type_ _A_a5) const</arglist>
    </member>
    <member kind="function">
      <type>slot5 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot5.html</anchorfile>
      <anchor>a8a523356c1678a133e9b2c1d21647d85</anchor>
      <arglist>(const slot5 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot5 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot5.html</anchorfile>
      <anchor>a1afda319b22c0e3d96fa28a1c273461f</anchor>
      <arglist>(slot5 &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::slot6</name>
    <filename>classsigc_1_1slot6.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <base>sigc::slot_base</base>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg1 &gt;</type>
      <name>arg1_type_</name>
      <anchorfile>classsigc_1_1slot6.html</anchorfile>
      <anchor>a98240591834da17569f94410684120ba</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg2 &gt;</type>
      <name>arg2_type_</name>
      <anchorfile>classsigc_1_1slot6.html</anchorfile>
      <anchor>a44b34c5068d0150922cc630400a1962a</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg3 &gt;</type>
      <name>arg3_type_</name>
      <anchorfile>classsigc_1_1slot6.html</anchorfile>
      <anchor>a05f153d441986f23d115bf29c92736ca</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg4 &gt;</type>
      <name>arg4_type_</name>
      <anchorfile>classsigc_1_1slot6.html</anchorfile>
      <anchor>a285a8d86913eff1b27b89f4d795190c1</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg5 &gt;</type>
      <name>arg5_type_</name>
      <anchorfile>classsigc_1_1slot6.html</anchorfile>
      <anchor>a4a304a22b1a1fae56b7998ae4ae3c0e1</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg6 &gt;</type>
      <name>arg6_type_</name>
      <anchorfile>classsigc_1_1slot6.html</anchorfile>
      <anchor>ae935d9ad4042e4cfb0730e2855d7882e</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1slot6.html</anchorfile>
      <anchor>a8dae48d6160e0f917f545eb10950a9bf</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot6</name>
      <anchorfile>classsigc_1_1slot6.html</anchorfile>
      <anchor>a3c763adcaa8b9c34c808ef0f15b1fc48</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot6</name>
      <anchorfile>classsigc_1_1slot6.html</anchorfile>
      <anchor>a7e4c0f209961d3797f6fadfe9d1c6078</anchor>
      <arglist>(const slot6 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot6</name>
      <anchorfile>classsigc_1_1slot6.html</anchorfile>
      <anchor>a7458f98cd4ed4a9aa6671ea9f0c260f2</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot6</name>
      <anchorfile>classsigc_1_1slot6.html</anchorfile>
      <anchor>af7132887ca029e0325d46baa2026bea4</anchor>
      <arglist>(slot6 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1slot6.html</anchorfile>
      <anchor>ac2d6449f2928138c434c474050c7c192</anchor>
      <arglist>(arg1_type_ _A_a1, arg2_type_ _A_a2, arg3_type_ _A_a3, arg4_type_ _A_a4, arg5_type_ _A_a5, arg6_type_ _A_a6) const</arglist>
    </member>
    <member kind="function">
      <type>slot6 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot6.html</anchorfile>
      <anchor>a359940f61538bd235e78a09ad25bce25</anchor>
      <arglist>(const slot6 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot6 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot6.html</anchorfile>
      <anchor>a9e4c81c41153aa0cc75adbab49c7fe58</anchor>
      <arglist>(slot6 &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::slot7</name>
    <filename>classsigc_1_1slot7.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <templarg>class T_arg7</templarg>
    <base>sigc::slot_base</base>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg1 &gt;</type>
      <name>arg1_type_</name>
      <anchorfile>classsigc_1_1slot7.html</anchorfile>
      <anchor>a58edf93a837003d1a69fc77d39fc11a9</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg2 &gt;</type>
      <name>arg2_type_</name>
      <anchorfile>classsigc_1_1slot7.html</anchorfile>
      <anchor>ad144d8ea3ecb891d358b5b1b969be7e2</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg3 &gt;</type>
      <name>arg3_type_</name>
      <anchorfile>classsigc_1_1slot7.html</anchorfile>
      <anchor>af90cd5954008a84d6459d99de152a08c</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg4 &gt;</type>
      <name>arg4_type_</name>
      <anchorfile>classsigc_1_1slot7.html</anchorfile>
      <anchor>af42bc9af248b7c2226d93230bd7b1024</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg5 &gt;</type>
      <name>arg5_type_</name>
      <anchorfile>classsigc_1_1slot7.html</anchorfile>
      <anchor>ad6c1006a29f6fcb721bc39e8d6f82323</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg6 &gt;</type>
      <name>arg6_type_</name>
      <anchorfile>classsigc_1_1slot7.html</anchorfile>
      <anchor>ae25a8a8663addfce52415a20725a3b3e</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>type_trait_take_t&lt; T_arg7 &gt;</type>
      <name>arg7_type_</name>
      <anchorfile>classsigc_1_1slot7.html</anchorfile>
      <anchor>a2dc6c96b8d014fab9daea823188ca021</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1slot7.html</anchorfile>
      <anchor>a06a374d3304636cb48fed29542dc851f</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot7</name>
      <anchorfile>classsigc_1_1slot7.html</anchorfile>
      <anchor>abf200ae4152fb26fc96a6863be3548b8</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot7</name>
      <anchorfile>classsigc_1_1slot7.html</anchorfile>
      <anchor>a6411349bb6f8d7151f41ae7772e61f6d</anchor>
      <arglist>(const slot7 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot7</name>
      <anchorfile>classsigc_1_1slot7.html</anchorfile>
      <anchor>aa9b64dc6516b8a0d55f46e4737eaaf8b</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot7</name>
      <anchorfile>classsigc_1_1slot7.html</anchorfile>
      <anchor>a69a267bb61931f4ea039048d3221517c</anchor>
      <arglist>(slot7 &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1slot7.html</anchorfile>
      <anchor>a28e18e1a9adc88a4758be7d2497fc88d</anchor>
      <arglist>(arg1_type_ _A_a1, arg2_type_ _A_a2, arg3_type_ _A_a3, arg4_type_ _A_a4, arg5_type_ _A_a5, arg6_type_ _A_a6, arg7_type_ _A_a7) const</arglist>
    </member>
    <member kind="function">
      <type>slot7 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot7.html</anchorfile>
      <anchor>a72753c2d39444ea26677a342fd94eaba</anchor>
      <arglist>(const slot7 &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot7 &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot7.html</anchorfile>
      <anchor>a7e889d3bc36bf7b310b20a1c22dabf83</anchor>
      <arglist>(slot7 &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::slot&lt; T_return(T_arg...)&gt;</name>
    <filename>classsigc_1_1slot_3_01T__return_07T__arg_8_8_8_08_4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class... T_arg</templarg>
    <base>sigc::slot_base</base>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_07T__arg_8_8_8_08_4.html</anchorfile>
      <anchor>af593e79280c004b6ef8f4722953df0c4</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_07T__arg_8_8_8_08_4.html</anchorfile>
      <anchor>add0d65ea6dc554733e766b3510c89a3a</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_07T__arg_8_8_8_08_4.html</anchorfile>
      <anchor>ad1e5bc73a259ee666eb8d11d9e48d1d7</anchor>
      <arglist>(const slot &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_07T__arg_8_8_8_08_4.html</anchorfile>
      <anchor>a8c7a2fb604a0a9495bfa2850bb3520f5</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_07T__arg_8_8_8_08_4.html</anchorfile>
      <anchor>ae7d852d9ac2c9a6a37564a0f4aed3872</anchor>
      <arglist>(slot &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_07T__arg_8_8_8_08_4.html</anchorfile>
      <anchor>a4038d1a1c7a34bbb344b61a8f43c23f6</anchor>
      <arglist>(type_trait_take_t&lt; T_arg &gt;... _A_a) const</arglist>
    </member>
    <member kind="function">
      <type>slot &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_07T__arg_8_8_8_08_4.html</anchorfile>
      <anchor>adae83847b51d50d21c5c080cf4d789fe</anchor>
      <arglist>(const slot &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_07T__arg_8_8_8_08_4.html</anchorfile>
      <anchor>a1eeb6a2014989cdd06beafef83343596</anchor>
      <arglist>(slot &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::slot&lt; T_return, nil, nil, nil, nil, nil, nil, nil &gt;</name>
    <filename>classsigc_1_1slot_3_01T__return_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</filename>
    <templarg>class T_return</templarg>
    <base>sigc::slot0</base>
    <member kind="typedef">
      <type>slot0&lt; T_return &gt;</type>
      <name>parent_type</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a9937c7fbdb8be4e387fddcebf328fa41</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>abdb48282bb8b1b5404fcea6474eca5a5</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a9312dc3f121832083362b21334b939d2</anchor>
      <arglist>(const slot &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>ad35c264a95bfb4f29ed1fac4fda05a48</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>aaf79a4f6ed84e20f9a800daa4f625d57</anchor>
      <arglist>(slot &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a99ae753f170def0dce9ad5a2048f8d9a</anchor>
      <arglist>(const slot &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>acdb7376a2cfbec9a00c5a862e5995176</anchor>
      <arglist>(slot &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::slot&lt; T_return, T_arg1, nil, nil, nil, nil, nil, nil &gt;</name>
    <filename>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <base>sigc::slot1</base>
    <member kind="typedef">
      <type>slot1&lt; T_return, T_arg1 &gt;</type>
      <name>parent_type</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a2b6b5b8590577c765c7a32f7e619250a</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>ad34e10be904557368c241f53e972c8e7</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a2765416a5563c2d264c892aa6ab5a83c</anchor>
      <arglist>(const slot &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a5d486e3227ed5f73b791c4e202a168b4</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>ad22e5b50e474d072bb17489e9342c478</anchor>
      <arglist>(slot &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a8a9706d17e1a202dc2cad87eeb1a2dbc</anchor>
      <arglist>(const slot &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>ab072d54e7fba851565fb88047d22f7b3</anchor>
      <arglist>(slot &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::slot&lt; T_return, T_arg1, T_arg2, nil, nil, nil, nil, nil &gt;</name>
    <filename>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <base>sigc::slot2</base>
    <member kind="typedef">
      <type>slot2&lt; T_return, T_arg1, T_arg2 &gt;</type>
      <name>parent_type</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a867e776b644ca32a703866a424ae3ba5</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>aae3ba9ffc1ab8ea95ba75dd6f5753c48</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a7b7a49a2270daf31abdc237d440b21b1</anchor>
      <arglist>(const slot &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a32b5350736a34c13c5e64d3ef6f5ba84</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>ad034a7e1a5344031ee9764c063054814</anchor>
      <arglist>(slot &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a57baf211a393a5c1bcf9d05c351c065d</anchor>
      <arglist>(const slot &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01nil_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>aeb8db60ff7b42a95ef859cd2655988a4</anchor>
      <arglist>(slot &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::slot&lt; T_return, T_arg1, T_arg2, T_arg3, nil, nil, nil, nil &gt;</name>
    <filename>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <base>sigc::slot3</base>
    <member kind="typedef">
      <type>slot3&lt; T_return, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>parent_type</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>adbafac5ab39a4a017406ac9587c9511c</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>ad99678bf6a2affc9a1607046e158b22b</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a508b21923e1ef3d7d689984132d89360</anchor>
      <arglist>(const slot &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a492069e82b787edc381f4583bc1ab16d</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a0e8a890566381060e52ffbd74cc4cca4</anchor>
      <arglist>(slot &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a7dd7df07809c6f60544157820d5f2b1f</anchor>
      <arglist>(const slot &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01nil_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>aaba0e6c6ec51d1861b52073c7a4ad382</anchor>
      <arglist>(slot &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::slot&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, nil, nil, nil &gt;</name>
    <filename>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01nil_00_01nil_00_01nil_01_4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <base>sigc::slot4</base>
    <member kind="typedef">
      <type>slot4&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>parent_type</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a704393344c1ba2f6bdda9b466bb81af1</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>afb4ec5a164ca622ab9c1a97e61e9cfdc</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>afb9ff761d6f8519ea01b4fd1c254ee60</anchor>
      <arglist>(const slot &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>aa2691c7a5f59f54788db1b31d4870650</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a4e1e1ecd839575d1d928325f8882fbfb</anchor>
      <arglist>(slot &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a6a6f88cf3942320de71c312416750cc5</anchor>
      <arglist>(const slot &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01nil_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a115a991552183f768493d8055c872fab</anchor>
      <arglist>(slot &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::slot&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, nil, nil &gt;</name>
    <filename>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01nil_00_01nil_01_4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <base>sigc::slot5</base>
    <member kind="typedef">
      <type>slot5&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>parent_type</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a013f4139332e23166f7db3be6da4ba91</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a81c9e625279217aee1ae00696927c39e</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>afab26283085a050db6d75a1bfe273f86</anchor>
      <arglist>(const slot &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a8d5f076fe0207cabd9b2632382bedd89</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>aad4ab45a94e4ec0bddf66c4d88e38b0a</anchor>
      <arglist>(slot &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>ad48ab72578306dea894e2b22f110bc37</anchor>
      <arglist>(const slot &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01nil_00_01nil_01_4.html</anchorfile>
      <anchor>a9e8acc6c0a8cf9e287f9658647f2a25a</anchor>
      <arglist>(slot &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::slot&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, nil &gt;</name>
    <filename>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_00_01nil_01_4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <base>sigc::slot6</base>
    <member kind="typedef">
      <type>slot6&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>parent_type</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_00_01nil_01_4.html</anchorfile>
      <anchor>a9c9028da9fc75a10c6c396673159d471</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_00_01nil_01_4.html</anchorfile>
      <anchor>a290753f903665f059c25a4f71c9a9e16</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_00_01nil_01_4.html</anchorfile>
      <anchor>a8be1480e392dcaa57d47e1c2a132edd4</anchor>
      <arglist>(const slot &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_00_01nil_01_4.html</anchorfile>
      <anchor>ab3081b23ab4fee6191cd8a2f57ba199d</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_00_01nil_01_4.html</anchorfile>
      <anchor>a139944017d26e32ec7a347d94a1fc952</anchor>
      <arglist>(slot &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_00_01nil_01_4.html</anchorfile>
      <anchor>ab2383835a5d0865f5395d611e1d7312a</anchor>
      <arglist>(const slot &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot_3_01T__return_00_01T__arg1_00_01T__arg2_00_01T__arg3_00_01T__arg4_00_01T__arg5_00_01T__arg6_00_01nil_01_4.html</anchorfile>
      <anchor>a577c3b31dee6655b936987eef441e28a</anchor>
      <arglist>(slot &amp;&amp;src)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::slot_base</name>
    <filename>classsigc_1_1slot__base.html</filename>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>trackable::func_destroy_notify</type>
      <name>func_destroy_notify</name>
      <anchorfile>classsigc_1_1slot__base.html</anchorfile>
      <anchor>a7e1a0c2fe43a42187810e8997abeb341</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot_base</name>
      <anchorfile>classsigc_1_1slot__base.html</anchorfile>
      <anchor>a182d5db71ef371838c73bcf1c135cd9a</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot_base</name>
      <anchorfile>classsigc_1_1slot__base.html</anchorfile>
      <anchor>aadcbb54832b5207bddf89ac5433b531a</anchor>
      <arglist>(const slot_base &amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot_base</name>
      <anchorfile>classsigc_1_1slot__base.html</anchorfile>
      <anchor>a5fbc2bf38a0d9ebcbe13d578d2b3d5a1</anchor>
      <arglist>(rep_type *rep) noexcept</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot_base</name>
      <anchorfile>classsigc_1_1slot__base.html</anchorfile>
      <anchor>ad1fee67a5885e424c275ad0f48fc81b1</anchor>
      <arglist>(slot_base &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~slot_base</name>
      <anchorfile>classsigc_1_1slot__base.html</anchorfile>
      <anchor>a75c18c50860f63fb020fc2953576ea57</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>add_destroy_notify_callback</name>
      <anchorfile>classsigc_1_1slot__base.html</anchorfile>
      <anchor>a8e37cc8f4b57898a288680e59bea2694</anchor>
      <arglist>(void *data, func_destroy_notify func) const</arglist>
    </member>
    <member kind="function">
      <type>bool</type>
      <name>block</name>
      <anchorfile>classsigc_1_1slot__base.html</anchorfile>
      <anchor>a657a8473164c963a5ca4828c88121bb9</anchor>
      <arglist>(bool should_block=true) noexcept</arglist>
    </member>
    <member kind="function">
      <type>bool</type>
      <name>blocked</name>
      <anchorfile>classsigc_1_1slot__base.html</anchorfile>
      <anchor>a2f266b6147c4a6bbc5b68994d2dc1517</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>disconnect</name>
      <anchorfile>classsigc_1_1slot__base.html</anchorfile>
      <anchor>a4042d221f7f07a7394d2eb0f14db2857</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>bool</type>
      <name>empty</name>
      <anchorfile>classsigc_1_1slot__base.html</anchorfile>
      <anchor>ae6ac6ca962a1f6a7506d0817165b5cef</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>operator bool</name>
      <anchorfile>classsigc_1_1slot__base.html</anchorfile>
      <anchor>a90d4d7d6037973a94d7dfd7ba9a5feb9</anchor>
      <arglist>() const noexcept</arglist>
    </member>
    <member kind="function">
      <type>slot_base &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot__base.html</anchorfile>
      <anchor>a922d3a3c2c781a63feb88ae46dac43fb</anchor>
      <arglist>(const slot_base &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>slot_base &amp;</type>
      <name>operator=</name>
      <anchorfile>classsigc_1_1slot__base.html</anchorfile>
      <anchor>af12025359fb1218699704e558ef3c3dd</anchor>
      <arglist>(slot_base &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>remove_destroy_notify_callback</name>
      <anchorfile>classsigc_1_1slot__base.html</anchorfile>
      <anchor>a69c55dedaa35626f288754d55b3da66c</anchor>
      <arglist>(void *data) const</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>set_parent</name>
      <anchorfile>classsigc_1_1slot__base.html</anchorfile>
      <anchor>aa7d281de451d5f47923f4ff1c5b7f2c9</anchor>
      <arglist>(void *parent, void *(*cleanup)(void *)) const noexcept</arglist>
    </member>
    <member kind="function">
      <type>bool</type>
      <name>unblock</name>
      <anchorfile>classsigc_1_1slot__base.html</anchorfile>
      <anchor>a25ad0bd4d2cea4dbfcd09f7d393d266d</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="variable">
      <type>bool</type>
      <name>blocked_</name>
      <anchorfile>classsigc_1_1slot__base.html</anchorfile>
      <anchor>a9dc4958860c0f8300b461a743b7f2a2b</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>rep_type *</type>
      <name>rep_</name>
      <anchorfile>classsigc_1_1slot__base.html</anchorfile>
      <anchor>aa482f7dfc73c6950abde0fd51b3125b5</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::slot_const_iterator</name>
    <filename>structsigc_1_1slot__const__iterator.html</filename>
    <templarg>typename T_slot</templarg>
    <member kind="typedef">
      <type>std::ptrdiff_t</type>
      <name>difference_type</name>
      <anchorfile>structsigc_1_1slot__const__iterator.html</anchorfile>
      <anchor>ac111b0a48ab96f75e720f32171072bc5</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>std::bidirectional_iterator_tag</type>
      <name>iterator_category</name>
      <anchorfile>structsigc_1_1slot__const__iterator.html</anchorfile>
      <anchor>afc9dff16373a2fa7a4f373bd48a852c6</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>internal::signal_impl::const_iterator_type</type>
      <name>iterator_type</name>
      <anchorfile>structsigc_1_1slot__const__iterator.html</anchorfile>
      <anchor>a3466a35177b6a0999a12ff0ee10e91b9</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>const T_slot *</type>
      <name>pointer</name>
      <anchorfile>structsigc_1_1slot__const__iterator.html</anchorfile>
      <anchor>a28f3f0d2ac11dd8805d75682d8f38022</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>const T_slot &amp;</type>
      <name>reference</name>
      <anchorfile>structsigc_1_1slot__const__iterator.html</anchorfile>
      <anchor>a8300967b4b29096e7ad0b96db04e095a</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>std::size_t</type>
      <name>size_type</name>
      <anchorfile>structsigc_1_1slot__const__iterator.html</anchorfile>
      <anchor>adb1eeabfa619cbd9565aa0f9429ca5ed</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_slot</type>
      <name>slot_type</name>
      <anchorfile>structsigc_1_1slot__const__iterator.html</anchorfile>
      <anchor>ae377905cad9a91ca23d09877c72d82cd</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_slot</type>
      <name>value_type</name>
      <anchorfile>structsigc_1_1slot__const__iterator.html</anchorfile>
      <anchor>a20a9337066a01a137ea9945bdd509e80</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot_const_iterator</name>
      <anchorfile>structsigc_1_1slot__const__iterator.html</anchorfile>
      <anchor>a2b9e80b87a3400bb6f794c07f90d2d47</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot_const_iterator</name>
      <anchorfile>structsigc_1_1slot__const__iterator.html</anchorfile>
      <anchor>af84ef3ee54ae482534d88ac6a5b871ae</anchor>
      <arglist>(const iterator_type &amp;i)</arglist>
    </member>
    <member kind="function">
      <type>bool</type>
      <name>operator!=</name>
      <anchorfile>structsigc_1_1slot__const__iterator.html</anchorfile>
      <anchor>a0139736ee01df37af11f3551d76a2b53</anchor>
      <arglist>(const slot_const_iterator &amp;other) const</arglist>
    </member>
    <member kind="function">
      <type>reference</type>
      <name>operator*</name>
      <anchorfile>structsigc_1_1slot__const__iterator.html</anchorfile>
      <anchor>a37c9a5d5bba252e41a628bd1c87fd883</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>slot_const_iterator &amp;</type>
      <name>operator++</name>
      <anchorfile>structsigc_1_1slot__const__iterator.html</anchorfile>
      <anchor>adb4688939c5b2c86d55495274a8915fc</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>slot_const_iterator</type>
      <name>operator++</name>
      <anchorfile>structsigc_1_1slot__const__iterator.html</anchorfile>
      <anchor>aa2f7b6d4c7aa7192fca0bdcc08b74ba6</anchor>
      <arglist>(int)</arglist>
    </member>
    <member kind="function">
      <type>slot_const_iterator &amp;</type>
      <name>operator--</name>
      <anchorfile>structsigc_1_1slot__const__iterator.html</anchorfile>
      <anchor>a391e95ce095529d4b2ed4a68e3240b77</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>slot_const_iterator</type>
      <name>operator--</name>
      <anchorfile>structsigc_1_1slot__const__iterator.html</anchorfile>
      <anchor>a9ece84f63e078754915dcc6dc6ee1cc4</anchor>
      <arglist>(int)</arglist>
    </member>
    <member kind="function">
      <type>pointer</type>
      <name>operator-&gt;</name>
      <anchorfile>structsigc_1_1slot__const__iterator.html</anchorfile>
      <anchor>afd0ff56e0779787da2c7dfdb0ef4630c</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>bool</type>
      <name>operator==</name>
      <anchorfile>structsigc_1_1slot__const__iterator.html</anchorfile>
      <anchor>af88c3fcadb7ce415fcad4bd5dafad087</anchor>
      <arglist>(const slot_const_iterator &amp;other) const</arglist>
    </member>
    <member kind="variable">
      <type>iterator_type</type>
      <name>i_</name>
      <anchorfile>structsigc_1_1slot__const__iterator.html</anchorfile>
      <anchor>a5e8020f4f1c3da18fcac4c9babee306f</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::slot_iterator</name>
    <filename>structsigc_1_1slot__iterator.html</filename>
    <templarg>typename T_slot</templarg>
    <member kind="typedef">
      <type>std::ptrdiff_t</type>
      <name>difference_type</name>
      <anchorfile>structsigc_1_1slot__iterator.html</anchorfile>
      <anchor>adb6307ee06c592d67ecef0607f319d5e</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>std::bidirectional_iterator_tag</type>
      <name>iterator_category</name>
      <anchorfile>structsigc_1_1slot__iterator.html</anchorfile>
      <anchor>a0c882521b418b9faaac879a1d337ace5</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>internal::signal_impl::iterator_type</type>
      <name>iterator_type</name>
      <anchorfile>structsigc_1_1slot__iterator.html</anchorfile>
      <anchor>a189fa620b9d90dc1a224d9ad91da5011</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_slot *</type>
      <name>pointer</name>
      <anchorfile>structsigc_1_1slot__iterator.html</anchorfile>
      <anchor>afb36f2add6064e0d7e7ae63ee2ddcde9</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_slot &amp;</type>
      <name>reference</name>
      <anchorfile>structsigc_1_1slot__iterator.html</anchorfile>
      <anchor>aa3e69a557b73d817a1951af1b1767632</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>std::size_t</type>
      <name>size_type</name>
      <anchorfile>structsigc_1_1slot__iterator.html</anchorfile>
      <anchor>a1dd8ea0a80b5bb0f936833a1c2e363ed</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_slot</type>
      <name>slot_type</name>
      <anchorfile>structsigc_1_1slot__iterator.html</anchorfile>
      <anchor>af7a0ed93fca0064021d77275305e04a9</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_slot</type>
      <name>value_type</name>
      <anchorfile>structsigc_1_1slot__iterator.html</anchorfile>
      <anchor>a94f7fcbd3224e1f7e88b84f9e326b0b3</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot_iterator</name>
      <anchorfile>structsigc_1_1slot__iterator.html</anchorfile>
      <anchor>a82d4023ad9dc38dcde4cae6bf65cd8c8</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot_iterator</name>
      <anchorfile>structsigc_1_1slot__iterator.html</anchorfile>
      <anchor>a07933d72e788285673121e5ce019a260</anchor>
      <arglist>(const iterator_type &amp;i)</arglist>
    </member>
    <member kind="function">
      <type>bool</type>
      <name>operator!=</name>
      <anchorfile>structsigc_1_1slot__iterator.html</anchorfile>
      <anchor>a880c8929759eca2fc7fb55cb0c813c55</anchor>
      <arglist>(const slot_iterator &amp;other) const</arglist>
    </member>
    <member kind="function">
      <type>reference</type>
      <name>operator*</name>
      <anchorfile>structsigc_1_1slot__iterator.html</anchorfile>
      <anchor>aa01dddd6f7b4e1a726a55cd1d430f398</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>slot_iterator &amp;</type>
      <name>operator++</name>
      <anchorfile>structsigc_1_1slot__iterator.html</anchorfile>
      <anchor>aa2ec4a9825f665e0293e1b656e8a79ed</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>slot_iterator</type>
      <name>operator++</name>
      <anchorfile>structsigc_1_1slot__iterator.html</anchorfile>
      <anchor>a7469f1ad5f1802d7a04f031ee4b3e54e</anchor>
      <arglist>(int)</arglist>
    </member>
    <member kind="function">
      <type>slot_iterator &amp;</type>
      <name>operator--</name>
      <anchorfile>structsigc_1_1slot__iterator.html</anchorfile>
      <anchor>a99441c6ae4390419745a390dffc92aca</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>slot_iterator</type>
      <name>operator--</name>
      <anchorfile>structsigc_1_1slot__iterator.html</anchorfile>
      <anchor>afd2ebfa71c2df96290f2bce0746d6fa5</anchor>
      <arglist>(int)</arglist>
    </member>
    <member kind="function">
      <type>pointer</type>
      <name>operator-&gt;</name>
      <anchorfile>structsigc_1_1slot__iterator.html</anchorfile>
      <anchor>a0a77bd2eccf05cecbdf3b690c5301540</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>bool</type>
      <name>operator==</name>
      <anchorfile>structsigc_1_1slot__iterator.html</anchorfile>
      <anchor>af2b4e16f15258f6cd98f8049afd0b88d</anchor>
      <arglist>(const slot_iterator &amp;other) const</arglist>
    </member>
    <member kind="variable">
      <type>iterator_type</type>
      <name>i_</name>
      <anchorfile>structsigc_1_1slot__iterator.html</anchorfile>
      <anchor>a5e113a9e58ce7e16a11838a203b72649</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::slot_list</name>
    <filename>structsigc_1_1slot__list.html</filename>
    <templarg>class T_slot</templarg>
    <member kind="typedef">
      <type>slot_const_iterator&lt; slot_type &gt;</type>
      <name>const_iterator</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>a957838a7111e132824c10c2d5a897a0b</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>const slot_type &amp;</type>
      <name>const_reference</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>a3ac6e61271e7e8623d1bd493c61f1214</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>std::reverse_iterator&lt; const_iterator &gt;</type>
      <name>const_reverse_iterator</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>a8293bfca54539958326f57375e4d8c14</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_iterator&lt; slot_type &gt;</type>
      <name>iterator</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>a9774e07e467d9463e6e7cc7aa2f5c05f</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>slot_type &amp;</type>
      <name>reference</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>ab0f2255639f24ff02d45f97994bc0e11</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>std::reverse_iterator&lt; iterator &gt;</type>
      <name>reverse_iterator</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>addb44a7590825f917b3fcf0179fadadb</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_slot</type>
      <name>slot_type</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>af769819a62b19adb888eb231709e894f</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot_list</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>aa83ff2d263581f80f9d15d14fa31bc7a</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>slot_list</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>a5baac8e52fda5f6fc4fa31bed67077e3</anchor>
      <arglist>(internal::signal_impl *__list)</arglist>
    </member>
    <member kind="function">
      <type>reference</type>
      <name>back</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>a2b1145f2e387c041913d01b5b197f12b</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const_reference</type>
      <name>back</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>a09c5090912b6a7920269d3959e9698f4</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>iterator</type>
      <name>begin</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>ae179ec4300ddc793492bc574f6a92fec</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const_iterator</type>
      <name>begin</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>af5d0b9141e3206f2a7512e1ac4cc65fc</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>iterator</type>
      <name>end</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>affef6e4e62e4be8743c56aa8753f76d1</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const_iterator</type>
      <name>end</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>a1d5274891fad64cd2449914728b60bc1</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>iterator</type>
      <name>erase</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>a76e40607d0329865e549ac78105a5d7d</anchor>
      <arglist>(iterator first_, iterator last_)</arglist>
    </member>
    <member kind="function">
      <type>iterator</type>
      <name>erase</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>a092ed557b1519062804a41e9b527e99d</anchor>
      <arglist>(iterator i)</arglist>
    </member>
    <member kind="function">
      <type>reference</type>
      <name>front</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>abcd398b9cb6fe9506e548d121081163a</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const_reference</type>
      <name>front</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>ac44ca78cb266a8c46758b276cea151a1</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>iterator</type>
      <name>insert</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>a34c421956609463692527793e49b87ae</anchor>
      <arglist>(iterator i, const slot_type &amp;slot_)</arglist>
    </member>
    <member kind="function">
      <type>iterator</type>
      <name>insert</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>ac4e8d8b623aed063b7873b5d2e1ce5f5</anchor>
      <arglist>(iterator i, slot_type &amp;&amp;slot_)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>pop_back</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>abb28f82ef0cbc78a86a4becd61b0c9ff</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>pop_front</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>a9244005ecc265b07b7f451e63662686e</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>push_back</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>a5c7401657a6020c14616e62b20949de8</anchor>
      <arglist>(const slot_type &amp;c)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>push_back</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>a48bf437419930c92756ee3b2162d08ad</anchor>
      <arglist>(slot_type &amp;&amp;c)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>push_front</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>a5bb241c13cb363825f787ecd244ebf7d</anchor>
      <arglist>(const slot_type &amp;c)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>push_front</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>a4179f2c80be5fb65544b19b3b1d4807e</anchor>
      <arglist>(slot_type &amp;&amp;c)</arglist>
    </member>
    <member kind="function">
      <type>reverse_iterator</type>
      <name>rbegin</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>a898411734692d01a320b20a20d9e6978</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const_reverse_iterator</type>
      <name>rbegin</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>a1d4d33c9ac07a6012332d89100e8fbeb</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>reverse_iterator</type>
      <name>rend</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>ae4759ca19577b31dca5116292e7de19c</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>const_reverse_iterator</type>
      <name>rend</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>a805f74b49477673660b039576cbec20f</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>internal::signal_impl *</type>
      <name>list_</name>
      <anchorfile>structsigc_1_1slot__list.html</anchorfile>
      <anchor>a2c5b3ecf068ec93cdc34a4ae8d48313c</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::track_obj_functor1</name>
    <filename>classsigc_1_1track__obj__functor1.html</filename>
    <templarg>typename T_functor</templarg>
    <templarg>typename T_obj1</templarg>
    <base>sigc::adapts</base>
    <member kind="typedef">
      <type>adapts&lt; T_functor &gt;::adaptor_type</type>
      <name>adaptor_type</name>
      <anchorfile>classsigc_1_1track__obj__functor1.html</anchorfile>
      <anchor>ab36332c8e8815546730b525f739d9ebf</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>adaptor_type::result_type</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1track__obj__functor1.html</anchorfile>
      <anchor>a17ad87a124cb6fafc37a2d573d47f222</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>track_obj_functor1</name>
      <anchorfile>classsigc_1_1track__obj__functor1.html</anchorfile>
      <anchor>a1bcc00d3b665af8f40fa18936fab5304</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1)</arglist>
    </member>
    <member kind="function">
      <type>result_type</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1track__obj__functor1.html</anchorfile>
      <anchor>a3a4b2ca8d1c83356dcf7d5ba93051986</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1track__obj__functor1.html</anchorfile>
      <anchor>abcfec2375e2fd020b7ba6b2f309df530</anchor>
      <arglist>(T_arg1 _A_arg1)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1track__obj__functor1.html</anchorfile>
      <anchor>ae622154816b5cd57b3b48ce4c44c5903</anchor>
      <arglist>(T_arg1 _A_arg1, T_arg2 _A_arg2)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1track__obj__functor1.html</anchorfile>
      <anchor>ae14295382c51dab715057bf79b8b9725</anchor>
      <arglist>(T_arg1 _A_arg1, T_arg2 _A_arg2, T_arg3 _A_arg3)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1track__obj__functor1.html</anchorfile>
      <anchor>ab62248fe4add62eca35328601bd279e6</anchor>
      <arglist>(T_arg1 _A_arg1, T_arg2 _A_arg2, T_arg3 _A_arg3, T_arg4 _A_arg4)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1track__obj__functor1.html</anchorfile>
      <anchor>aee6fd8f4f308b803a5603300987ef05e</anchor>
      <arglist>(T_arg1 _A_arg1, T_arg2 _A_arg2, T_arg3 _A_arg3, T_arg4 _A_arg4, T_arg5 _A_arg5)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1track__obj__functor1.html</anchorfile>
      <anchor>a4979f14da623b2276505ebd5d2d3c489</anchor>
      <arglist>(T_arg1 _A_arg1, T_arg2 _A_arg2, T_arg3 _A_arg3, T_arg4 _A_arg4, T_arg5 _A_arg5, T_arg6 _A_arg6)</arglist>
    </member>
    <member kind="function">
      <type>deduce_result_type&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;::type</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1track__obj__functor1.html</anchorfile>
      <anchor>aeeae1e93e366a96fae0772275902dacc</anchor>
      <arglist>(T_arg1 _A_arg1, T_arg2 _A_arg2, T_arg3 _A_arg3, T_arg4 _A_arg4, T_arg5 _A_arg5, T_arg6 _A_arg6, T_arg7 _A_arg7)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::track_obj_functor2</name>
    <filename>classsigc_1_1track__obj__functor2.html</filename>
    <templarg>typename T_functor</templarg>
    <templarg>typename T_obj1</templarg>
    <templarg>typename T_obj2</templarg>
    <base>sigc::track_obj_functor1</base>
    <member kind="function">
      <type></type>
      <name>track_obj_functor2</name>
      <anchorfile>classsigc_1_1track__obj__functor2.html</anchorfile>
      <anchor>ae12b4c85e92a265c011fccf090fa6947</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::track_obj_functor3</name>
    <filename>classsigc_1_1track__obj__functor3.html</filename>
    <templarg>typename T_functor</templarg>
    <templarg>typename T_obj1</templarg>
    <templarg>typename T_obj2</templarg>
    <templarg>typename T_obj3</templarg>
    <base>sigc::track_obj_functor1</base>
    <member kind="function">
      <type></type>
      <name>track_obj_functor3</name>
      <anchorfile>classsigc_1_1track__obj__functor3.html</anchorfile>
      <anchor>add83622dc2ad7cd561d2c59768eea45a</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::track_obj_functor4</name>
    <filename>classsigc_1_1track__obj__functor4.html</filename>
    <templarg>typename T_functor</templarg>
    <templarg>typename T_obj1</templarg>
    <templarg>typename T_obj2</templarg>
    <templarg>typename T_obj3</templarg>
    <templarg>typename T_obj4</templarg>
    <base>sigc::track_obj_functor1</base>
    <member kind="function">
      <type></type>
      <name>track_obj_functor4</name>
      <anchorfile>classsigc_1_1track__obj__functor4.html</anchorfile>
      <anchor>a29f48beae82cf67da9b70a51da35a2e9</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3, const T_obj4 &amp;_A_obj4)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::track_obj_functor5</name>
    <filename>classsigc_1_1track__obj__functor5.html</filename>
    <templarg>typename T_functor</templarg>
    <templarg>typename T_obj1</templarg>
    <templarg>typename T_obj2</templarg>
    <templarg>typename T_obj3</templarg>
    <templarg>typename T_obj4</templarg>
    <templarg>typename T_obj5</templarg>
    <base>sigc::track_obj_functor1</base>
    <member kind="function">
      <type></type>
      <name>track_obj_functor5</name>
      <anchorfile>classsigc_1_1track__obj__functor5.html</anchorfile>
      <anchor>a1f0481289e8c48acc4cc6561c8f0c8b6</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3, const T_obj4 &amp;_A_obj4, const T_obj5 &amp;_A_obj5)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::track_obj_functor6</name>
    <filename>classsigc_1_1track__obj__functor6.html</filename>
    <templarg>typename T_functor</templarg>
    <templarg>typename T_obj1</templarg>
    <templarg>typename T_obj2</templarg>
    <templarg>typename T_obj3</templarg>
    <templarg>typename T_obj4</templarg>
    <templarg>typename T_obj5</templarg>
    <templarg>typename T_obj6</templarg>
    <base>sigc::track_obj_functor1</base>
    <member kind="function">
      <type></type>
      <name>track_obj_functor6</name>
      <anchorfile>classsigc_1_1track__obj__functor6.html</anchorfile>
      <anchor>a70b36db3f8cafb77c48269c3e4c68714</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3, const T_obj4 &amp;_A_obj4, const T_obj5 &amp;_A_obj5, const T_obj6 &amp;_A_obj6)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::track_obj_functor7</name>
    <filename>classsigc_1_1track__obj__functor7.html</filename>
    <templarg>typename T_functor</templarg>
    <templarg>typename T_obj1</templarg>
    <templarg>typename T_obj2</templarg>
    <templarg>typename T_obj3</templarg>
    <templarg>typename T_obj4</templarg>
    <templarg>typename T_obj5</templarg>
    <templarg>typename T_obj6</templarg>
    <templarg>typename T_obj7</templarg>
    <base>sigc::track_obj_functor1</base>
    <member kind="function">
      <type></type>
      <name>track_obj_functor7</name>
      <anchorfile>classsigc_1_1track__obj__functor7.html</anchorfile>
      <anchor>a77667be610a480c7afdb928533b02651</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3, const T_obj4 &amp;_A_obj4, const T_obj5 &amp;_A_obj5, const T_obj6 &amp;_A_obj6, const T_obj7 &amp;_A_obj7)</arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::trackable</name>
    <filename>structsigc_1_1trackable.html</filename>
    <member kind="typedef">
      <type>internal::func_destroy_notify</type>
      <name>func_destroy_notify</name>
      <anchorfile>structsigc_1_1trackable.html</anchorfile>
      <anchor>a3338954d7565534bd945290b798e13ed</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>trackable</name>
      <anchorfile>structsigc_1_1trackable.html</anchorfile>
      <anchor>a7e1348841e762fb41b41c6f2ce9fa073</anchor>
      <arglist>() noexcept</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>trackable</name>
      <anchorfile>structsigc_1_1trackable.html</anchorfile>
      <anchor>ac8431d9452c9698a012597e6560c72fa</anchor>
      <arglist>(const trackable &amp;src) noexcept</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>trackable</name>
      <anchorfile>structsigc_1_1trackable.html</anchorfile>
      <anchor>aba42ed8afb6598106cf68c18a7387f18</anchor>
      <arglist>(trackable &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>~trackable</name>
      <anchorfile>structsigc_1_1trackable.html</anchorfile>
      <anchor>a75587da09e30031db7a2519843f1f4fb</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>add_destroy_notify_callback</name>
      <anchorfile>structsigc_1_1trackable.html</anchorfile>
      <anchor>aed95b40846f61b4f202348c71d5913ea</anchor>
      <arglist>(void *data, func_destroy_notify func) const</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>notify_callbacks</name>
      <anchorfile>structsigc_1_1trackable.html</anchorfile>
      <anchor>af2e23cfe7adc1ca844a3350bbac557cb</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>trackable &amp;</type>
      <name>operator=</name>
      <anchorfile>structsigc_1_1trackable.html</anchorfile>
      <anchor>a4e72c35edcd1ddc421c9ae3c667e9e00</anchor>
      <arglist>(const trackable &amp;src)</arglist>
    </member>
    <member kind="function">
      <type>trackable &amp;</type>
      <name>operator=</name>
      <anchorfile>structsigc_1_1trackable.html</anchorfile>
      <anchor>a8c47321a38b15af3b90b2b66afed9dc1</anchor>
      <arglist>(trackable &amp;&amp;src)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>remove_destroy_notify_callback</name>
      <anchorfile>structsigc_1_1trackable.html</anchorfile>
      <anchor>ad1c1845ff5b356f13b32180077f83cff</anchor>
      <arglist>(void *data) const</arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::type_trait</name>
    <filename>structsigc_1_1type__trait.html</filename>
    <templarg>class T_type</templarg>
    <member kind="typedef">
      <type>T_type &amp;</type>
      <name>pass</name>
      <anchorfile>structsigc_1_1type__trait.html</anchorfile>
      <anchor>aebfa426334f8de7b93031de35d2495e3</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>const T_type &amp;</type>
      <name>take</name>
      <anchorfile>structsigc_1_1type__trait.html</anchorfile>
      <anchor>a191a797ea6e2d851287b8a87b6305157</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::type_trait&lt; const T_type &amp; &gt;</name>
    <filename>structsigc_1_1type__trait_3_01const_01T__type_01_6_01_4.html</filename>
    <templarg>class T_type</templarg>
    <member kind="typedef">
      <type>const T_type &amp;</type>
      <name>pass</name>
      <anchorfile>structsigc_1_1type__trait_3_01const_01T__type_01_6_01_4.html</anchorfile>
      <anchor>a7b9cd2a3e6e7cf986e4e25e05c665c73</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>const T_type &amp;</type>
      <name>take</name>
      <anchorfile>structsigc_1_1type__trait_3_01const_01T__type_01_6_01_4.html</anchorfile>
      <anchor>a2c3a2a62adee114867045a7f77096435</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::type_trait&lt; T_type &amp; &gt;</name>
    <filename>structsigc_1_1type__trait_3_01T__type_01_6_01_4.html</filename>
    <templarg>class T_type</templarg>
    <member kind="typedef">
      <type>T_type &amp;</type>
      <name>pass</name>
      <anchorfile>structsigc_1_1type__trait_3_01T__type_01_6_01_4.html</anchorfile>
      <anchor>a1b24e79fed94df3fc0e7574e0ae1c991</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>T_type &amp;</type>
      <name>take</name>
      <anchorfile>structsigc_1_1type__trait_3_01T__type_01_6_01_4.html</anchorfile>
      <anchor>a604c7ad05de42e3f9d28ab45c8d865b5</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::type_trait&lt; T_type[N]&gt;</name>
    <filename>structsigc_1_1type__trait_3_01T__type_0fN_0e_4.html</filename>
    <templarg>class T_type</templarg>
    <templarg>int N</templarg>
    <member kind="typedef">
      <type>T_type *&amp;</type>
      <name>pass</name>
      <anchorfile>structsigc_1_1type__trait_3_01T__type_0fN_0e_4.html</anchorfile>
      <anchor>abfd06dd56be6fda2436e9e15acb1fc72</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>const T_type *&amp;</type>
      <name>take</name>
      <anchorfile>structsigc_1_1type__trait_3_01T__type_0fN_0e_4.html</anchorfile>
      <anchor>a9cb9e2faaa68a89ef1a74b8b7c98d81e</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::type_trait&lt; void &gt;</name>
    <filename>structsigc_1_1type__trait_3_01void_01_4.html</filename>
    <member kind="typedef">
      <type>void</type>
      <name>pass</name>
      <anchorfile>structsigc_1_1type__trait_3_01void_01_4.html</anchorfile>
      <anchor>ab5d97b4ec126f3afeaf67e9a6b05b0be</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>void</type>
      <name>take</name>
      <anchorfile>structsigc_1_1type__trait_3_01void_01_4.html</anchorfile>
      <anchor>a40d187392469ee48d24838ef38531b90</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::unwrap_reference</name>
    <filename>structsigc_1_1unwrap__reference.html</filename>
    <templarg>class T_type</templarg>
    <member kind="typedef">
      <type>T_type</type>
      <name>type</name>
      <anchorfile>structsigc_1_1unwrap__reference.html</anchorfile>
      <anchor>af35cad963fc073623282a2fb9c81f02a</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::unwrap_reference&lt; const_reference_wrapper&lt; T_type &gt; &gt;</name>
    <filename>structsigc_1_1unwrap__reference_3_01const__reference__wrapper_3_01T__type_01_4_01_4.html</filename>
    <templarg>class T_type</templarg>
    <member kind="typedef">
      <type>const T_type &amp;</type>
      <name>type</name>
      <anchorfile>structsigc_1_1unwrap__reference_3_01const__reference__wrapper_3_01T__type_01_4_01_4.html</anchorfile>
      <anchor>a9820651050b0059841f9a92d9c478ba8</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::unwrap_reference&lt; reference_wrapper&lt; T_type &gt; &gt;</name>
    <filename>structsigc_1_1unwrap__reference_3_01reference__wrapper_3_01T__type_01_4_01_4.html</filename>
    <templarg>class T_type</templarg>
    <member kind="typedef">
      <type>T_type &amp;</type>
      <name>type</name>
      <anchorfile>structsigc_1_1unwrap__reference_3_01reference__wrapper_3_01T__type_01_4_01_4.html</anchorfile>
      <anchor>a25182a927492ff79290f9820f7131e58</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::unwrap_reference&lt; std::reference_wrapper&lt; T_type &gt; &gt;</name>
    <filename>structsigc_1_1unwrap__reference_3_01std_1_1reference__wrapper_3_01T__type_01_4_01_4.html</filename>
    <templarg>class T_type</templarg>
    <member kind="typedef">
      <type>T_type &amp;</type>
      <name>type</name>
      <anchorfile>structsigc_1_1unwrap__reference_3_01std_1_1reference__wrapper_3_01T__type_01_4_01_4.html</anchorfile>
      <anchor>a2a9edeecf0de1843fb4d218f68ae86c4</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>sigc::visitor</name>
    <filename>structsigc_1_1visitor.html</filename>
    <templarg>class T_functor</templarg>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>do_visit_each</name>
      <anchorfile>structsigc_1_1visitor.html</anchorfile>
      <anchor>a9fe5d6be845e622a99a0db5d3621d4b3</anchor>
      <arglist>(const T_action &amp;_A_action, const T_functor &amp;_A_functor)</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::volatile_limit_reference</name>
    <filename>classsigc_1_1volatile__limit__reference.html</filename>
    <templarg>class T_type</templarg>
    <templarg>bool I_derives_trackable</templarg>
    <member kind="function">
      <type></type>
      <name>volatile_limit_reference</name>
      <anchorfile>classsigc_1_1volatile__limit__reference.html</anchorfile>
      <anchor>acb3e6e1ecc628343f94faae718b58066</anchor>
      <arglist>(T_type &amp;_A_target)</arglist>
    </member>
    <member kind="function">
      <type>volatile T_type &amp;</type>
      <name>invoke</name>
      <anchorfile>classsigc_1_1volatile__limit__reference.html</anchorfile>
      <anchor>a7898eabf395e02b1e48cadd13a6e2c12</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>const T_type &amp;</type>
      <name>visit</name>
      <anchorfile>classsigc_1_1volatile__limit__reference.html</anchorfile>
      <anchor>a796e92794c6986e39152461c4992eeee</anchor>
      <arglist>() const</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::volatile_limit_reference&lt; T_type, true &gt;</name>
    <filename>classsigc_1_1volatile__limit__reference_3_01T__type_00_01true_01_4.html</filename>
    <templarg>class T_type</templarg>
    <member kind="function">
      <type></type>
      <name>volatile_limit_reference</name>
      <anchorfile>classsigc_1_1volatile__limit__reference_3_01T__type_00_01true_01_4.html</anchorfile>
      <anchor>aa0b69d0a82616d6db2eb86d7a041df23</anchor>
      <arglist>(T_type &amp;_A_target)</arglist>
    </member>
    <member kind="function">
      <type>volatile T_type &amp;</type>
      <name>invoke</name>
      <anchorfile>classsigc_1_1volatile__limit__reference_3_01T__type_00_01true_01_4.html</anchorfile>
      <anchor>a1149deb8e7af80cbd3507a34d18f9bd8</anchor>
      <arglist>() const</arglist>
    </member>
    <member kind="function">
      <type>const trackable &amp;</type>
      <name>visit</name>
      <anchorfile>classsigc_1_1volatile__limit__reference_3_01T__type_00_01true_01_4.html</anchorfile>
      <anchor>a06384188c8003c51f9f260ebfae07e32</anchor>
      <arglist>() const</arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::volatile_mem_functor0</name>
    <filename>classsigc_1_1volatile__mem__functor0.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1volatile__mem__functor0.html</anchorfile>
      <anchor>a2f0448d35b580f2b4884292f29b19b2f</anchor>
      <arglist>)() volatile</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1volatile__mem__functor0.html</anchorfile>
      <anchor>a41fbd67d6bbde0818b880f08f6295396</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>volatile_mem_functor0</name>
      <anchorfile>classsigc_1_1volatile__mem__functor0.html</anchorfile>
      <anchor>ae29bbe3e668b370d2788631465daa63c</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>volatile_mem_functor0</name>
      <anchorfile>classsigc_1_1volatile__mem__functor0.html</anchorfile>
      <anchor>aa4e5e279480d50940eb4b73b9c61b938</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1volatile__mem__functor0.html</anchorfile>
      <anchor>aa5df40ec8fb385594c673a07f3ff8044</anchor>
      <arglist>(T_obj &amp;_A_obj) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1volatile__mem__functor0.html</anchorfile>
      <anchor>af627ef410fac7ec5d2ee842d8f89fe51</anchor>
      <arglist>(T_obj *_A_obj) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1volatile__mem__functor0.html</anchorfile>
      <anchor>a874e91ca403b95bb085ed596257de3ec</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::volatile_mem_functor1</name>
    <filename>classsigc_1_1volatile__mem__functor1.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1volatile__mem__functor1.html</anchorfile>
      <anchor>a49228c222297c3f116b132370c3f054d</anchor>
      <arglist>)(T_arg1) volatile</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1volatile__mem__functor1.html</anchorfile>
      <anchor>a3bcbf6ae6e950d35e4ac7b33fa066877</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>volatile_mem_functor1</name>
      <anchorfile>classsigc_1_1volatile__mem__functor1.html</anchorfile>
      <anchor>a30ec3be683a2c466b23da53c8025608b</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>volatile_mem_functor1</name>
      <anchorfile>classsigc_1_1volatile__mem__functor1.html</anchorfile>
      <anchor>a86d592aee0ca1d853b64b52224054029</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1volatile__mem__functor1.html</anchorfile>
      <anchor>a98cdb61b4c623e44d5b60650098bddfd</anchor>
      <arglist>(T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1volatile__mem__functor1.html</anchorfile>
      <anchor>a69185452103c51af81b78e95504eb95c</anchor>
      <arglist>(T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1volatile__mem__functor1.html</anchorfile>
      <anchor>ad07b2821f95c27c013af4fdce527c1cb</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::volatile_mem_functor2</name>
    <filename>classsigc_1_1volatile__mem__functor2.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1volatile__mem__functor2.html</anchorfile>
      <anchor>a5faa6d84f05d64ff92e9e4ba6b8bcc1f</anchor>
      <arglist>)(T_arg1, T_arg2) volatile</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1volatile__mem__functor2.html</anchorfile>
      <anchor>a67719071ed0eacd994fa6fe300cfb24d</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>volatile_mem_functor2</name>
      <anchorfile>classsigc_1_1volatile__mem__functor2.html</anchorfile>
      <anchor>a273bbe27bc7b190d8457408cd328c1f9</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>volatile_mem_functor2</name>
      <anchorfile>classsigc_1_1volatile__mem__functor2.html</anchorfile>
      <anchor>acba5e052ebb8884ff02cab194a2f794e</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1volatile__mem__functor2.html</anchorfile>
      <anchor>a814c8abe52fa858da9f8dfbda8efafc9</anchor>
      <arglist>(T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1volatile__mem__functor2.html</anchorfile>
      <anchor>ac4c64a4812347e17744e33e5e37775d7</anchor>
      <arglist>(T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1volatile__mem__functor2.html</anchorfile>
      <anchor>aafe942fe06b2687338ea82b058412d07</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::volatile_mem_functor3</name>
    <filename>classsigc_1_1volatile__mem__functor3.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1volatile__mem__functor3.html</anchorfile>
      <anchor>aadf62624c12ef82ade8114184f0882c9</anchor>
      <arglist>)(T_arg1, T_arg2, T_arg3) volatile</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1volatile__mem__functor3.html</anchorfile>
      <anchor>a229fe43026e97bbcf80215ea8e9fa828</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>volatile_mem_functor3</name>
      <anchorfile>classsigc_1_1volatile__mem__functor3.html</anchorfile>
      <anchor>ad2319eebf06194ff516c27f581cbd7a5</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>volatile_mem_functor3</name>
      <anchorfile>classsigc_1_1volatile__mem__functor3.html</anchorfile>
      <anchor>a2364e6ab68a8128ba9e9973c66c0ce1d</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1volatile__mem__functor3.html</anchorfile>
      <anchor>ab525bf6e0a4057a4f3f8f98ff6c1bd74</anchor>
      <arglist>(T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1volatile__mem__functor3.html</anchorfile>
      <anchor>a39944451f3bb1538828e45b66f082ea0</anchor>
      <arglist>(T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1volatile__mem__functor3.html</anchorfile>
      <anchor>acf6a8aebcf4de461e03e9b994a807362</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::volatile_mem_functor4</name>
    <filename>classsigc_1_1volatile__mem__functor4.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1volatile__mem__functor4.html</anchorfile>
      <anchor>a697cad0c578cd4ba3e04f6db8a39e283</anchor>
      <arglist>)(T_arg1, T_arg2, T_arg3, T_arg4) volatile</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1volatile__mem__functor4.html</anchorfile>
      <anchor>a58dd95fa47c02a9ba6340682c7dbbcb0</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>volatile_mem_functor4</name>
      <anchorfile>classsigc_1_1volatile__mem__functor4.html</anchorfile>
      <anchor>a5ba462855081b617085e59e7566927a7</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>volatile_mem_functor4</name>
      <anchorfile>classsigc_1_1volatile__mem__functor4.html</anchorfile>
      <anchor>ab86348ff91ed7ce4cadff97c157e4024</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1volatile__mem__functor4.html</anchorfile>
      <anchor>a58491d7fd980863c7abd311624ada052</anchor>
      <arglist>(T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1volatile__mem__functor4.html</anchorfile>
      <anchor>a86a0e482790971e3674b9ba488e10127</anchor>
      <arglist>(T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1volatile__mem__functor4.html</anchorfile>
      <anchor>a176ab2202482276e79e6d71ff839c31d</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::volatile_mem_functor5</name>
    <filename>classsigc_1_1volatile__mem__functor5.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1volatile__mem__functor5.html</anchorfile>
      <anchor>a43ce719034586bbd097c823376c288ef</anchor>
      <arglist>)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5) volatile</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1volatile__mem__functor5.html</anchorfile>
      <anchor>ab647ea2e44db475cc2d4bae8be842127</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>volatile_mem_functor5</name>
      <anchorfile>classsigc_1_1volatile__mem__functor5.html</anchorfile>
      <anchor>abe1011a71cd8e78d248e072fb7d60231</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>volatile_mem_functor5</name>
      <anchorfile>classsigc_1_1volatile__mem__functor5.html</anchorfile>
      <anchor>a98e43ac4bafb96958bbbf658154794d0</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1volatile__mem__functor5.html</anchorfile>
      <anchor>a4a4b9b8ce1ce396ed9fa355ed56cf7b2</anchor>
      <arglist>(T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1volatile__mem__functor5.html</anchorfile>
      <anchor>ab6449c487e42fc9810c0f8d5a6cc243f</anchor>
      <arglist>(T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1volatile__mem__functor5.html</anchorfile>
      <anchor>a01d38ddf6e713a47199fba85fd5a8092</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::volatile_mem_functor6</name>
    <filename>classsigc_1_1volatile__mem__functor6.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1volatile__mem__functor6.html</anchorfile>
      <anchor>a67b3a13a2f595360ff6f78cb96efe9d1</anchor>
      <arglist>)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6) volatile</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1volatile__mem__functor6.html</anchorfile>
      <anchor>a1ce192c145ec5af4c826ccb2619cf002</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>volatile_mem_functor6</name>
      <anchorfile>classsigc_1_1volatile__mem__functor6.html</anchorfile>
      <anchor>a782bbd4bff8bd939a008ceb9e0511bae</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>volatile_mem_functor6</name>
      <anchorfile>classsigc_1_1volatile__mem__functor6.html</anchorfile>
      <anchor>a55c428dacaaff7f5dcd48ec02b53ed60</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1volatile__mem__functor6.html</anchorfile>
      <anchor>a2fdda8079c742fd0366c3fc057ea45e5</anchor>
      <arglist>(T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1volatile__mem__functor6.html</anchorfile>
      <anchor>a00320a319413753f756304a8db0fbf51</anchor>
      <arglist>(T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1volatile__mem__functor6.html</anchorfile>
      <anchor>aa64e5accf2702a06bffb6ed68fd95022</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="class">
    <name>sigc::volatile_mem_functor7</name>
    <filename>classsigc_1_1volatile__mem__functor7.html</filename>
    <templarg>class T_return</templarg>
    <templarg>class T_obj</templarg>
    <templarg>class T_arg1</templarg>
    <templarg>class T_arg2</templarg>
    <templarg>class T_arg3</templarg>
    <templarg>class T_arg4</templarg>
    <templarg>class T_arg5</templarg>
    <templarg>class T_arg6</templarg>
    <templarg>class T_arg7</templarg>
    <base>sigc::functor_base</base>
    <member kind="typedef">
      <type>T_return(T_obj::*</type>
      <name>function_type</name>
      <anchorfile>classsigc_1_1volatile__mem__functor7.html</anchorfile>
      <anchor>a4ee701fd029c3b7f2f3a3af1aef428a0</anchor>
      <arglist>)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7) volatile</arglist>
    </member>
    <member kind="typedef">
      <type>T_return</type>
      <name>result_type</name>
      <anchorfile>classsigc_1_1volatile__mem__functor7.html</anchorfile>
      <anchor>a4762374376dcb7b11c77372edab78823</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>volatile_mem_functor7</name>
      <anchorfile>classsigc_1_1volatile__mem__functor7.html</anchorfile>
      <anchor>a07834a50703bf92aad9bc167fa256d24</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type></type>
      <name>volatile_mem_functor7</name>
      <anchorfile>classsigc_1_1volatile__mem__functor7.html</anchorfile>
      <anchor>a809146646d2dd726a385344f455402e4</anchor>
      <arglist>(function_type _A_func)</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1volatile__mem__functor7.html</anchorfile>
      <anchor>a05ed4811582f583a1a1e11b1a8951a21</anchor>
      <arglist>(T_obj &amp;_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6, type_trait_take_t&lt; T_arg7 &gt; _A_a7) const</arglist>
    </member>
    <member kind="function">
      <type>T_return</type>
      <name>operator()</name>
      <anchorfile>classsigc_1_1volatile__mem__functor7.html</anchorfile>
      <anchor>ae587c12caf1c68886fbf001b2c8acc03</anchor>
      <arglist>(T_obj *_A_obj, type_trait_take_t&lt; T_arg1 &gt; _A_a1, type_trait_take_t&lt; T_arg2 &gt; _A_a2, type_trait_take_t&lt; T_arg3 &gt; _A_a3, type_trait_take_t&lt; T_arg4 &gt; _A_a4, type_trait_take_t&lt; T_arg5 &gt; _A_a5, type_trait_take_t&lt; T_arg6 &gt; _A_a6, type_trait_take_t&lt; T_arg7 &gt; _A_a7) const</arglist>
    </member>
    <member kind="variable" protection="protected">
      <type>function_type</type>
      <name>func_ptr_</name>
      <anchorfile>classsigc_1_1volatile__mem__functor7.html</anchorfile>
      <anchor>ac74b72d519805a654529347e4c638e6f</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="namespace">
    <name>sigc</name>
    <filename>namespacesigc.html</filename>
    <class kind="struct">sigc::adaptor_base</class>
    <class kind="struct">sigc::adaptor_functor</class>
    <class kind="struct">sigc::adaptor_trait</class>
    <class kind="struct">sigc::adaptor_trait&lt; T_functor, false &gt;</class>
    <class kind="struct">sigc::adaptor_trait&lt; T_functor, true &gt;</class>
    <class kind="struct">sigc::adapts</class>
    <class kind="struct">sigc::bind_functor</class>
    <class kind="struct">sigc::bind_functor&lt; 0, T_functor, T_bound, nil, nil, nil, nil, nil, nil &gt;</class>
    <class kind="struct">sigc::bind_functor&lt;-1, T_functor, T_type1, nil, nil, nil, nil, nil, nil &gt;</class>
    <class kind="struct">sigc::bind_return_functor</class>
    <class kind="class">sigc::bound_argument</class>
    <class kind="class">sigc::bound_argument&lt; const_reference_wrapper&lt; T_wrapped &gt; &gt;</class>
    <class kind="class">sigc::bound_argument&lt; reference_wrapper&lt; T_wrapped &gt; &gt;</class>
    <class kind="class">sigc::bound_argument&lt; std::reference_wrapper&lt; T_wrapped &gt; &gt;</class>
    <class kind="class">sigc::bound_const_mem_functor0</class>
    <class kind="class">sigc::bound_const_mem_functor1</class>
    <class kind="class">sigc::bound_const_mem_functor2</class>
    <class kind="class">sigc::bound_const_mem_functor3</class>
    <class kind="class">sigc::bound_const_mem_functor4</class>
    <class kind="class">sigc::bound_const_mem_functor5</class>
    <class kind="class">sigc::bound_const_mem_functor6</class>
    <class kind="class">sigc::bound_const_mem_functor7</class>
    <class kind="class">sigc::bound_const_volatile_mem_functor0</class>
    <class kind="class">sigc::bound_const_volatile_mem_functor1</class>
    <class kind="class">sigc::bound_const_volatile_mem_functor2</class>
    <class kind="class">sigc::bound_const_volatile_mem_functor3</class>
    <class kind="class">sigc::bound_const_volatile_mem_functor4</class>
    <class kind="class">sigc::bound_const_volatile_mem_functor5</class>
    <class kind="class">sigc::bound_const_volatile_mem_functor6</class>
    <class kind="class">sigc::bound_const_volatile_mem_functor7</class>
    <class kind="class">sigc::bound_mem_functor0</class>
    <class kind="class">sigc::bound_mem_functor1</class>
    <class kind="class">sigc::bound_mem_functor2</class>
    <class kind="class">sigc::bound_mem_functor3</class>
    <class kind="class">sigc::bound_mem_functor4</class>
    <class kind="class">sigc::bound_mem_functor5</class>
    <class kind="class">sigc::bound_mem_functor6</class>
    <class kind="class">sigc::bound_mem_functor7</class>
    <class kind="class">sigc::bound_volatile_mem_functor0</class>
    <class kind="class">sigc::bound_volatile_mem_functor1</class>
    <class kind="class">sigc::bound_volatile_mem_functor2</class>
    <class kind="class">sigc::bound_volatile_mem_functor3</class>
    <class kind="class">sigc::bound_volatile_mem_functor4</class>
    <class kind="class">sigc::bound_volatile_mem_functor5</class>
    <class kind="class">sigc::bound_volatile_mem_functor6</class>
    <class kind="class">sigc::bound_volatile_mem_functor7</class>
    <class kind="class">sigc::can_deduce_result_type_with_decltype</class>
    <class kind="struct">sigc::compose1_functor</class>
    <class kind="struct">sigc::compose2_functor</class>
    <class kind="struct">sigc::connection</class>
    <class kind="class">sigc::const_limit_reference</class>
    <class kind="class">sigc::const_limit_reference&lt; T_type, true &gt;</class>
    <class kind="class">sigc::const_mem_functor0</class>
    <class kind="class">sigc::const_mem_functor1</class>
    <class kind="class">sigc::const_mem_functor2</class>
    <class kind="class">sigc::const_mem_functor3</class>
    <class kind="class">sigc::const_mem_functor4</class>
    <class kind="class">sigc::const_mem_functor5</class>
    <class kind="class">sigc::const_mem_functor6</class>
    <class kind="class">sigc::const_mem_functor7</class>
    <class kind="struct">sigc::const_reference_wrapper</class>
    <class kind="class">sigc::const_volatile_limit_reference</class>
    <class kind="class">sigc::const_volatile_limit_reference&lt; T_type, true &gt;</class>
    <class kind="class">sigc::const_volatile_mem_functor0</class>
    <class kind="class">sigc::const_volatile_mem_functor1</class>
    <class kind="class">sigc::const_volatile_mem_functor2</class>
    <class kind="class">sigc::const_volatile_mem_functor3</class>
    <class kind="class">sigc::const_volatile_mem_functor4</class>
    <class kind="class">sigc::const_volatile_mem_functor5</class>
    <class kind="class">sigc::const_volatile_mem_functor6</class>
    <class kind="class">sigc::const_volatile_mem_functor7</class>
    <class kind="struct">sigc::deduce_result_type</class>
    <class kind="struct">sigc::exception_catch_functor</class>
    <class kind="struct">sigc::exception_catch_functor&lt; T_functor, T_catcher, void &gt;</class>
    <class kind="struct">sigc::functor_base</class>
    <class kind="struct">sigc::functor_trait</class>
    <class kind="struct">sigc::hide_functor</class>
    <class kind="struct">sigc::hide_functor&lt; 0, T_functor &gt;</class>
    <class kind="struct">sigc::hide_functor&lt;-1, T_functor &gt;</class>
    <class kind="class">sigc::limit_reference</class>
    <class kind="class">sigc::limit_reference&lt; T_type, true &gt;</class>
    <class kind="class">sigc::mem_functor0</class>
    <class kind="class">sigc::mem_functor1</class>
    <class kind="class">sigc::mem_functor2</class>
    <class kind="class">sigc::mem_functor3</class>
    <class kind="class">sigc::mem_functor4</class>
    <class kind="class">sigc::mem_functor5</class>
    <class kind="class">sigc::mem_functor6</class>
    <class kind="class">sigc::mem_functor7</class>
    <class kind="struct">sigc::nil</class>
    <class kind="class">sigc::pointer_functor0</class>
    <class kind="class">sigc::pointer_functor1</class>
    <class kind="class">sigc::pointer_functor2</class>
    <class kind="class">sigc::pointer_functor3</class>
    <class kind="class">sigc::pointer_functor4</class>
    <class kind="class">sigc::pointer_functor5</class>
    <class kind="class">sigc::pointer_functor6</class>
    <class kind="class">sigc::pointer_functor7</class>
    <class kind="struct">sigc::reference_wrapper</class>
    <class kind="struct">sigc::retype_functor</class>
    <class kind="struct">sigc::retype_return_functor</class>
    <class kind="struct">sigc::retype_return_functor&lt; void, T_functor &gt;</class>
    <class kind="class">sigc::signal</class>
    <class kind="class">sigc::signal0</class>
    <class kind="class">sigc::signal1</class>
    <class kind="class">sigc::signal2</class>
    <class kind="class">sigc::signal3</class>
    <class kind="class">sigc::signal4</class>
    <class kind="class">sigc::signal5</class>
    <class kind="class">sigc::signal6</class>
    <class kind="class">sigc::signal7</class>
    <class kind="class">sigc::signal&lt; T_return()&gt;</class>
    <class kind="class">sigc::signal&lt; T_return(T_arg1)&gt;</class>
    <class kind="class">sigc::signal&lt; T_return(T_arg1, T_arg2)&gt;</class>
    <class kind="class">sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3)&gt;</class>
    <class kind="class">sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4)&gt;</class>
    <class kind="class">sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5)&gt;</class>
    <class kind="class">sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6)&gt;</class>
    <class kind="class">sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7)&gt;</class>
    <class kind="class">sigc::signal&lt; T_return, nil, nil, nil, nil, nil, nil, nil &gt;</class>
    <class kind="class">sigc::signal&lt; T_return, T_arg1, nil, nil, nil, nil, nil, nil &gt;</class>
    <class kind="class">sigc::signal&lt; T_return, T_arg1, T_arg2, nil, nil, nil, nil, nil &gt;</class>
    <class kind="class">sigc::signal&lt; T_return, T_arg1, T_arg2, T_arg3, nil, nil, nil, nil &gt;</class>
    <class kind="class">sigc::signal&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, nil, nil, nil &gt;</class>
    <class kind="class">sigc::signal&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, nil, nil &gt;</class>
    <class kind="class">sigc::signal&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, nil &gt;</class>
    <class kind="struct">sigc::signal_base</class>
    <class kind="class">sigc::slot</class>
    <class kind="class">sigc::slot0</class>
    <class kind="class">sigc::slot1</class>
    <class kind="class">sigc::slot2</class>
    <class kind="class">sigc::slot3</class>
    <class kind="class">sigc::slot4</class>
    <class kind="class">sigc::slot5</class>
    <class kind="class">sigc::slot6</class>
    <class kind="class">sigc::slot7</class>
    <class kind="class">sigc::slot&lt; T_return(T_arg...)&gt;</class>
    <class kind="class">sigc::slot&lt; T_return, nil, nil, nil, nil, nil, nil, nil &gt;</class>
    <class kind="class">sigc::slot&lt; T_return, T_arg1, nil, nil, nil, nil, nil, nil &gt;</class>
    <class kind="class">sigc::slot&lt; T_return, T_arg1, T_arg2, nil, nil, nil, nil, nil &gt;</class>
    <class kind="class">sigc::slot&lt; T_return, T_arg1, T_arg2, T_arg3, nil, nil, nil, nil &gt;</class>
    <class kind="class">sigc::slot&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, nil, nil, nil &gt;</class>
    <class kind="class">sigc::slot&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, nil, nil &gt;</class>
    <class kind="class">sigc::slot&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, nil &gt;</class>
    <class kind="class">sigc::slot_base</class>
    <class kind="struct">sigc::slot_const_iterator</class>
    <class kind="struct">sigc::slot_iterator</class>
    <class kind="struct">sigc::slot_list</class>
    <class kind="class">sigc::track_obj_functor1</class>
    <class kind="class">sigc::track_obj_functor2</class>
    <class kind="class">sigc::track_obj_functor3</class>
    <class kind="class">sigc::track_obj_functor4</class>
    <class kind="class">sigc::track_obj_functor5</class>
    <class kind="class">sigc::track_obj_functor6</class>
    <class kind="class">sigc::track_obj_functor7</class>
    <class kind="struct">sigc::trackable</class>
    <class kind="struct">sigc::type_trait</class>
    <class kind="struct">sigc::type_trait&lt; const T_type &amp; &gt;</class>
    <class kind="struct">sigc::type_trait&lt; T_type &amp; &gt;</class>
    <class kind="struct">sigc::type_trait&lt; T_type[N]&gt;</class>
    <class kind="struct">sigc::type_trait&lt; void &gt;</class>
    <class kind="struct">sigc::unwrap_reference</class>
    <class kind="struct">sigc::unwrap_reference&lt; const_reference_wrapper&lt; T_type &gt; &gt;</class>
    <class kind="struct">sigc::unwrap_reference&lt; reference_wrapper&lt; T_type &gt; &gt;</class>
    <class kind="struct">sigc::unwrap_reference&lt; std::reference_wrapper&lt; T_type &gt; &gt;</class>
    <class kind="struct">sigc::visitor</class>
    <class kind="class">sigc::volatile_limit_reference</class>
    <class kind="class">sigc::volatile_limit_reference&lt; T_type, true &gt;</class>
    <class kind="class">sigc::volatile_mem_functor0</class>
    <class kind="class">sigc::volatile_mem_functor1</class>
    <class kind="class">sigc::volatile_mem_functor2</class>
    <class kind="class">sigc::volatile_mem_functor3</class>
    <class kind="class">sigc::volatile_mem_functor4</class>
    <class kind="class">sigc::volatile_mem_functor5</class>
    <class kind="class">sigc::volatile_mem_functor6</class>
    <class kind="class">sigc::volatile_mem_functor7</class>
    <member kind="typedef">
      <type>typename deduce_result_type&lt; T_functor, T_args... &gt;::type</type>
      <name>deduce_result_t</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ab7791439fb79592300826fe076a8e3d1</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>typename type_trait&lt; T &gt;::pass</type>
      <name>type_trait_pass_t</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>aa2d13c7fc829cfec6e0f9d5092f2aa79</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>typename type_trait&lt; T &gt;::take</type>
      <name>type_trait_take_t</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>aa0d56c61023af35c47b79db80b32fd2e</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>bind_functor&lt; I_location, T_functor, T_bound1 &gt;</type>
      <name>bind</name>
      <anchorfile>group__bind.html</anchorfile>
      <anchor>ga6a4483f74dfd17dde1eba383bcbd13d2</anchor>
      <arglist>(const T_functor &amp;_A_func, T_bound1 _A_b1)</arglist>
    </member>
    <member kind="function">
      <type>bind_functor&lt;-1, T_functor, T_type1 &gt;</type>
      <name>bind</name>
      <anchorfile>group__bind.html</anchorfile>
      <anchor>ga8f2721c1e728ba951bdbf39b2c91f19b</anchor>
      <arglist>(const T_functor &amp;_A_func, T_type1 _A_b1)</arglist>
    </member>
    <member kind="function">
      <type>bind_functor&lt;-1, T_functor, T_type1, T_type2 &gt;</type>
      <name>bind</name>
      <anchorfile>group__bind.html</anchorfile>
      <anchor>ga3b8ee8e290c68625c1df0fed0ff9cb47</anchor>
      <arglist>(const T_functor &amp;_A_func, T_type1 _A_b1, T_type2 _A_b2)</arglist>
    </member>
    <member kind="function">
      <type>bind_functor&lt;-1, T_functor, T_type1, T_type2, T_type3 &gt;</type>
      <name>bind</name>
      <anchorfile>group__bind.html</anchorfile>
      <anchor>ga99f3e6ea91c19e01a2037bb681050b3f</anchor>
      <arglist>(const T_functor &amp;_A_func, T_type1 _A_b1, T_type2 _A_b2, T_type3 _A_b3)</arglist>
    </member>
    <member kind="function">
      <type>bind_functor&lt;-1, T_functor, T_type1, T_type2, T_type3, T_type4 &gt;</type>
      <name>bind</name>
      <anchorfile>group__bind.html</anchorfile>
      <anchor>gaa2a4fed92f81a36636386bd3a9ac5767</anchor>
      <arglist>(const T_functor &amp;_A_func, T_type1 _A_b1, T_type2 _A_b2, T_type3 _A_b3, T_type4 _A_b4)</arglist>
    </member>
    <member kind="function">
      <type>bind_functor&lt;-1, T_functor, T_type1, T_type2, T_type3, T_type4, T_type5 &gt;</type>
      <name>bind</name>
      <anchorfile>group__bind.html</anchorfile>
      <anchor>gadcadd1d4d1c0f7aa790ea61cb137f804</anchor>
      <arglist>(const T_functor &amp;_A_func, T_type1 _A_b1, T_type2 _A_b2, T_type3 _A_b3, T_type4 _A_b4, T_type5 _A_b5)</arglist>
    </member>
    <member kind="function">
      <type>bind_functor&lt;-1, T_functor, T_type1, T_type2, T_type3, T_type4, T_type5, T_type6 &gt;</type>
      <name>bind</name>
      <anchorfile>group__bind.html</anchorfile>
      <anchor>ga1bfb4cf58b26450ece97b6976c9466c9</anchor>
      <arglist>(const T_functor &amp;_A_func, T_type1 _A_b1, T_type2 _A_b2, T_type3 _A_b3, T_type4 _A_b4, T_type5 _A_b5, T_type6 _A_b6)</arglist>
    </member>
    <member kind="function">
      <type>bind_functor&lt;-1, T_functor, T_type1, T_type2, T_type3, T_type4, T_type5, T_type6, T_type7 &gt;</type>
      <name>bind</name>
      <anchorfile>group__bind.html</anchorfile>
      <anchor>ga0042ca8ec8d92397e5e70303a23cabf7</anchor>
      <arglist>(const T_functor &amp;_A_func, T_type1 _A_b1, T_type2 _A_b2, T_type3 _A_b3, T_type4 _A_b4, T_type5 _A_b5, T_type6 _A_b6, T_type7 _A_b7)</arglist>
    </member>
    <member kind="function">
      <type>bind_return_functor&lt; T_return, T_functor &gt;</type>
      <name>bind_return</name>
      <anchorfile>group__bind.html</anchorfile>
      <anchor>ga91afef95024201ab106a8410580620f1</anchor>
      <arglist>(const T_functor &amp;_A_functor, T_return _A_ret_value)</arglist>
    </member>
    <member kind="function">
      <type>compose1_functor&lt; T_setter, T_getter &gt;</type>
      <name>compose</name>
      <anchorfile>group__compose.html</anchorfile>
      <anchor>ga1966bce067b6dae23be9cbba23e85f07</anchor>
      <arglist>(const T_setter &amp;_A_setter, const T_getter &amp;_A_getter)</arglist>
    </member>
    <member kind="function">
      <type>compose2_functor&lt; T_setter, T_getter1, T_getter2 &gt;</type>
      <name>compose</name>
      <anchorfile>group__compose.html</anchorfile>
      <anchor>gad8e2ea3384e03bfa708b13818280187b</anchor>
      <arglist>(const T_setter &amp;_A_setter, const T_getter1 &amp;_A_getter1, const T_getter2 &amp;_A_getter2)</arglist>
    </member>
    <member kind="function">
      <type>exception_catch_functor&lt; T_functor, T_catcher &gt;</type>
      <name>exception_catch</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>abb75f452a6b9eff0eb7901c8d4e6e6ba</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_catcher &amp;_A_catcher)</arglist>
    </member>
    <member kind="function">
      <type>hide_functor&lt; I_location, T_functor &gt;</type>
      <name>hide</name>
      <anchorfile>group__hide.html</anchorfile>
      <anchor>gad519cf7ef9a33dfa2fa8aae1a0a25724</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type>hide_functor&lt;-1, T_functor &gt;</type>
      <name>hide</name>
      <anchorfile>group__hide.html</anchorfile>
      <anchor>gaba6dc16ffd1fff394b5fde7e66d9e739</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type>retype_return_functor&lt; void, T_functor &gt;</type>
      <name>hide_return</name>
      <anchorfile>group__hide.html</anchorfile>
      <anchor>ga9880bc946be160784385419f072bf7f1</anchor>
      <arglist>(const T_functor &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga8f960f4c2577bb628f9c0de824bbad0f</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)() const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga8f960f4c2577bb628f9c0de824bbad0f</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)() const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga8f960f4c2577bb628f9c0de824bbad0f</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)() volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga8f960f4c2577bb628f9c0de824bbad0f</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)())</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga4d12cf568048e2fde93ede00c36fdd9a</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga4d12cf568048e2fde93ede00c36fdd9a</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga4d12cf568048e2fde93ede00c36fdd9a</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga4d12cf568048e2fde93ede00c36fdd9a</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga50d03ced5b627bd3fd35fa6f4ef3331d</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga50d03ced5b627bd3fd35fa6f4ef3331d</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga50d03ced5b627bd3fd35fa6f4ef3331d</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga50d03ced5b627bd3fd35fa6f4ef3331d</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga01b3775529dbc2973e1ed38434353e49</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga01b3775529dbc2973e1ed38434353e49</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga01b3775529dbc2973e1ed38434353e49</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga01b3775529dbc2973e1ed38434353e49</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga7f2ed1ad8ad5f9f5c9d9e0712158b186</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga7f2ed1ad8ad5f9f5c9d9e0712158b186</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga7f2ed1ad8ad5f9f5c9d9e0712158b186</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga7f2ed1ad8ad5f9f5c9d9e0712158b186</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga1d2cd6600ddda7532465c67ca7a580cf</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga1d2cd6600ddda7532465c67ca7a580cf</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga1d2cd6600ddda7532465c67ca7a580cf</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga1d2cd6600ddda7532465c67ca7a580cf</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga198194ed19b8a2c974803f38e85180bc</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga198194ed19b8a2c974803f38e85180bc</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga198194ed19b8a2c974803f38e85180bc</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga198194ed19b8a2c974803f38e85180bc</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gaa44d0fd38fe0aeb548a332c460e79137</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gaa44d0fd38fe0aeb548a332c460e79137</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gaa44d0fd38fe0aeb548a332c460e79137</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gaa44d0fd38fe0aeb548a332c460e79137</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga44eb0f46d4cac264278d5713b32f8b36</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)() const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga44eb0f46d4cac264278d5713b32f8b36</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)() const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga44eb0f46d4cac264278d5713b32f8b36</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)() volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga44eb0f46d4cac264278d5713b32f8b36</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)())</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga7c002e205fab59a11ec8e4ed34020f30</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga7c002e205fab59a11ec8e4ed34020f30</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga7c002e205fab59a11ec8e4ed34020f30</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga7c002e205fab59a11ec8e4ed34020f30</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga9e583e399877d83ebb80a5032f62c52f</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga9e583e399877d83ebb80a5032f62c52f</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga9e583e399877d83ebb80a5032f62c52f</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga9e583e399877d83ebb80a5032f62c52f</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gab482492cd5dbc5fd994165a910d610cc</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gab482492cd5dbc5fd994165a910d610cc</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gab482492cd5dbc5fd994165a910d610cc</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gab482492cd5dbc5fd994165a910d610cc</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gabb7c548a50269ac3953b51890aa4a288</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gabb7c548a50269ac3953b51890aa4a288</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gabb7c548a50269ac3953b51890aa4a288</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gabb7c548a50269ac3953b51890aa4a288</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gad42a2b5a9528eeef2d8ba726d52cdf3b</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gad42a2b5a9528eeef2d8ba726d52cdf3b</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gad42a2b5a9528eeef2d8ba726d52cdf3b</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gad42a2b5a9528eeef2d8ba726d52cdf3b</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga5d670848ae79674c72c16b36644d18dc</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga5d670848ae79674c72c16b36644d18dc</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga5d670848ae79674c72c16b36644d18dc</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga5d670848ae79674c72c16b36644d18dc</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gacbbd2021e83dd6f69cdcead3f1c5f247</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gacbbd2021e83dd6f69cdcead3f1c5f247</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gacbbd2021e83dd6f69cdcead3f1c5f247</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gacbbd2021e83dd6f69cdcead3f1c5f247</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7))</arglist>
    </member>
    <member kind="function">
      <type>const_volatile_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga2b3b8a62c6647a2bc50de2ae158cd55f</anchor>
      <arglist>(T_return(T_obj::*_A_func)() const volatile)</arglist>
    </member>
    <member kind="function">
      <type>const_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga2b3b8a62c6647a2bc50de2ae158cd55f</anchor>
      <arglist>(T_return(T_obj::*_A_func)() const)</arglist>
    </member>
    <member kind="function">
      <type>volatile_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga2b3b8a62c6647a2bc50de2ae158cd55f</anchor>
      <arglist>(T_return(T_obj::*_A_func)() volatile)</arglist>
    </member>
    <member kind="function">
      <type>mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga2b3b8a62c6647a2bc50de2ae158cd55f</anchor>
      <arglist>(T_return(T_obj::*_A_func)())</arglist>
    </member>
    <member kind="function">
      <type>const_volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga7e16c03f6bc7cdf99b74ed24a846d51c</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>const_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga7e16c03f6bc7cdf99b74ed24a846d51c</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1) const)</arglist>
    </member>
    <member kind="function">
      <type>volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga7e16c03f6bc7cdf99b74ed24a846d51c</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1) volatile)</arglist>
    </member>
    <member kind="function">
      <type>mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga7e16c03f6bc7cdf99b74ed24a846d51c</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1))</arglist>
    </member>
    <member kind="function">
      <type>const_volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga4e8efb035927ee7feaa5e49c9953b798</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>const_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga4e8efb035927ee7feaa5e49c9953b798</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2) const)</arglist>
    </member>
    <member kind="function">
      <type>volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga4e8efb035927ee7feaa5e49c9953b798</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2) volatile)</arglist>
    </member>
    <member kind="function">
      <type>mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga4e8efb035927ee7feaa5e49c9953b798</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2))</arglist>
    </member>
    <member kind="function">
      <type>const_volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gae64e621589894dfb515b53c3228420ea</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>const_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gae64e621589894dfb515b53c3228420ea</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3) const)</arglist>
    </member>
    <member kind="function">
      <type>volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gae64e621589894dfb515b53c3228420ea</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3) volatile)</arglist>
    </member>
    <member kind="function">
      <type>mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gae64e621589894dfb515b53c3228420ea</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3))</arglist>
    </member>
    <member kind="function">
      <type>const_volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga183417046faf41d9b39b720949e82a49</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>const_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga183417046faf41d9b39b720949e82a49</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4) const)</arglist>
    </member>
    <member kind="function">
      <type>volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga183417046faf41d9b39b720949e82a49</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4) volatile)</arglist>
    </member>
    <member kind="function">
      <type>mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga183417046faf41d9b39b720949e82a49</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4))</arglist>
    </member>
    <member kind="function">
      <type>const_volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gab7b6782977c4a8531f57ce364b1231cc</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>const_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gab7b6782977c4a8531f57ce364b1231cc</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5) const)</arglist>
    </member>
    <member kind="function">
      <type>volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gab7b6782977c4a8531f57ce364b1231cc</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5) volatile)</arglist>
    </member>
    <member kind="function">
      <type>mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gab7b6782977c4a8531f57ce364b1231cc</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5))</arglist>
    </member>
    <member kind="function">
      <type>const_volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga57eb416f3aed7d5ca0914301af3b43a6</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>const_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga57eb416f3aed7d5ca0914301af3b43a6</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6) const)</arglist>
    </member>
    <member kind="function">
      <type>volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga57eb416f3aed7d5ca0914301af3b43a6</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6) volatile)</arglist>
    </member>
    <member kind="function">
      <type>mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga57eb416f3aed7d5ca0914301af3b43a6</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6))</arglist>
    </member>
    <member kind="function">
      <type>const_volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga6f38e358bded356f993dacb180ca8de0</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>const_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga6f38e358bded356f993dacb180ca8de0</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7) const)</arglist>
    </member>
    <member kind="function">
      <type>volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga6f38e358bded356f993dacb180ca8de0</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7) volatile)</arglist>
    </member>
    <member kind="function">
      <type>mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga6f38e358bded356f993dacb180ca8de0</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun0</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gabcd290a63a4d1d74a621d6b62890aafc</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)() const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun0</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gabcd290a63a4d1d74a621d6b62890aafc</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)() const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun0</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gabcd290a63a4d1d74a621d6b62890aafc</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)() volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun0</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gabcd290a63a4d1d74a621d6b62890aafc</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)())</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun0</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga8403211d1ad6174806743c5112180d06</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)() const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun0</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga8403211d1ad6174806743c5112180d06</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)() const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun0</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga8403211d1ad6174806743c5112180d06</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)() volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun0</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga8403211d1ad6174806743c5112180d06</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)())</arglist>
    </member>
    <member kind="function">
      <type>const_volatile_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun0</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga1d68489b08628f0d2542143f56e7e00f</anchor>
      <arglist>(T_return(T_obj::*_A_func)() const volatile)</arglist>
    </member>
    <member kind="function">
      <type>const_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun0</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga1d68489b08628f0d2542143f56e7e00f</anchor>
      <arglist>(T_return(T_obj::*_A_func)() const)</arglist>
    </member>
    <member kind="function">
      <type>volatile_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun0</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga1d68489b08628f0d2542143f56e7e00f</anchor>
      <arglist>(T_return(T_obj::*_A_func)() volatile)</arglist>
    </member>
    <member kind="function">
      <type>mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun0</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga1d68489b08628f0d2542143f56e7e00f</anchor>
      <arglist>(T_return(T_obj::*_A_func)())</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun1</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gaf0dc377959a00d0551a69592553e8cb3</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun1</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gaf0dc377959a00d0551a69592553e8cb3</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun1</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gaf0dc377959a00d0551a69592553e8cb3</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun1</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gaf0dc377959a00d0551a69592553e8cb3</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun1</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gad5410c0ec2d9a82b0b5ebc6b6d1f5447</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun1</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gad5410c0ec2d9a82b0b5ebc6b6d1f5447</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun1</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gad5410c0ec2d9a82b0b5ebc6b6d1f5447</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun1</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gad5410c0ec2d9a82b0b5ebc6b6d1f5447</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1))</arglist>
    </member>
    <member kind="function">
      <type>const_volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun1</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga458299ac5e83302e3b8f1c69765296ba</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>const_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun1</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga458299ac5e83302e3b8f1c69765296ba</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1) const)</arglist>
    </member>
    <member kind="function">
      <type>volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun1</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga458299ac5e83302e3b8f1c69765296ba</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1) volatile)</arglist>
    </member>
    <member kind="function">
      <type>mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun1</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga458299ac5e83302e3b8f1c69765296ba</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun2</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga0f050df8bce7809e1ef8f6ebe285eabc</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun2</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga0f050df8bce7809e1ef8f6ebe285eabc</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun2</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga0f050df8bce7809e1ef8f6ebe285eabc</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun2</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga0f050df8bce7809e1ef8f6ebe285eabc</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun2</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gae8a9f905cfec5e68467d8011455c54c8</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun2</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gae8a9f905cfec5e68467d8011455c54c8</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun2</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gae8a9f905cfec5e68467d8011455c54c8</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun2</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gae8a9f905cfec5e68467d8011455c54c8</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2))</arglist>
    </member>
    <member kind="function">
      <type>const_volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun2</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga44470413467ca6e64e267a3d1c66a018</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>const_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun2</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga44470413467ca6e64e267a3d1c66a018</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2) const)</arglist>
    </member>
    <member kind="function">
      <type>volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun2</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga44470413467ca6e64e267a3d1c66a018</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2) volatile)</arglist>
    </member>
    <member kind="function">
      <type>mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun2</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga44470413467ca6e64e267a3d1c66a018</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun3</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga5e9fd7327451cc2cb39b336f8016cc90</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun3</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga5e9fd7327451cc2cb39b336f8016cc90</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun3</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga5e9fd7327451cc2cb39b336f8016cc90</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun3</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga5e9fd7327451cc2cb39b336f8016cc90</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun3</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga26e6bef1dac59f2d3714d55384a7c48a</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun3</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga26e6bef1dac59f2d3714d55384a7c48a</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun3</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga26e6bef1dac59f2d3714d55384a7c48a</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun3</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga26e6bef1dac59f2d3714d55384a7c48a</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3))</arglist>
    </member>
    <member kind="function">
      <type>const_volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun3</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga72b423893eeca8d87ccf8739f290e49a</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>const_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun3</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga72b423893eeca8d87ccf8739f290e49a</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3) const)</arglist>
    </member>
    <member kind="function">
      <type>volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun3</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga72b423893eeca8d87ccf8739f290e49a</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3) volatile)</arglist>
    </member>
    <member kind="function">
      <type>mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun3</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga72b423893eeca8d87ccf8739f290e49a</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun4</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga77d3bcffbfffb7157ee401fdfa29f65c</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun4</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga77d3bcffbfffb7157ee401fdfa29f65c</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun4</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga77d3bcffbfffb7157ee401fdfa29f65c</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun4</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga77d3bcffbfffb7157ee401fdfa29f65c</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun4</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gadb8e14af035457975822807adc8a4456</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun4</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gadb8e14af035457975822807adc8a4456</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun4</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gadb8e14af035457975822807adc8a4456</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun4</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gadb8e14af035457975822807adc8a4456</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4))</arglist>
    </member>
    <member kind="function">
      <type>const_volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun4</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga70955175cbfc3cb56ab42e9ceb850915</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>const_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun4</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga70955175cbfc3cb56ab42e9ceb850915</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4) const)</arglist>
    </member>
    <member kind="function">
      <type>volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun4</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga70955175cbfc3cb56ab42e9ceb850915</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4) volatile)</arglist>
    </member>
    <member kind="function">
      <type>mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun4</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga70955175cbfc3cb56ab42e9ceb850915</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun5</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gabf00f6a585635e80d6c3c36d08d8889e</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun5</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gabf00f6a585635e80d6c3c36d08d8889e</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun5</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gabf00f6a585635e80d6c3c36d08d8889e</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun5</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gabf00f6a585635e80d6c3c36d08d8889e</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun5</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gacd32aafc9510da71fedabe95109f2cee</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun5</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gacd32aafc9510da71fedabe95109f2cee</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun5</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gacd32aafc9510da71fedabe95109f2cee</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun5</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gacd32aafc9510da71fedabe95109f2cee</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5))</arglist>
    </member>
    <member kind="function">
      <type>const_volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun5</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga82fa0851f42597c6a45c387f281cd483</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>const_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun5</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga82fa0851f42597c6a45c387f281cd483</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5) const)</arglist>
    </member>
    <member kind="function">
      <type>volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun5</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga82fa0851f42597c6a45c387f281cd483</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5) volatile)</arglist>
    </member>
    <member kind="function">
      <type>mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun5</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga82fa0851f42597c6a45c387f281cd483</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun6</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga78b1c9de288f0343ba557b6b234dc4c2</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun6</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga78b1c9de288f0343ba557b6b234dc4c2</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun6</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga78b1c9de288f0343ba557b6b234dc4c2</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun6</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga78b1c9de288f0343ba557b6b234dc4c2</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun6</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gae09aae6c1dc6a67dc9856f006615f626</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun6</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gae09aae6c1dc6a67dc9856f006615f626</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun6</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gae09aae6c1dc6a67dc9856f006615f626</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun6</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gae09aae6c1dc6a67dc9856f006615f626</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6))</arglist>
    </member>
    <member kind="function">
      <type>const_volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun6</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga089c10f2cb594de94bf3803e0f72fd4a</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>const_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun6</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga089c10f2cb594de94bf3803e0f72fd4a</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6) const)</arglist>
    </member>
    <member kind="function">
      <type>volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun6</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga089c10f2cb594de94bf3803e0f72fd4a</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6) volatile)</arglist>
    </member>
    <member kind="function">
      <type>mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun6</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga089c10f2cb594de94bf3803e0f72fd4a</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun7</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gac87b0829fbd016bec8304733be343c34</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun7</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gac87b0829fbd016bec8304733be343c34</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun7</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gac87b0829fbd016bec8304733be343c34</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun7</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gac87b0829fbd016bec8304733be343c34</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7))</arglist>
    </member>
    <member kind="function">
      <type>bound_const_volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun7</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga41d027b9fdece038a473adaa3fe38ea1</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_const_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun7</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga41d027b9fdece038a473adaa3fe38ea1</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7) const)</arglist>
    </member>
    <member kind="function">
      <type>bound_volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun7</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ga41d027b9fdece038a473adaa3fe38ea1</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7) volatile)</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun7</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga41d027b9fdece038a473adaa3fe38ea1</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7))</arglist>
    </member>
    <member kind="function">
      <type>const_volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun7</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gab990e9938fbd72df93b6c9eb300f0fa0</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7) const volatile)</arglist>
    </member>
    <member kind="function">
      <type>const_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun7</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gab990e9938fbd72df93b6c9eb300f0fa0</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7) const)</arglist>
    </member>
    <member kind="function">
      <type>volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun7</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>gab990e9938fbd72df93b6c9eb300f0fa0</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7) volatile)</arglist>
    </member>
    <member kind="function">
      <type>mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun7</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gab990e9938fbd72df93b6c9eb300f0fa0</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor0&lt; T_return &gt;</type>
      <name>ptr_fun</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>gae1869c9efd259f295b5de03480a9ff5e</anchor>
      <arglist>(T_return(*_A_func)())</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor1&lt; T_arg1, T_return &gt;</type>
      <name>ptr_fun</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>gaf921a79e585a7f07d6b6534c7e9b876c</anchor>
      <arglist>(T_return(*_A_func)(T_arg1))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor2&lt; T_arg1, T_arg2, T_return &gt;</type>
      <name>ptr_fun</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>gae27faeca4107d88e0ff2ed080cb8caf0</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor3&lt; T_arg1, T_arg2, T_arg3, T_return &gt;</type>
      <name>ptr_fun</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>gaca37294a2ac5c7534749dd9a478ecf03</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2, T_arg3))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor4&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_return &gt;</type>
      <name>ptr_fun</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>gae2a1d41f416aa6ece2a53f43bd54304a</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor5&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_return &gt;</type>
      <name>ptr_fun</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>gad523fd275c0f62d95ab61e0f34a555e5</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor6&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_return &gt;</type>
      <name>ptr_fun</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>ga6ad0ac16fb241e80a83bc115efbf948c</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor7&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7, T_return &gt;</type>
      <name>ptr_fun</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>ga129df09c4e53389acb97e62ae6d52906</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor0&lt; T_return &gt;</type>
      <name>ptr_fun0</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>gabf904c882abfe02a457905355b75c042</anchor>
      <arglist>(T_return(*_A_func)())</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor1&lt; T_arg1, T_return &gt;</type>
      <name>ptr_fun1</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>ga18e42a74ffbbb8e85e2ce341a95c2d0b</anchor>
      <arglist>(T_return(*_A_func)(T_arg1))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor2&lt; T_arg1, T_arg2, T_return &gt;</type>
      <name>ptr_fun2</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>ga417a280f51a84d169f6757c0b2871edf</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor3&lt; T_arg1, T_arg2, T_arg3, T_return &gt;</type>
      <name>ptr_fun3</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>gaf5b62980add5ef6ec62dbed0d18a7629</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2, T_arg3))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor4&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_return &gt;</type>
      <name>ptr_fun4</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>ga863f3abbfbddaadaa488652537ed700e</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor5&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_return &gt;</type>
      <name>ptr_fun5</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>ga5b0e3610f3caefe1706a4e43041a0649</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor6&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_return &gt;</type>
      <name>ptr_fun6</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>ga840be9c606eb5c03b72505abe0edf829</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor7&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7, T_return &gt;</type>
      <name>ptr_fun7</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>gad190be276e741d04c364a0d4a0ead5a5</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7))</arglist>
    </member>
    <member kind="function">
      <type>const_reference_wrapper&lt; T_type &gt;</type>
      <name>ref</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>a7a0c4dcc2ae0c204250c30720365fd88</anchor>
      <arglist>(const T_type &amp;v)</arglist>
    </member>
    <member kind="function">
      <type>reference_wrapper&lt; T_type &gt;</type>
      <name>ref</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>ae1e7daca89c9093e59befaf55bd77633</anchor>
      <arglist>(T_type &amp;v)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_mem_functor0&lt; T_return, T_obj &gt; &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga6c107e595a12569af6a902641e6c902a</anchor>
      <arglist>(const bound_const_mem_functor0&lt; T_return, T_obj &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;, T_arg1 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga24ff023013c40554f918092d1f2fbd42</anchor>
      <arglist>(const bound_const_mem_functor1&lt; T_return, T_obj, T_arg1 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;, T_arg1, T_arg2 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga2ddb2e47e115accbb5d6dabce39c0ac8</anchor>
      <arglist>(const bound_const_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga63f34145eb38802ed2a7bf01e26b6dfa</anchor>
      <arglist>(const bound_const_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga17395f3e43e3b68ae63dad570e135311</anchor>
      <arglist>(const bound_const_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gac588c0330476e26c3ed05aca43834e00</anchor>
      <arglist>(const bound_const_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gaa7f28f6f24305fb91b9cac3ba496594e</anchor>
      <arglist>(const bound_const_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga25d9b0baa3ea0b49df4fe255514ae490</anchor>
      <arglist>(const bound_const_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_volatile_mem_functor0&lt; T_return, T_obj &gt; &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga1c5915b1f959006a4e48974818bfe77f</anchor>
      <arglist>(const bound_const_volatile_mem_functor0&lt; T_return, T_obj &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;, T_arg1 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga1aad7db8d6238782b66e356bcd971c10</anchor>
      <arglist>(const bound_const_volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;, T_arg1, T_arg2 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga20fe67bcf50c69672a347b1968c6d631</anchor>
      <arglist>(const bound_const_volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gacc539fe6af45742672db7e6ac55a056c</anchor>
      <arglist>(const bound_const_volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga5b5963c5dee282f1d5e53bd1ddfe9438</anchor>
      <arglist>(const bound_const_volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga2accbb2db55b8c3253507c8ebbd24199</anchor>
      <arglist>(const bound_const_volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gac0d59bd2cc9988722f02ca660d7afed8</anchor>
      <arglist>(const bound_const_volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga1c908428d78c67fd872538039040bf8c</anchor>
      <arglist>(const bound_const_volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_mem_functor0&lt; T_return, T_obj &gt; &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga49cb342890317ee70d4f202cc2a2c1c0</anchor>
      <arglist>(const bound_mem_functor0&lt; T_return, T_obj &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;, T_arg1 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gad18f526fdfde8004ed1de96bfa413657</anchor>
      <arglist>(const bound_mem_functor1&lt; T_return, T_obj, T_arg1 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;, T_arg1, T_arg2 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga4eae2106da32159768f872d5db7a15be</anchor>
      <arglist>(const bound_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gaa36f4d6bd8930fb1e217e6f664d303f9</anchor>
      <arglist>(const bound_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gae0199dadf1d100c092a5e86f69098627</anchor>
      <arglist>(const bound_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga5eed9002b7c7ac02b25a009ba698a419</anchor>
      <arglist>(const bound_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga5226ce140c12dc0e3e7adecb5cfa2c3b</anchor>
      <arglist>(const bound_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga7ccb754d4cd293cb0c6f0f181bd95358</anchor>
      <arglist>(const bound_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_volatile_mem_functor0&lt; T_return, T_obj &gt; &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga53e413a4634b0af8e1f221b98b2bcb20</anchor>
      <arglist>(const bound_volatile_mem_functor0&lt; T_return, T_obj &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;, T_arg1 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gaa7d6a32b1a591926cf93a8cb91e84007</anchor>
      <arglist>(const bound_volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;, T_arg1, T_arg2 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga513e88c64f13be9f2795e101e292958c</anchor>
      <arglist>(const bound_volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga3b5a0b5eefa94cce26bf0adcc1d4a2b5</anchor>
      <arglist>(const bound_volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga8a47bd7abd4dcdbffe7b94ddf7e6b70c</anchor>
      <arglist>(const bound_volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gad1ed361b37f183381410691872a85283</anchor>
      <arglist>(const bound_volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga12dddf97ebdf6d5a1a52d3addde70325</anchor>
      <arglist>(const bound_volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga2859a461bb17f096894e524db4d63663</anchor>
      <arglist>(const bound_volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_mem_functor0&lt; T_return, T_obj &gt; &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gaba0494c6e616362c0e642f281077d198</anchor>
      <arglist>(const const_mem_functor0&lt; T_return, T_obj &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;, T_arg1 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gaab8ab4d661417218f99527574896505a</anchor>
      <arglist>(const const_mem_functor1&lt; T_return, T_obj, T_arg1 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;, T_arg1, T_arg2 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gac60e2944abf4bbba72f5863fce332e41</anchor>
      <arglist>(const const_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gae3dd72fda7a601292b252665c14ab2c4</anchor>
      <arglist>(const const_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga7c9b86558ae7e42af45abe56d4763153</anchor>
      <arglist>(const const_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga963efe620473c3f35bd71f1f4c2b72aa</anchor>
      <arglist>(const const_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga77e01a6fa7b29f260d6f537fecf4036f</anchor>
      <arglist>(const const_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gab841aa27f8e582c1994429a3ecaa955e</anchor>
      <arglist>(const const_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_volatile_mem_functor0&lt; T_return, T_obj &gt; &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga7fbc58665a9d94300c4d7fe69440fa87</anchor>
      <arglist>(const const_volatile_mem_functor0&lt; T_return, T_obj &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;, T_arg1 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gabc956c6b66365fb3448b37e64d3044da</anchor>
      <arglist>(const const_volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;, T_arg1, T_arg2 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga951f4bb023f6bf4d8fa9424e659f90cf</anchor>
      <arglist>(const const_volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gaa7575ba0ddcfde8c8935f96e225ff2c2</anchor>
      <arglist>(const const_volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gab3680cdf3e713a87f8288d52a2f62b6a</anchor>
      <arglist>(const const_volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gaf1fb93d6705ceb5129c99354771b63da</anchor>
      <arglist>(const const_volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga54c15c7a5f756e2e4221c12380d300db</anchor>
      <arglist>(const const_volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga7599c7c81804a82b28ec25cfcf7ed73d</anchor>
      <arglist>(const const_volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; mem_functor0&lt; T_return, T_obj &gt; &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gad77a172d9515e4fd4370722cf9612ba6</anchor>
      <arglist>(const mem_functor0&lt; T_return, T_obj &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; mem_functor1&lt; T_return, T_obj, T_arg1 &gt;, T_arg1 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga0ad693c256892494042518f7e8bfc20a</anchor>
      <arglist>(const mem_functor1&lt; T_return, T_obj, T_arg1 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;, T_arg1, T_arg2 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gad8f1f6519bc9959570e9f876b439ba9b</anchor>
      <arglist>(const mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga4c08e6b6d3b399e204879a0d7b9f2b0e</anchor>
      <arglist>(const mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga3f2fddc16f94e7f3cbea037ec43ca5f0</anchor>
      <arglist>(const mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga141fb7efc6dfdb4e0614da37e385e71a</anchor>
      <arglist>(const mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga70593acca6bafad973df8f81ce57ad94</anchor>
      <arglist>(const mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gaabe7c544ba6dba7d157d9d5fa7a90098</anchor>
      <arglist>(const mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; pointer_functor0&lt; T_return &gt; &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga6fae64e7670cae5af728ab36cce1e1c2</anchor>
      <arglist>(const pointer_functor0&lt; T_return &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; pointer_functor1&lt; T_arg1, T_return &gt;, T_arg1 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga52390ed4f43b71e63f83e87422c1155b</anchor>
      <arglist>(const pointer_functor1&lt; T_arg1, T_return &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; pointer_functor2&lt; T_arg1, T_arg2, T_return &gt;, T_arg1, T_arg2 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga61096e57221b1431b97c7764e76051ba</anchor>
      <arglist>(const pointer_functor2&lt; T_arg1, T_arg2, T_return &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; pointer_functor3&lt; T_arg1, T_arg2, T_arg3, T_return &gt;, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga45666d1e9f5b684998db043562499f46</anchor>
      <arglist>(const pointer_functor3&lt; T_arg1, T_arg2, T_arg3, T_return &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; pointer_functor4&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_return &gt;, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gafef2854df9cb42b0dba9f06513bbf791</anchor>
      <arglist>(const pointer_functor4&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_return &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; pointer_functor5&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_return &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gad11b38e1d0ded72d17209f5f93fb66b5</anchor>
      <arglist>(const pointer_functor5&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_return &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; pointer_functor6&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_return &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga0c91dae5d6fae2619ae159217adfb8c9</anchor>
      <arglist>(const pointer_functor6&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_return &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; pointer_functor7&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7, T_return &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga7c8a5e03cd174de3322c065aa240ccbf</anchor>
      <arglist>(const pointer_functor7&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7, T_return &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; slot&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gaea80daa7fb16d2cac60f185667b2fe9d</anchor>
      <arglist>(const slot&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; volatile_mem_functor0&lt; T_return, T_obj &gt; &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga1412fa6dfa392e2c88688ae9ea4be29d</anchor>
      <arglist>(const volatile_mem_functor0&lt; T_return, T_obj &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;, T_arg1 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gae7074c1265efe335755f7460ba15c888</anchor>
      <arglist>(const volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;, T_arg1, T_arg2 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga7b77efe41e5a11cec979979ad666c725</anchor>
      <arglist>(const volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga93978e864006832ab18beb5d685f2310</anchor>
      <arglist>(const volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga472b34f2dd5a8d7fd4da157926339b09</anchor>
      <arglist>(const volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gae567cf66645331216794c24f559240e2</anchor>
      <arglist>(const volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gab7c39f5d6ea213acf582d2ef3a769073</anchor>
      <arglist>(const volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga9b82a4f45380ffc18d636fd390679050</anchor>
      <arglist>(const volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_return_functor&lt; T_return, T_functor &gt;</type>
      <name>retype_return</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gabf41e61ebc452f69ae1e2b5ca5a2f709</anchor>
      <arglist>(const T_functor &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor1&lt; T_functor, T_obj1 &gt;</type>
      <name>track_obj</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>gafa4f352697149bbb860efc861be9f18b</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor2&lt; T_functor, T_obj1, T_obj2 &gt;</type>
      <name>track_obj</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>ga3aae882d4a72d5971c1b76a4c5d4c601</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor3&lt; T_functor, T_obj1, T_obj2, T_obj3 &gt;</type>
      <name>track_obj</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>gab501e266973ce3bdec7539a29f1b17de</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor4&lt; T_functor, T_obj1, T_obj2, T_obj3, T_obj4 &gt;</type>
      <name>track_obj</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>ga1fec4c6c5c92bbb3563fe14928e2b883</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3, const T_obj4 &amp;_A_obj4)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor5&lt; T_functor, T_obj1, T_obj2, T_obj3, T_obj4, T_obj5 &gt;</type>
      <name>track_obj</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>gacce53cf8c90e95add5dc77072d64cc8f</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3, const T_obj4 &amp;_A_obj4, const T_obj5 &amp;_A_obj5)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor6&lt; T_functor, T_obj1, T_obj2, T_obj3, T_obj4, T_obj5, T_obj6 &gt;</type>
      <name>track_obj</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>gaf6e22889485abeb6adb12b916d301f8d</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3, const T_obj4 &amp;_A_obj4, const T_obj5 &amp;_A_obj5, const T_obj6 &amp;_A_obj6)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor7&lt; T_functor, T_obj1, T_obj2, T_obj3, T_obj4, T_obj5, T_obj6, T_obj7 &gt;</type>
      <name>track_obj</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>ga72c2b62068e0c155cdf1911e28d97ebe</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3, const T_obj4 &amp;_A_obj4, const T_obj5 &amp;_A_obj5, const T_obj6 &amp;_A_obj6, const T_obj7 &amp;_A_obj7)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor1&lt; T_functor, T_obj1 &gt;</type>
      <name>track_object</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>gad00ec458bb4f9fa469cf8b7f10ec8e61</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor2&lt; T_functor, T_obj1, T_obj2 &gt;</type>
      <name>track_object</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>ga29034b19a0b58d05f0cd3cd8cf5c3fec</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor3&lt; T_functor, T_obj1, T_obj2, T_obj3 &gt;</type>
      <name>track_object</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>gab17bbb108f387c479fac94a6578eead5</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor4&lt; T_functor, T_obj1, T_obj2, T_obj3, T_obj4 &gt;</type>
      <name>track_object</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>ga684acf3428fd736fde4c2e77b10c6ea7</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3, const T_obj4 &amp;_A_obj4)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor5&lt; T_functor, T_obj1, T_obj2, T_obj3, T_obj4, T_obj5 &gt;</type>
      <name>track_object</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>gae79aa5c80594ab406619492d167b27f4</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3, const T_obj4 &amp;_A_obj4, const T_obj5 &amp;_A_obj5)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor6&lt; T_functor, T_obj1, T_obj2, T_obj3, T_obj4, T_obj5, T_obj6 &gt;</type>
      <name>track_object</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>gab7768b7b8f18afa47ecd3b1f7c252659</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3, const T_obj4 &amp;_A_obj4, const T_obj5 &amp;_A_obj5, const T_obj6 &amp;_A_obj6)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor7&lt; T_functor, T_obj1, T_obj2, T_obj3, T_obj4, T_obj5, T_obj6, T_obj7 &gt;</type>
      <name>track_object</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>ga9290af1906e1532d0827cd7dcf0dc3ae</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3, const T_obj4 &amp;_A_obj4, const T_obj5 &amp;_A_obj5, const T_obj6 &amp;_A_obj6, const T_obj7 &amp;_A_obj7)</arglist>
    </member>
    <member kind="function">
      <type>const T_type &amp;</type>
      <name>unwrap</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>a723638769645e585299f9162a4f8251b</anchor>
      <arglist>(const const_reference_wrapper&lt; T_type &gt; &amp;v)</arglist>
    </member>
    <member kind="function">
      <type>T_type &amp;</type>
      <name>unwrap</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>a4f3591b8c04cc4ec6c2348f256201c5a</anchor>
      <arglist>(const reference_wrapper&lt; T_type &gt; &amp;v)</arglist>
    </member>
    <member kind="function">
      <type>T_type &amp;</type>
      <name>unwrap</name>
      <anchorfile>namespacesigc.html</anchorfile>
      <anchor>a640a579a99e9159dfe9b85a717210f68</anchor>
      <arglist>(const std::reference_wrapper&lt; T_type &gt; &amp;v)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>visit_each</name>
      <anchorfile>group__sigcfunctors.html</anchorfile>
      <anchor>ga64cb7832acc1e58efb5ffe0b4f5e9404</anchor>
      <arglist>(const T_action &amp;_A_action, const T_functor &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>visit_each_type</name>
      <anchorfile>group__sigcfunctors.html</anchorfile>
      <anchor>gada222d975b87d64cfa7a7f29244ae587</anchor>
      <arglist>(const T_action &amp;_A_action, const T_functor &amp;_A_functor)</arglist>
    </member>
  </compound>
  <compound kind="group">
    <name>adaptors</name>
    <title>Adaptors</title>
    <filename>group__adaptors.html</filename>
    <subgroup>bind</subgroup>
    <subgroup>compose</subgroup>
    <subgroup>exception_catch</subgroup>
    <subgroup>hide</subgroup>
    <subgroup>retype</subgroup>
    <subgroup>track_obj</subgroup>
    <class kind="struct">sigc::adaptor_base</class>
    <class kind="struct">sigc::adaptor_functor</class>
    <class kind="struct">sigc::adaptor_trait</class>
    <class kind="struct">sigc::adapts</class>
    <class kind="struct">sigc::deduce_result_type</class>
  </compound>
  <compound kind="group">
    <name>sigcfunctors</name>
    <title>Functors</title>
    <filename>group__sigcfunctors.html</filename>
    <subgroup>slot</subgroup>
    <subgroup>mem_fun</subgroup>
    <subgroup>ptr_fun</subgroup>
    <class kind="class">sigc::can_deduce_result_type_with_decltype</class>
    <class kind="struct">sigc::functor_base</class>
    <class kind="struct">sigc::functor_trait</class>
    <class kind="struct">sigc::visitor</class>
    <member kind="define">
      <type>#define</type>
      <name>SIGC_FUNCTOR_TRAIT</name>
      <anchorfile>group__sigcfunctors.html</anchorfile>
      <anchor>ga7a6f5575dc0b0ea896889c782721f6be</anchor>
      <arglist>(T_functor, T_return)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>SIGC_FUNCTORS_DEDUCE_RESULT_TYPE_WITH_DECLTYPE</name>
      <anchorfile>group__sigcfunctors.html</anchorfile>
      <anchor>gadf1ba3cacb09cc5c3c3e399836ec6e50</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>SIGC_FUNCTORS_HAVE_RESULT_TYPE</name>
      <anchorfile>group__sigcfunctors.html</anchorfile>
      <anchor>ga93b6ee8815d90adccfdceed72bcda577</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>visit_each</name>
      <anchorfile>group__sigcfunctors.html</anchorfile>
      <anchor>ga64cb7832acc1e58efb5ffe0b4f5e9404</anchor>
      <arglist>(const T_action &amp;_A_action, const T_functor &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>visit_each_type</name>
      <anchorfile>group__sigcfunctors.html</anchorfile>
      <anchor>gada222d975b87d64cfa7a7f29244ae587</anchor>
      <arglist>(const T_action &amp;_A_action, const T_functor &amp;_A_functor)</arglist>
    </member>
  </compound>
  <compound kind="group">
    <name>signal</name>
    <title>Signals</title>
    <filename>group__signal.html</filename>
    <class kind="struct">sigc::connection</class>
    <class kind="struct">sigc::nil</class>
    <class kind="class">sigc::signal</class>
    <class kind="class">sigc::signal0</class>
    <class kind="class">sigc::signal1</class>
    <class kind="class">sigc::signal2</class>
    <class kind="class">sigc::signal3</class>
    <class kind="class">sigc::signal4</class>
    <class kind="class">sigc::signal5</class>
    <class kind="class">sigc::signal6</class>
    <class kind="class">sigc::signal7</class>
    <class kind="class">sigc::signal::accumulated</class>
    <class kind="class">sigc::signal&lt; T_return()&gt;</class>
    <class kind="class">sigc::signal&lt; T_return(T_arg1)&gt;</class>
    <class kind="class">sigc::signal&lt; T_return(T_arg1, T_arg2)&gt;</class>
    <class kind="class">sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3)&gt;</class>
    <class kind="class">sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4)&gt;</class>
    <class kind="class">sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5)&gt;</class>
    <class kind="class">sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6)&gt;</class>
    <class kind="class">sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7)&gt;</class>
    <class kind="class">sigc::signal&lt; T_return(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7)&gt;::accumulated</class>
    <class kind="struct">sigc::signal_base</class>
    <class kind="struct">sigc::slot_const_iterator</class>
    <class kind="struct">sigc::slot_iterator</class>
    <class kind="struct">sigc::slot_list</class>
    <class kind="struct">sigc::trackable</class>
  </compound>
  <compound kind="group">
    <name>slot</name>
    <title>Slots</title>
    <filename>group__slot.html</filename>
    <class kind="struct">sigc::nil</class>
    <class kind="class">sigc::slot</class>
    <class kind="class">sigc::slot0</class>
    <class kind="class">sigc::slot1</class>
    <class kind="class">sigc::slot2</class>
    <class kind="class">sigc::slot3</class>
    <class kind="class">sigc::slot4</class>
    <class kind="class">sigc::slot5</class>
    <class kind="class">sigc::slot6</class>
    <class kind="class">sigc::slot7</class>
    <class kind="class">sigc::slot&lt; T_return(T_arg...)&gt;</class>
    <class kind="class">sigc::slot_base</class>
    <docanchor file="group__slot.html" title="Creating Slots">slots-creating</docanchor>
    <docanchor file="group__slot.html" title="Member Methods and Automatic Disconnection">slots-auto-disconnect</docanchor>
    <docanchor file="group__slot.html" title="auto">slots-auto</docanchor>
    <docanchor file="group__slot.html" title="C++ Lambdas">slots-with-lambdas</docanchor>
  </compound>
  <compound kind="group">
    <name>bind</name>
    <title>bind(), bind_return()</title>
    <filename>group__bind.html</filename>
    <class kind="struct">sigc::bind_functor</class>
    <class kind="struct">sigc::bind_functor&lt; 0, T_functor, T_bound, nil, nil, nil, nil, nil, nil &gt;</class>
    <class kind="struct">sigc::bind_functor&lt;-1, T_functor, T_type1, nil, nil, nil, nil, nil, nil &gt;</class>
    <class kind="struct">sigc::bind_return_functor</class>
    <member kind="function">
      <type>bind_functor&lt; I_location, T_functor, T_bound1 &gt;</type>
      <name>bind</name>
      <anchorfile>group__bind.html</anchorfile>
      <anchor>ga6a4483f74dfd17dde1eba383bcbd13d2</anchor>
      <arglist>(const T_functor &amp;_A_func, T_bound1 _A_b1)</arglist>
    </member>
    <member kind="function">
      <type>bind_functor&lt;-1, T_functor, T_type1 &gt;</type>
      <name>bind</name>
      <anchorfile>group__bind.html</anchorfile>
      <anchor>ga8f2721c1e728ba951bdbf39b2c91f19b</anchor>
      <arglist>(const T_functor &amp;_A_func, T_type1 _A_b1)</arglist>
    </member>
    <member kind="function">
      <type>bind_functor&lt;-1, T_functor, T_type1, T_type2 &gt;</type>
      <name>bind</name>
      <anchorfile>group__bind.html</anchorfile>
      <anchor>ga3b8ee8e290c68625c1df0fed0ff9cb47</anchor>
      <arglist>(const T_functor &amp;_A_func, T_type1 _A_b1, T_type2 _A_b2)</arglist>
    </member>
    <member kind="function">
      <type>bind_functor&lt;-1, T_functor, T_type1, T_type2, T_type3 &gt;</type>
      <name>bind</name>
      <anchorfile>group__bind.html</anchorfile>
      <anchor>ga99f3e6ea91c19e01a2037bb681050b3f</anchor>
      <arglist>(const T_functor &amp;_A_func, T_type1 _A_b1, T_type2 _A_b2, T_type3 _A_b3)</arglist>
    </member>
    <member kind="function">
      <type>bind_functor&lt;-1, T_functor, T_type1, T_type2, T_type3, T_type4 &gt;</type>
      <name>bind</name>
      <anchorfile>group__bind.html</anchorfile>
      <anchor>gaa2a4fed92f81a36636386bd3a9ac5767</anchor>
      <arglist>(const T_functor &amp;_A_func, T_type1 _A_b1, T_type2 _A_b2, T_type3 _A_b3, T_type4 _A_b4)</arglist>
    </member>
    <member kind="function">
      <type>bind_functor&lt;-1, T_functor, T_type1, T_type2, T_type3, T_type4, T_type5 &gt;</type>
      <name>bind</name>
      <anchorfile>group__bind.html</anchorfile>
      <anchor>gadcadd1d4d1c0f7aa790ea61cb137f804</anchor>
      <arglist>(const T_functor &amp;_A_func, T_type1 _A_b1, T_type2 _A_b2, T_type3 _A_b3, T_type4 _A_b4, T_type5 _A_b5)</arglist>
    </member>
    <member kind="function">
      <type>bind_functor&lt;-1, T_functor, T_type1, T_type2, T_type3, T_type4, T_type5, T_type6 &gt;</type>
      <name>bind</name>
      <anchorfile>group__bind.html</anchorfile>
      <anchor>ga1bfb4cf58b26450ece97b6976c9466c9</anchor>
      <arglist>(const T_functor &amp;_A_func, T_type1 _A_b1, T_type2 _A_b2, T_type3 _A_b3, T_type4 _A_b4, T_type5 _A_b5, T_type6 _A_b6)</arglist>
    </member>
    <member kind="function">
      <type>bind_functor&lt;-1, T_functor, T_type1, T_type2, T_type3, T_type4, T_type5, T_type6, T_type7 &gt;</type>
      <name>bind</name>
      <anchorfile>group__bind.html</anchorfile>
      <anchor>ga0042ca8ec8d92397e5e70303a23cabf7</anchor>
      <arglist>(const T_functor &amp;_A_func, T_type1 _A_b1, T_type2 _A_b2, T_type3 _A_b3, T_type4 _A_b4, T_type5 _A_b5, T_type6 _A_b6, T_type7 _A_b7)</arglist>
    </member>
    <member kind="function">
      <type>bind_return_functor&lt; T_return, T_functor &gt;</type>
      <name>bind_return</name>
      <anchorfile>group__bind.html</anchorfile>
      <anchor>ga91afef95024201ab106a8410580620f1</anchor>
      <arglist>(const T_functor &amp;_A_functor, T_return _A_ret_value)</arglist>
    </member>
  </compound>
  <compound kind="group">
    <name>compose</name>
    <title>compose()</title>
    <filename>group__compose.html</filename>
    <class kind="struct">sigc::compose1_functor</class>
    <class kind="struct">sigc::compose2_functor</class>
    <member kind="function">
      <type>compose1_functor&lt; T_setter, T_getter &gt;</type>
      <name>compose</name>
      <anchorfile>group__compose.html</anchorfile>
      <anchor>ga1966bce067b6dae23be9cbba23e85f07</anchor>
      <arglist>(const T_setter &amp;_A_setter, const T_getter &amp;_A_getter)</arglist>
    </member>
    <member kind="function">
      <type>compose2_functor&lt; T_setter, T_getter1, T_getter2 &gt;</type>
      <name>compose</name>
      <anchorfile>group__compose.html</anchorfile>
      <anchor>gad8e2ea3384e03bfa708b13818280187b</anchor>
      <arglist>(const T_setter &amp;_A_setter, const T_getter1 &amp;_A_getter1, const T_getter2 &amp;_A_getter2)</arglist>
    </member>
  </compound>
  <compound kind="group">
    <name>exception_catch</name>
    <title>exception_catch()</title>
    <filename>group__exception__catch.html</filename>
  </compound>
  <compound kind="group">
    <name>hide</name>
    <title>hide(), hide_return()</title>
    <filename>group__hide.html</filename>
    <class kind="struct">sigc::hide_functor</class>
    <class kind="struct">sigc::hide_functor&lt; 0, T_functor &gt;</class>
    <class kind="struct">sigc::hide_functor&lt;-1, T_functor &gt;</class>
    <member kind="function">
      <type>hide_functor&lt; I_location, T_functor &gt;</type>
      <name>hide</name>
      <anchorfile>group__hide.html</anchorfile>
      <anchor>gad519cf7ef9a33dfa2fa8aae1a0a25724</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type>hide_functor&lt;-1, T_functor &gt;</type>
      <name>hide</name>
      <anchorfile>group__hide.html</anchorfile>
      <anchor>gaba6dc16ffd1fff394b5fde7e66d9e739</anchor>
      <arglist>(const T_functor &amp;_A_func)</arglist>
    </member>
    <member kind="function">
      <type>retype_return_functor&lt; void, T_functor &gt;</type>
      <name>hide_return</name>
      <anchorfile>group__hide.html</anchorfile>
      <anchor>ga9880bc946be160784385419f072bf7f1</anchor>
      <arglist>(const T_functor &amp;_A_functor)</arglist>
    </member>
  </compound>
  <compound kind="group">
    <name>mem_fun</name>
    <title>mem_fun()</title>
    <filename>group__mem__fun.html</filename>
    <class kind="class">sigc::bound_const_mem_functor0</class>
    <class kind="class">sigc::bound_const_mem_functor1</class>
    <class kind="class">sigc::bound_const_mem_functor2</class>
    <class kind="class">sigc::bound_const_mem_functor3</class>
    <class kind="class">sigc::bound_const_mem_functor4</class>
    <class kind="class">sigc::bound_const_mem_functor5</class>
    <class kind="class">sigc::bound_const_mem_functor6</class>
    <class kind="class">sigc::bound_const_mem_functor7</class>
    <class kind="class">sigc::bound_const_volatile_mem_functor0</class>
    <class kind="class">sigc::bound_const_volatile_mem_functor1</class>
    <class kind="class">sigc::bound_const_volatile_mem_functor2</class>
    <class kind="class">sigc::bound_const_volatile_mem_functor3</class>
    <class kind="class">sigc::bound_const_volatile_mem_functor4</class>
    <class kind="class">sigc::bound_const_volatile_mem_functor5</class>
    <class kind="class">sigc::bound_const_volatile_mem_functor6</class>
    <class kind="class">sigc::bound_const_volatile_mem_functor7</class>
    <class kind="class">sigc::bound_mem_functor0</class>
    <class kind="class">sigc::bound_mem_functor1</class>
    <class kind="class">sigc::bound_mem_functor2</class>
    <class kind="class">sigc::bound_mem_functor3</class>
    <class kind="class">sigc::bound_mem_functor4</class>
    <class kind="class">sigc::bound_mem_functor5</class>
    <class kind="class">sigc::bound_mem_functor6</class>
    <class kind="class">sigc::bound_mem_functor7</class>
    <class kind="class">sigc::bound_volatile_mem_functor0</class>
    <class kind="class">sigc::bound_volatile_mem_functor1</class>
    <class kind="class">sigc::bound_volatile_mem_functor2</class>
    <class kind="class">sigc::bound_volatile_mem_functor3</class>
    <class kind="class">sigc::bound_volatile_mem_functor4</class>
    <class kind="class">sigc::bound_volatile_mem_functor5</class>
    <class kind="class">sigc::bound_volatile_mem_functor6</class>
    <class kind="class">sigc::bound_volatile_mem_functor7</class>
    <class kind="class">sigc::const_mem_functor0</class>
    <class kind="class">sigc::const_mem_functor1</class>
    <class kind="class">sigc::const_mem_functor2</class>
    <class kind="class">sigc::const_mem_functor3</class>
    <class kind="class">sigc::const_mem_functor4</class>
    <class kind="class">sigc::const_mem_functor5</class>
    <class kind="class">sigc::const_mem_functor6</class>
    <class kind="class">sigc::const_mem_functor7</class>
    <class kind="class">sigc::const_volatile_mem_functor0</class>
    <class kind="class">sigc::const_volatile_mem_functor1</class>
    <class kind="class">sigc::const_volatile_mem_functor2</class>
    <class kind="class">sigc::const_volatile_mem_functor3</class>
    <class kind="class">sigc::const_volatile_mem_functor4</class>
    <class kind="class">sigc::const_volatile_mem_functor5</class>
    <class kind="class">sigc::const_volatile_mem_functor6</class>
    <class kind="class">sigc::const_volatile_mem_functor7</class>
    <class kind="class">sigc::mem_functor0</class>
    <class kind="class">sigc::mem_functor1</class>
    <class kind="class">sigc::mem_functor2</class>
    <class kind="class">sigc::mem_functor3</class>
    <class kind="class">sigc::mem_functor4</class>
    <class kind="class">sigc::mem_functor5</class>
    <class kind="class">sigc::mem_functor6</class>
    <class kind="class">sigc::mem_functor7</class>
    <class kind="class">sigc::volatile_mem_functor0</class>
    <class kind="class">sigc::volatile_mem_functor1</class>
    <class kind="class">sigc::volatile_mem_functor2</class>
    <class kind="class">sigc::volatile_mem_functor3</class>
    <class kind="class">sigc::volatile_mem_functor4</class>
    <class kind="class">sigc::volatile_mem_functor5</class>
    <class kind="class">sigc::volatile_mem_functor6</class>
    <class kind="class">sigc::volatile_mem_functor7</class>
    <member kind="function">
      <type>bound_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga8f960f4c2577bb628f9c0de824bbad0f</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)())</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga4d12cf568048e2fde93ede00c36fdd9a</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga50d03ced5b627bd3fd35fa6f4ef3331d</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga01b3775529dbc2973e1ed38434353e49</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga7f2ed1ad8ad5f9f5c9d9e0712158b186</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga1d2cd6600ddda7532465c67ca7a580cf</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga198194ed19b8a2c974803f38e85180bc</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gaa44d0fd38fe0aeb548a332c460e79137</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga44eb0f46d4cac264278d5713b32f8b36</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)())</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga7c002e205fab59a11ec8e4ed34020f30</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga9e583e399877d83ebb80a5032f62c52f</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gab482492cd5dbc5fd994165a910d610cc</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gabb7c548a50269ac3953b51890aa4a288</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gad42a2b5a9528eeef2d8ba726d52cdf3b</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga5d670848ae79674c72c16b36644d18dc</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gacbbd2021e83dd6f69cdcead3f1c5f247</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7))</arglist>
    </member>
    <member kind="function">
      <type>mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga2b3b8a62c6647a2bc50de2ae158cd55f</anchor>
      <arglist>(T_return(T_obj::*_A_func)())</arglist>
    </member>
    <member kind="function">
      <type>mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga7e16c03f6bc7cdf99b74ed24a846d51c</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1))</arglist>
    </member>
    <member kind="function">
      <type>mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga4e8efb035927ee7feaa5e49c9953b798</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2))</arglist>
    </member>
    <member kind="function">
      <type>mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gae64e621589894dfb515b53c3228420ea</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3))</arglist>
    </member>
    <member kind="function">
      <type>mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga183417046faf41d9b39b720949e82a49</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4))</arglist>
    </member>
    <member kind="function">
      <type>mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gab7b6782977c4a8531f57ce364b1231cc</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5))</arglist>
    </member>
    <member kind="function">
      <type>mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga57eb416f3aed7d5ca0914301af3b43a6</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6))</arglist>
    </member>
    <member kind="function">
      <type>mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga6f38e358bded356f993dacb180ca8de0</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun0</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gabcd290a63a4d1d74a621d6b62890aafc</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)())</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun0</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga8403211d1ad6174806743c5112180d06</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)())</arglist>
    </member>
    <member kind="function">
      <type>mem_functor0&lt; T_return, T_obj &gt;</type>
      <name>mem_fun0</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga1d68489b08628f0d2542143f56e7e00f</anchor>
      <arglist>(T_return(T_obj::*_A_func)())</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun1</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gaf0dc377959a00d0551a69592553e8cb3</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun1</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gad5410c0ec2d9a82b0b5ebc6b6d1f5447</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1))</arglist>
    </member>
    <member kind="function">
      <type>mem_functor1&lt; T_return, T_obj, T_arg1 &gt;</type>
      <name>mem_fun1</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga458299ac5e83302e3b8f1c69765296ba</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun2</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga0f050df8bce7809e1ef8f6ebe285eabc</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun2</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gae8a9f905cfec5e68467d8011455c54c8</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2))</arglist>
    </member>
    <member kind="function">
      <type>mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;</type>
      <name>mem_fun2</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga44470413467ca6e64e267a3d1c66a018</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun3</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga5e9fd7327451cc2cb39b336f8016cc90</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun3</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga26e6bef1dac59f2d3714d55384a7c48a</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3))</arglist>
    </member>
    <member kind="function">
      <type>mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>mem_fun3</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga72b423893eeca8d87ccf8739f290e49a</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun4</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga77d3bcffbfffb7157ee401fdfa29f65c</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun4</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gadb8e14af035457975822807adc8a4456</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4))</arglist>
    </member>
    <member kind="function">
      <type>mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>mem_fun4</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga70955175cbfc3cb56ab42e9ceb850915</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun5</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gabf00f6a585635e80d6c3c36d08d8889e</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun5</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gacd32aafc9510da71fedabe95109f2cee</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5))</arglist>
    </member>
    <member kind="function">
      <type>mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>mem_fun5</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga82fa0851f42597c6a45c387f281cd483</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun6</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga78b1c9de288f0343ba557b6b234dc4c2</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun6</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gae09aae6c1dc6a67dc9856f006615f626</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6))</arglist>
    </member>
    <member kind="function">
      <type>mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>mem_fun6</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga089c10f2cb594de94bf3803e0f72fd4a</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun7</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gac87b0829fbd016bec8304733be343c34</anchor>
      <arglist>(T_obj &amp;_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7))</arglist>
    </member>
    <member kind="function">
      <type>bound_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun7</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>ga41d027b9fdece038a473adaa3fe38ea1</anchor>
      <arglist>(T_obj *_A_obj, T_return(T_obj2::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7))</arglist>
    </member>
    <member kind="function">
      <type>mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>mem_fun7</name>
      <anchorfile>group__mem__fun.html</anchorfile>
      <anchor>gab990e9938fbd72df93b6c9eb300f0fa0</anchor>
      <arglist>(T_return(T_obj::*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7))</arglist>
    </member>
  </compound>
  <compound kind="group">
    <name>ptr_fun</name>
    <title>ptr_fun()</title>
    <filename>group__ptr__fun.html</filename>
    <class kind="class">sigc::pointer_functor0</class>
    <class kind="class">sigc::pointer_functor1</class>
    <class kind="class">sigc::pointer_functor2</class>
    <class kind="class">sigc::pointer_functor3</class>
    <class kind="class">sigc::pointer_functor4</class>
    <class kind="class">sigc::pointer_functor5</class>
    <class kind="class">sigc::pointer_functor6</class>
    <class kind="class">sigc::pointer_functor7</class>
    <member kind="function">
      <type>pointer_functor0&lt; T_return &gt;</type>
      <name>ptr_fun</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>gae1869c9efd259f295b5de03480a9ff5e</anchor>
      <arglist>(T_return(*_A_func)())</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor1&lt; T_arg1, T_return &gt;</type>
      <name>ptr_fun</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>gaf921a79e585a7f07d6b6534c7e9b876c</anchor>
      <arglist>(T_return(*_A_func)(T_arg1))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor2&lt; T_arg1, T_arg2, T_return &gt;</type>
      <name>ptr_fun</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>gae27faeca4107d88e0ff2ed080cb8caf0</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor3&lt; T_arg1, T_arg2, T_arg3, T_return &gt;</type>
      <name>ptr_fun</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>gaca37294a2ac5c7534749dd9a478ecf03</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2, T_arg3))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor4&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_return &gt;</type>
      <name>ptr_fun</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>gae2a1d41f416aa6ece2a53f43bd54304a</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor5&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_return &gt;</type>
      <name>ptr_fun</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>gad523fd275c0f62d95ab61e0f34a555e5</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor6&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_return &gt;</type>
      <name>ptr_fun</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>ga6ad0ac16fb241e80a83bc115efbf948c</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor7&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7, T_return &gt;</type>
      <name>ptr_fun</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>ga129df09c4e53389acb97e62ae6d52906</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor0&lt; T_return &gt;</type>
      <name>ptr_fun0</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>gabf904c882abfe02a457905355b75c042</anchor>
      <arglist>(T_return(*_A_func)())</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor1&lt; T_arg1, T_return &gt;</type>
      <name>ptr_fun1</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>ga18e42a74ffbbb8e85e2ce341a95c2d0b</anchor>
      <arglist>(T_return(*_A_func)(T_arg1))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor2&lt; T_arg1, T_arg2, T_return &gt;</type>
      <name>ptr_fun2</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>ga417a280f51a84d169f6757c0b2871edf</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor3&lt; T_arg1, T_arg2, T_arg3, T_return &gt;</type>
      <name>ptr_fun3</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>gaf5b62980add5ef6ec62dbed0d18a7629</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2, T_arg3))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor4&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_return &gt;</type>
      <name>ptr_fun4</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>ga863f3abbfbddaadaa488652537ed700e</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor5&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_return &gt;</type>
      <name>ptr_fun5</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>ga5b0e3610f3caefe1706a4e43041a0649</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor6&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_return &gt;</type>
      <name>ptr_fun6</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>ga840be9c606eb5c03b72505abe0edf829</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6))</arglist>
    </member>
    <member kind="function">
      <type>pointer_functor7&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7, T_return &gt;</type>
      <name>ptr_fun7</name>
      <anchorfile>group__ptr__fun.html</anchorfile>
      <anchor>gad190be276e741d04c364a0d4a0ead5a5</anchor>
      <arglist>(T_return(*_A_func)(T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7))</arglist>
    </member>
  </compound>
  <compound kind="group">
    <name>retype</name>
    <title>retype(), retype_return()</title>
    <filename>group__retype.html</filename>
    <class kind="struct">sigc::retype_functor</class>
    <class kind="struct">sigc::retype_return_functor</class>
    <class kind="struct">sigc::retype_return_functor&lt; void, T_functor &gt;</class>
    <member kind="function">
      <type>retype_functor&lt; bound_const_mem_functor0&lt; T_return, T_obj &gt; &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga6c107e595a12569af6a902641e6c902a</anchor>
      <arglist>(const bound_const_mem_functor0&lt; T_return, T_obj &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;, T_arg1 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga24ff023013c40554f918092d1f2fbd42</anchor>
      <arglist>(const bound_const_mem_functor1&lt; T_return, T_obj, T_arg1 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;, T_arg1, T_arg2 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga2ddb2e47e115accbb5d6dabce39c0ac8</anchor>
      <arglist>(const bound_const_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga63f34145eb38802ed2a7bf01e26b6dfa</anchor>
      <arglist>(const bound_const_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga17395f3e43e3b68ae63dad570e135311</anchor>
      <arglist>(const bound_const_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gac588c0330476e26c3ed05aca43834e00</anchor>
      <arglist>(const bound_const_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gaa7f28f6f24305fb91b9cac3ba496594e</anchor>
      <arglist>(const bound_const_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga25d9b0baa3ea0b49df4fe255514ae490</anchor>
      <arglist>(const bound_const_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_volatile_mem_functor0&lt; T_return, T_obj &gt; &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga1c5915b1f959006a4e48974818bfe77f</anchor>
      <arglist>(const bound_const_volatile_mem_functor0&lt; T_return, T_obj &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;, T_arg1 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga1aad7db8d6238782b66e356bcd971c10</anchor>
      <arglist>(const bound_const_volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;, T_arg1, T_arg2 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga20fe67bcf50c69672a347b1968c6d631</anchor>
      <arglist>(const bound_const_volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gacc539fe6af45742672db7e6ac55a056c</anchor>
      <arglist>(const bound_const_volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga5b5963c5dee282f1d5e53bd1ddfe9438</anchor>
      <arglist>(const bound_const_volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga2accbb2db55b8c3253507c8ebbd24199</anchor>
      <arglist>(const bound_const_volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gac0d59bd2cc9988722f02ca660d7afed8</anchor>
      <arglist>(const bound_const_volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_const_volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga1c908428d78c67fd872538039040bf8c</anchor>
      <arglist>(const bound_const_volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_mem_functor0&lt; T_return, T_obj &gt; &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga49cb342890317ee70d4f202cc2a2c1c0</anchor>
      <arglist>(const bound_mem_functor0&lt; T_return, T_obj &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;, T_arg1 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gad18f526fdfde8004ed1de96bfa413657</anchor>
      <arglist>(const bound_mem_functor1&lt; T_return, T_obj, T_arg1 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;, T_arg1, T_arg2 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga4eae2106da32159768f872d5db7a15be</anchor>
      <arglist>(const bound_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gaa36f4d6bd8930fb1e217e6f664d303f9</anchor>
      <arglist>(const bound_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gae0199dadf1d100c092a5e86f69098627</anchor>
      <arglist>(const bound_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga5eed9002b7c7ac02b25a009ba698a419</anchor>
      <arglist>(const bound_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga5226ce140c12dc0e3e7adecb5cfa2c3b</anchor>
      <arglist>(const bound_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga7ccb754d4cd293cb0c6f0f181bd95358</anchor>
      <arglist>(const bound_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_volatile_mem_functor0&lt; T_return, T_obj &gt; &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga53e413a4634b0af8e1f221b98b2bcb20</anchor>
      <arglist>(const bound_volatile_mem_functor0&lt; T_return, T_obj &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;, T_arg1 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gaa7d6a32b1a591926cf93a8cb91e84007</anchor>
      <arglist>(const bound_volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;, T_arg1, T_arg2 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga513e88c64f13be9f2795e101e292958c</anchor>
      <arglist>(const bound_volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga3b5a0b5eefa94cce26bf0adcc1d4a2b5</anchor>
      <arglist>(const bound_volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga8a47bd7abd4dcdbffe7b94ddf7e6b70c</anchor>
      <arglist>(const bound_volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gad1ed361b37f183381410691872a85283</anchor>
      <arglist>(const bound_volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga12dddf97ebdf6d5a1a52d3addde70325</anchor>
      <arglist>(const bound_volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; bound_volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga2859a461bb17f096894e524db4d63663</anchor>
      <arglist>(const bound_volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_mem_functor0&lt; T_return, T_obj &gt; &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gaba0494c6e616362c0e642f281077d198</anchor>
      <arglist>(const const_mem_functor0&lt; T_return, T_obj &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;, T_arg1 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gaab8ab4d661417218f99527574896505a</anchor>
      <arglist>(const const_mem_functor1&lt; T_return, T_obj, T_arg1 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;, T_arg1, T_arg2 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gac60e2944abf4bbba72f5863fce332e41</anchor>
      <arglist>(const const_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gae3dd72fda7a601292b252665c14ab2c4</anchor>
      <arglist>(const const_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga7c9b86558ae7e42af45abe56d4763153</anchor>
      <arglist>(const const_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga963efe620473c3f35bd71f1f4c2b72aa</anchor>
      <arglist>(const const_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga77e01a6fa7b29f260d6f537fecf4036f</anchor>
      <arglist>(const const_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gab841aa27f8e582c1994429a3ecaa955e</anchor>
      <arglist>(const const_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_volatile_mem_functor0&lt; T_return, T_obj &gt; &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga7fbc58665a9d94300c4d7fe69440fa87</anchor>
      <arglist>(const const_volatile_mem_functor0&lt; T_return, T_obj &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;, T_arg1 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gabc956c6b66365fb3448b37e64d3044da</anchor>
      <arglist>(const const_volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;, T_arg1, T_arg2 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga951f4bb023f6bf4d8fa9424e659f90cf</anchor>
      <arglist>(const const_volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gaa7575ba0ddcfde8c8935f96e225ff2c2</anchor>
      <arglist>(const const_volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gab3680cdf3e713a87f8288d52a2f62b6a</anchor>
      <arglist>(const const_volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gaf1fb93d6705ceb5129c99354771b63da</anchor>
      <arglist>(const const_volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga54c15c7a5f756e2e4221c12380d300db</anchor>
      <arglist>(const const_volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; const_volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga7599c7c81804a82b28ec25cfcf7ed73d</anchor>
      <arglist>(const const_volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; mem_functor0&lt; T_return, T_obj &gt; &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gad77a172d9515e4fd4370722cf9612ba6</anchor>
      <arglist>(const mem_functor0&lt; T_return, T_obj &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; mem_functor1&lt; T_return, T_obj, T_arg1 &gt;, T_arg1 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga0ad693c256892494042518f7e8bfc20a</anchor>
      <arglist>(const mem_functor1&lt; T_return, T_obj, T_arg1 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;, T_arg1, T_arg2 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gad8f1f6519bc9959570e9f876b439ba9b</anchor>
      <arglist>(const mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga4c08e6b6d3b399e204879a0d7b9f2b0e</anchor>
      <arglist>(const mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga3f2fddc16f94e7f3cbea037ec43ca5f0</anchor>
      <arglist>(const mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga141fb7efc6dfdb4e0614da37e385e71a</anchor>
      <arglist>(const mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga70593acca6bafad973df8f81ce57ad94</anchor>
      <arglist>(const mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gaabe7c544ba6dba7d157d9d5fa7a90098</anchor>
      <arglist>(const mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; pointer_functor0&lt; T_return &gt; &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga6fae64e7670cae5af728ab36cce1e1c2</anchor>
      <arglist>(const pointer_functor0&lt; T_return &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; pointer_functor1&lt; T_arg1, T_return &gt;, T_arg1 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga52390ed4f43b71e63f83e87422c1155b</anchor>
      <arglist>(const pointer_functor1&lt; T_arg1, T_return &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; pointer_functor2&lt; T_arg1, T_arg2, T_return &gt;, T_arg1, T_arg2 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga61096e57221b1431b97c7764e76051ba</anchor>
      <arglist>(const pointer_functor2&lt; T_arg1, T_arg2, T_return &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; pointer_functor3&lt; T_arg1, T_arg2, T_arg3, T_return &gt;, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga45666d1e9f5b684998db043562499f46</anchor>
      <arglist>(const pointer_functor3&lt; T_arg1, T_arg2, T_arg3, T_return &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; pointer_functor4&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_return &gt;, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gafef2854df9cb42b0dba9f06513bbf791</anchor>
      <arglist>(const pointer_functor4&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_return &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; pointer_functor5&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_return &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gad11b38e1d0ded72d17209f5f93fb66b5</anchor>
      <arglist>(const pointer_functor5&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_return &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; pointer_functor6&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_return &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga0c91dae5d6fae2619ae159217adfb8c9</anchor>
      <arglist>(const pointer_functor6&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_return &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; pointer_functor7&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7, T_return &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga7c8a5e03cd174de3322c065aa240ccbf</anchor>
      <arglist>(const pointer_functor7&lt; T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7, T_return &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; slot&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gaea80daa7fb16d2cac60f185667b2fe9d</anchor>
      <arglist>(const slot&lt; T_return, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; volatile_mem_functor0&lt; T_return, T_obj &gt; &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga1412fa6dfa392e2c88688ae9ea4be29d</anchor>
      <arglist>(const volatile_mem_functor0&lt; T_return, T_obj &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt;, T_arg1 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gae7074c1265efe335755f7460ba15c888</anchor>
      <arglist>(const volatile_mem_functor1&lt; T_return, T_obj, T_arg1 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt;, T_arg1, T_arg2 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga7b77efe41e5a11cec979979ad666c725</anchor>
      <arglist>(const volatile_mem_functor2&lt; T_return, T_obj, T_arg1, T_arg2 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt;, T_arg1, T_arg2, T_arg3 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga93978e864006832ab18beb5d685f2310</anchor>
      <arglist>(const volatile_mem_functor3&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt;, T_arg1, T_arg2, T_arg3, T_arg4 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga472b34f2dd5a8d7fd4da157926339b09</anchor>
      <arglist>(const volatile_mem_functor4&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gae567cf66645331216794c24f559240e2</anchor>
      <arglist>(const volatile_mem_functor5&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gab7c39f5d6ea213acf582d2ef3a769073</anchor>
      <arglist>(const volatile_mem_functor6&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_functor&lt; volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt;</type>
      <name>retype</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>ga9b82a4f45380ffc18d636fd390679050</anchor>
      <arglist>(const volatile_mem_functor7&lt; T_return, T_obj, T_arg1, T_arg2, T_arg3, T_arg4, T_arg5, T_arg6, T_arg7 &gt; &amp;_A_functor)</arglist>
    </member>
    <member kind="function">
      <type>retype_return_functor&lt; T_return, T_functor &gt;</type>
      <name>retype_return</name>
      <anchorfile>group__retype.html</anchorfile>
      <anchor>gabf41e61ebc452f69ae1e2b5ca5a2f709</anchor>
      <arglist>(const T_functor &amp;_A_functor)</arglist>
    </member>
  </compound>
  <compound kind="group">
    <name>track_obj</name>
    <title>track_obj(), track_object()</title>
    <filename>group__track__obj.html</filename>
    <class kind="class">sigc::track_obj_functor1</class>
    <class kind="class">sigc::track_obj_functor2</class>
    <class kind="class">sigc::track_obj_functor3</class>
    <class kind="class">sigc::track_obj_functor4</class>
    <class kind="class">sigc::track_obj_functor5</class>
    <class kind="class">sigc::track_obj_functor6</class>
    <class kind="class">sigc::track_obj_functor7</class>
    <member kind="function">
      <type>track_obj_functor1&lt; T_functor, T_obj1 &gt;</type>
      <name>track_obj</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>gafa4f352697149bbb860efc861be9f18b</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor2&lt; T_functor, T_obj1, T_obj2 &gt;</type>
      <name>track_obj</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>ga3aae882d4a72d5971c1b76a4c5d4c601</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor3&lt; T_functor, T_obj1, T_obj2, T_obj3 &gt;</type>
      <name>track_obj</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>gab501e266973ce3bdec7539a29f1b17de</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor4&lt; T_functor, T_obj1, T_obj2, T_obj3, T_obj4 &gt;</type>
      <name>track_obj</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>ga1fec4c6c5c92bbb3563fe14928e2b883</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3, const T_obj4 &amp;_A_obj4)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor5&lt; T_functor, T_obj1, T_obj2, T_obj3, T_obj4, T_obj5 &gt;</type>
      <name>track_obj</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>gacce53cf8c90e95add5dc77072d64cc8f</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3, const T_obj4 &amp;_A_obj4, const T_obj5 &amp;_A_obj5)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor6&lt; T_functor, T_obj1, T_obj2, T_obj3, T_obj4, T_obj5, T_obj6 &gt;</type>
      <name>track_obj</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>gaf6e22889485abeb6adb12b916d301f8d</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3, const T_obj4 &amp;_A_obj4, const T_obj5 &amp;_A_obj5, const T_obj6 &amp;_A_obj6)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor7&lt; T_functor, T_obj1, T_obj2, T_obj3, T_obj4, T_obj5, T_obj6, T_obj7 &gt;</type>
      <name>track_obj</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>ga72c2b62068e0c155cdf1911e28d97ebe</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3, const T_obj4 &amp;_A_obj4, const T_obj5 &amp;_A_obj5, const T_obj6 &amp;_A_obj6, const T_obj7 &amp;_A_obj7)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor1&lt; T_functor, T_obj1 &gt;</type>
      <name>track_object</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>gad00ec458bb4f9fa469cf8b7f10ec8e61</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor2&lt; T_functor, T_obj1, T_obj2 &gt;</type>
      <name>track_object</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>ga29034b19a0b58d05f0cd3cd8cf5c3fec</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor3&lt; T_functor, T_obj1, T_obj2, T_obj3 &gt;</type>
      <name>track_object</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>gab17bbb108f387c479fac94a6578eead5</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor4&lt; T_functor, T_obj1, T_obj2, T_obj3, T_obj4 &gt;</type>
      <name>track_object</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>ga684acf3428fd736fde4c2e77b10c6ea7</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3, const T_obj4 &amp;_A_obj4)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor5&lt; T_functor, T_obj1, T_obj2, T_obj3, T_obj4, T_obj5 &gt;</type>
      <name>track_object</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>gae79aa5c80594ab406619492d167b27f4</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3, const T_obj4 &amp;_A_obj4, const T_obj5 &amp;_A_obj5)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor6&lt; T_functor, T_obj1, T_obj2, T_obj3, T_obj4, T_obj5, T_obj6 &gt;</type>
      <name>track_object</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>gab7768b7b8f18afa47ecd3b1f7c252659</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3, const T_obj4 &amp;_A_obj4, const T_obj5 &amp;_A_obj5, const T_obj6 &amp;_A_obj6)</arglist>
    </member>
    <member kind="function">
      <type>track_obj_functor7&lt; T_functor, T_obj1, T_obj2, T_obj3, T_obj4, T_obj5, T_obj6, T_obj7 &gt;</type>
      <name>track_object</name>
      <anchorfile>group__track__obj.html</anchorfile>
      <anchor>ga9290af1906e1532d0827cd7dcf0dc3ae</anchor>
      <arglist>(const T_functor &amp;_A_func, const T_obj1 &amp;_A_obj1, const T_obj2 &amp;_A_obj2, const T_obj3 &amp;_A_obj3, const T_obj4 &amp;_A_obj4, const T_obj5 &amp;_A_obj5, const T_obj6 &amp;_A_obj6, const T_obj7 &amp;_A_obj7)</arglist>
    </member>
  </compound>
  <compound kind="page">
    <name>index</name>
    <title>libsigc++ Reference Manual</title>
    <filename>index.html</filename>
    <docanchor file="index.html" title="Description">description</docanchor>
    <docanchor file="index.html" title="Features">features</docanchor>
    <docanchor file="index.html" title="Basic Usage">basics</docanchor>
    <docanchor file="index.html" title="Using Meson">meson</docanchor>
    <docanchor file="index.html" title="Using Autotools">autotools</docanchor>
    <docanchor file="index.html" title="Using CMake">cmake</docanchor>
    <docanchor file="index.html" title="Scope of Documentation">scope</docanchor>
  </compound>
</tagfile>

# FOS dev test harnesses

Dev-only tests. They live outside `Buildroot/board/FOG/FOS/rootfs_overlay`, so
nothing here ever enters the built init.

## golden/ — output differential harness

Proves that refactors of the shared libraries (`funcs.sh`,
`partition-funcs.sh`) change no observable output. It drives the
deterministic, refactor-targeted functions over a fixed battery of inputs and
compares the result against a committed fixture:

```sh
tests/golden/run.sh capture   # write fixtures/golden.txt (run BEFORE a refactor)
tests/golden/run.sh check     # regenerate and assert byte-identical to the fixture
tests/golden/run.sh print     # dump current output to stdout
```

Covered: every `*FileName()` output string, the `doInventory` dmidecode and
base64 blocks, and the `changeHostname` registry `EOFREG` file contents.

The library hardcodes `/usr/share/fog/lib` paths and calls hardware tools, so
the harness sources a sandbox copy with those paths rewritten and the external
tools stubbed deterministically. The fixture is therefore machine-independent.

Workflow for a refactor: run `check` on a clean tree (should pass against the
committed fixture), make the change, run `check` again — it must still pass.

## checks/ — assertion harnesses

Pass/fail assertions for behavior that a single golden output stream can't
express (e.g. "does this function abort or not?"). Each script runs a battery of
cases and exits non-zero if any fail.

```sh
tests/checks/sector-size.sh   # validateImageSectorSize() refuses on a
                              # logical-sector-size mismatch, allows on match,
                              # reformats an NVMe target to the image's sector
                              # size when it exposes a matching LBA format, and
                              # names the device class (eMMC/UFS/virtual/NVMe)
                              # in the refusal when the target's size is fixed
tests/checks/fill-engine.sh   # the whole-disk fill engine (processSfdisk +
                              # fillSfdiskWithPartitions + fill_disk in the awk):
                              # 4Kn sector-size rescaling keeps a small partition
                              # alive, the GPT backup-header clamp holds, and an
                              # unusable computed table aborts instead of being
                              # written
tests/checks/resize-engine.sh # the capture-time shrink (processSfdisk +
                              # resizeSfdiskPartition + resize_partition in the
                              # awk), the deploy engine's sibling: the disk's own
                              # last-lba is passed through rather than recomputed,
                              # the byte-count argument is divided by the LOGICAL
                              # sector size (not the alignment quantum) so a 4Kn
                              # shrink asks for an eighth as many sectors rather
                              # than eight times too many, that division rounds up
                              # so a partition is never smaller than the
                              # filesystem already shrunk into it, and a valid 4Kn
                              # shrink reaches the sfdisk write (ADR-0016)
tests/checks/move-partition.sh
                              # movePartition(), which closes the gap a capture-
                              # time shrink leaves on a GPT disk: each partition
                              # is looked up by its exact device name, so sda1
                              # never also matches sda14/sda15 (Debian/Ubuntu
                              # cloud images, fos#189)
tests/checks/ntfs-shrink-retry.sh
                              # the NTFS branch of shrinkPartition() when the
                              # ntfsresize dry run fails with ENOSPC (ntfs-3g
                              # issue #142, fogproject#789): the target grows
                              # and is retried until a dry run passes, the
                              # real resize uses the size that passed, any
                              # other failure still aborts on the first try,
                              # and a volume nothing below its present size
                              # fits is recorded as fixed size instead
tests/checks/mbr-extended.sh  # MBR tables carrying an extended partition with
                              # logicals inside it (issue #150): the emitted
                              # table is ordered by partition number so sfdisk
                              # never meets a logical before its container, each
                              # logical keeps a gap for its EBR, the container is
                              # sized from its contents rather than scaled, and
                              # savePartition/restorePartition treat it as a
                              # container rather than partclone'ing it. Where a
                              # real sfdisk is present each computed table is
                              # also applied to a sparse file
tests/checks/error-report.sh  # the failure report handleError() sends to
                              # service/taskerror.php (fogproject#1206): it goes
                              # to the right URL with mac, sysuuid and the
                              # message, it is time bounded and url-encoded, the
                              # "\n" the callers embed is expanded before
                              # sending, nothing it does reaches the operator's
                              # console, a failed report still lets handleError
                              # reach its reboot notice, and no $web means no
                              # attempt at all
tests/checks/empty-mac-fallback.sh
                              # what $mac is when the server sent none
                              # (fogproject#1767). A FOG 1.5 server builds a
                              # menu-started task's kernel line with an empty
                              # mac= for any machine with no host row, and $mac
                              # is how FOS names itself to taskerror.php,
                              # progress.php and the Secure Boot report for the
                              # whole run -- so an empty one makes every report
                              # anonymous and silently discarded. The check
                              # pins that an empty or absent mac= is answered
                              # from the NICs, that a mac= the server DID send
                              # is kept and costs no lookup, that a USB boot's
                              # own /tmp/hinfo.txt answer still wins, and that
                              # the result is exported so a child process (the
                              # backgrounded fog.statusreporter) sees it. Its
                              # ip double reproduces FOS's OWN busybox output,
                              # which omits the `state`/`group` fields a
                              # distribution's ip prints -- getMACAddresses
                              # reads field 11, so a stub built from the host's
                              # format returns junk and fails correct code
tests/checks/server-post-reporting.sh
                              # callServer() and every script that talks to the
                              # FOG server (fogproject#1380): a connect failure,
                              # an HTTP >= 400, a 2xx with an EMPTY body and a
                              # real answer are told apart rather than all
                              # printing as one blank "Error returned:", and the
                              # three get distinct return codes so a caller can
                              # tell a dead server from an endpoint that answers
                              # nothing on purpose. An empty 200 points at the
                              # PHP error log because a PHP fatal is not
                              # catchable server-side; a multi-line body survives
                              # the -w status split; trailing newlines are
                              # stripped, because every caller compares the reply
                              # against a bare sentinel ("##") and used to get
                              # that stripping free from $(curl ...). GET when no
                              # data is passed, POST when there is. And -- the
                              # case that matters -- the caller can still read
                              # serverReason after the call, since $(callServer
                              # ...) runs in a subshell that discards it, so no
                              # call site anywhere in the overlay may wrap it,
                              # and raw curl may read a reply only in the
                              # exceptions named in the check
tests/checks/status-reporting.sh
                              # fog.statusreporter: what actually reaches
                              # service/progress.php while a task images. It
                              # read partclone's snapshot file as though it
                              # were a stream -- truncating /tmp/status.fog
                              # after every read, which posted an EMPTY status
                              # whenever the read landed between the truncation
                              # and the next tick, and left nothing for any
                              # other reader. The check pins that the producer's
                              # file survives a read, that a partial or short
                              # line the server would discard is not sent at
                              # all, that an unchanged value is not re-posted
                              # every three seconds (a host lookup, a task
                              # load, an image load and a save per post, times
                              # every client in a multicast), that it IS
                              # re-posted on the keepalive interval so a quiet
                              # client and a stalled one are distinguishable in
                              # the server's log, and that the poll loop
                              # contains no `continue` -- the old empty-MAC
                              # guard jumped past the sleep and span at 100%
                              # CPU. The spin is measured from /proc, not from
                              # `ps -o time=`: the loop burns its time in the
                              # `tail` it forks, so ps reports 00:00:00 for a
                              # process eating a core
tests/checks/partclone-status-patch.sh
                              # the producer half of the same path: FOG's
                              # partclone patch, which adds fogLogStatusFile()
                              # to progress.c. That function used to call
                              # exit(0) when it could not open
                              # /tmp/status.fog, quitting partclone with a
                              # SUCCESS status mid-restore -- funcs.sh reads
                              # $exitcode, sees 0, and records a partially
                              # written partition as a completed deploy. /tmp
                              # in FOS is a ramdisk, so a full one reaches it.
                              # The check pins that the function never exits,
                              # that a failed open returns instead, that no
                              # sprintf() takes a converted string as its
                              # FORMAT argument, and that each hunk header's
                              # counts match the lines under it -- the added
                              # code is `+` lines in a unified diff, so
                              # editing it by hand moves counts that nothing
                              # else recomputes
tests/checks/wipe.sh          # wipeDisk() issues the right erase primitive per
                              # device class (NVMe/SSD/HDD) and mode
                              # (fast/normal/full), never issues an `nvme format`
                              # without an explicit --ses, warns that overwriting
                              # an SSD is not a guaranteed erase, and refuses
                              # instead of reporting a wipe that did not run
tests/checks/secureboot.sh    # secureboot-funcs.sh: derives the right firmware
                              # state from efivarfs (keeping Setup Mode distinct
                              # from "Secure Boot merely off"), rejects a
                              # non-certificate download, and stages the MOK
                              # request non-interactively without ever putting
                              # the one-time password on a mokutil argv --
                              # refusing when mokutil exits 0 having staged
                              # nothing. Also covers the Setup Mode db path:
                              # db goes to the image-security GUID and not the
                              # global one, the attribute prefix carries the
                              # authenticated-write bit, the variable is written
                              # in a single full-block dd, PK is written LAST,
                              # a failed download writes nothing at all, and a
                              # SetupMode that does not flip 1 -> 0 is a refusal
                              # rather than a success. And the User Mode path
                              # (ADR-0019): Microsoft's signed 2023 CA updates
                              # are appended, not written over db, only where
                              # the 2011 counterpart and Microsoft's KEK are
                              # present, and a write the firmware did not apply
                              # is a failure. sbEnroll() end to end: each path
                              # sets the outcome the task reports (a staged
                              # request is 'mok', never 'db'), handleError
                              # aborts while handleWarning returns, and
                              # registration enrolls only on sbenroll=true,
                              # skips BIOS and 32-bit UEFI quietly, and posts
                              # no report (fogproject#1860)
tests/checks/secureboot-enrollment-report.sh
                              # sbReport() tells the FOG server WHICH of
                              # sbEnroll()'s three outcomes was reached -- all
                              # three otherwise end in the same argument-free
                              # completion POST and look identical from the
                              # server. Pins that a staged MOK is reported as
                              # 'mok' and never as an enrollment (turning Secure
                              # Boot on after that lie stops the machine
                              # booting), that every exit reports BEFORE
                              # completing the task, and that a server that is
                              # unreachable, 404s or answers nothing never
                              # fails the task the enrollment already finished
tests/checks/secureboot-config.sh
                              # configs/kernel*.config carry the Secure Boot
                              # hardening symbols (lockdown LSM in CONFIG_LSM,
                              # platform keyring, no CONFIG_KEXEC). See ADR-0010
tests/checks/pcie-aspm-config.sh
                              # configs/kernel*.config leave the kernel able to
                              # control PCIe ASPM: CONFIG_PCIEASPM, CONFIG_PCI_
                              # MMCONFIG on x86, a non-power-saving ASPM policy.
                              # Without these, pci_disable_link_state() is a stub
                              # that reports success, and r8169 enables ASPM and
                              # L1.2 on the NIC believing the OS disabled L1 --
                              # a ~5x deploy throughput loss. See ADR-0013
tests/checks/initrd-format.sh
                              # the init image build.sh publishes for each arch
                              # (rootfs.ext2.xz on x64/x86, rootfs.cpio.gz on
                              # arm64) is one that arch's kernel can actually
                              # decompress: CONFIG_RD_<fmt>/CONFIG_DECOMPRESS_
                              # <fmt> present, and fs<arch>.config really emits
                              # that image type and compression. The two ends
                              # had drifted -- the released arm64 kernel shipped
                              # with RD_GZIP off against a gzip init, which
                              # cannot boot at all. Also asserts CONFIG_MODULES
                              # is off on every arch: the init is the root
                              # filesystem and has no /lib/modules, so an =m
                              # driver is a driver that silently isn't there
tests/checks/arm64-platform-config.sh
                              # configs/kernelarm64.config describes an actual
                              # ARM platform: ARCH_BCM2835 (Pi 3/4/5), the
                              # VideoCore firmware+mailbox+clock chain, SD card
                              # (sdhci-iproc, sdhost, DMA), NICs (genet,
                              # lan78xx, smsc95xx, macb for Pi 5's RP1),
                              # PCIE_BRCMSTB, the SoC watchdog FOS reboots
                              # through, and the RP1 overlay symbols -- plus
                              # ACPI, PCI_HOST_GENERIC and PL011 for non-Pi
                              # arm64. Also that build.sh builds dtbs.
                              # See ADR-0015
tests/checks/nfs-mount-type.sh
                              # every FOS mount carrying the NFS-only option
                              # list also names -t nfs. busybox mount infers
                              # NFS from the SOURCE ("host:/path"), not from
                              # the options, and the init ships no mount.nfs
                              # helper -- so an empty or malformed storage=
                              # silently falls through to a walk of every
                              # block-backed filesystem in /proc/filesystems,
                              # each one rejecting 'nolock'. The console then
                              # blames ext2/ext4/vfat/f2fs for a bad NFS path.
                              # See forums topic 18229
tests/checks/mdraid-gate.sh
                              # md arrays assemble only with mdraid=true:
                              # the overlay masks mdadm's udev
                              # 64-md-raid-assembly.rules with a copy gated on
                              # the kernel command line, and S99fog stops any
                              # array when the flag is off. Without the gate an
                              # array holds its member partitions and capture
                              # fails with 'Could not find partitions'. -b also
                              # diffs the copy against the built upstream rule.
                              # See forums topic 18202
tests/checks/multicast-receiver.sh
                              # writeImage() gives both udp-receiver call
                              # sites --start-timeout of max(mcastMaxWait*60,
                              # 600)+120 seconds when the server sent a positive
                              # integer mcastMaxWait, and no flag otherwise (an
                              # older server, 0, or garbage). Without it a host
                              # that boots after its sender started or gave up
                              # waits forever. An empty receiver stream is
                              # reported as "no multicast sender answered"
                              # rather than a stream mismatch against ''.
                              # See fos#48
tests/checks/fixparts-binary-present.sh
                              # runFixparts() calls fixparts, which Buildroot's
                              # gptfdisk package cannot build. fs.patch adds
                              # BR2_PACKAGE_GPTFDISK_FIXPARTS; this asserts the
                              # patch still defines it and every fs config sets
                              # it. A symbol with no Kconfig definition is
                              # dropped silently, which is how every init from
                              # 2023-12 on shipped without it. See fos#194
tests/checks/package-mirrors.sh
                              # build.sh's package-mirror seeding: resolves each
                              # package's version/source/site out of its own .mk
                              # (including Buildroot's github macro), falls
                              # through upstream -> Debian -> Fedora lookaside,
                              # refuses a source serving bytes that don't match
                              # the package's .hash, repairs rather than trusts a
                              # cached tarball whose hash no longer matches,
                              # skips a package that has no .hash, and returns 0
                              # when every source is down so Buildroot still gets
                              # its own attempt. Also covers bump-package.sh:
                              # a bump rewrites version and hashes together and
                              # drops the superseded lines, a failed download
                              # restores the .mk rather than leaving a half-bump,
                              # and --dry-run writes nothing
tests/checks/us-spelling.sh   # FOS's own source carries US spellings. A
                              # whole-tree scan rather than a diff, because a
                              # diff-scoped check needs a base ref a shallow
                              # clone does not have -- and would then pass for a
                              # reason unrelated to spelling, silently. Two
                              # patterns: word/camelCase, and ALL CAPS with a
                              # tighter right edge, so the five-letter UK form
                              # does not fire inside ENROLL_SECUREBOOT
```

Like the golden harness, the library harnesses source a sandbox copy of the
library with its hardcoded paths rewritten and the external tools stubbed, so
they run on any host without hardware.

`package-mirrors.sh` is the one harness that tests `build.sh` rather than
anything shipped in the init. It follows the same sandbox-and-stub pattern —
the functions come from `package-funcs.sh` (they live there rather than in
`build.sh`, which would run a whole build if sourced), `wget` is PATH-shadowed,
and the seeding cases run against
a synthetic package whose `.mk`/`.hash` describe a locally generated fixture.
That last part is what keeps it offline: no case touches the network, and none
depends on any upstream still serving a given release. Whether the *committed*
hashes still match the *real* tarballs is a question only a build can answer.

The URL-resolution and shipped-file groups do read the real
`Buildroot/package/*/` files, since both are pure text checks — that each
package's site resolves to the URL Buildroot will actually request, and that
every mirrored package still carries the hashes its mirrors are addressed by.

The two `*-config.sh` harnesses are different: they assert on the kernel
configs rather than on shell code, and take `-b` to additionally inspect the
post-`oldconfig` `.config` in any `kernelsource<arch>/` present. That mode is
the one that proves anything, because `make oldconfig` silently drops symbols
whose dependencies are unmet — a config can look correct in git and still build
a kernel without the feature.

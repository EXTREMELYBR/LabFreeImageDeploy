#!/usr/bin/awk -f
#
# This script will shrink (resize) partitions based
#  on the new partition size passed in.
# NOTE: This does not shrink the volume,
#  just the parititon layout information.
# This script will fill disks (expand) with
#  the relevant data passed on based on the disk size passed in.
#
# Usage Passed in Variables:
#
# SECTOR_SIZE The size-alignment quantum, in sectors -- NOT the sector size,
#             despite the name. 512 on a 512-byte-sector disk (= 256 KiB), 64 on
#             a 4Kn one (the same 256 KiB). Only ever used as `x % SECTOR_SIZE`.
# LOGICAL_SECTOR_SIZE
#             The disk's logical sector size in bytes (512, 4096, ...). This is
#             the unit the whole table is expressed in, and the divisor that turns
#             resize's byte-count argument into a sector count. Distinct from
#             SECTOR_SIZE on purpose: see ADR-0016. Defaults to 512.
# CHUNK_SIZE  The default block size for the disk/partition being used. Typically 512
# MIN_START   The minimum start position for the first partition. Typically 2048.
# action      The action to perform with the script.
#  1. filldisk Fills the disk.
#  2. move     Moves partitions.
#  3. resize   Shrinks partitions.
# target      The target to work with.
#  1. filldisk The target is the disk in whole.
#  2. move     The target is the current partition.
#  3. resize   The target is the current partition.
# sizePos     The size to change.
#  This is only used for move/resize. Used to tell
#   the new size of the disk.
# diskSize    The disk size.
# fixedList   The partition sizes that should remain untouched in size.
#
# $data is the filename of the output of sfdisk -d
# cat $data | awk -F, '\

# Comparison function for PROCINFO["sorted_in"], ordering a partition_names
# traversal by partition number rather than by gawk's hash order.
#
# `for (name in partition_names)` has no defined order. That is fatal for an
# MBR table carrying an extended partition: sfdisk applies a script line by
# line and derives the partition number from the device name, so a logical
# (>=5) reaching sfdisk before the extended partition that contains it fails
# with "Extended partition does not exists. Failed to add logical partition."
# and the whole apply is abandoned. gawk's hash order happens to match the
# input order for /dev/sdaN with N <= 9, which is why this only surfaced on
# tables with ten or more partitions (/dev/sda10 hashes to the front).
# Ascending partition number is the order sfdisk needs and the order the rest
# of this script was written assuming.
#
# i1/i2 are the array indices (the device names); v1/v2 are unused.
# n1 and n2 are locally scoped.
function by_partition_number(i1, v1, i2, v2, n1, n2) {
    # Same extraction as the parser below, so devices like mmcblk0p10 and
    # nvme0n1p10 order on their partition number and not on the whole string.
    n1 = int(gensub(/^.*[^0-9]([0-9]+)/, "\\1", 1, i1));
    n2 = int(gensub(/^.*[^0-9]([0-9]+)/, "\\1", 1, i2));
    if (n1 < n2) {
        return -1;
    }
    if (n1 > n2) {
        return 1;
    }
    return 0;
}

# Checks all partitions for any overlap possibilities.
# Requires partition_names and partitions.
# partition_names is an array of all the partition names.
# partitions is an array containing the data we need.
#  Partitions are sent in an array of form:
#   partitions['name']['start'] = value;
#   partitions['name']['size'] = value;
# pName is locally scoped
# p_start is locally scoped
# p_size is locally scoped
function check_all_partitions(partition_names, partitions, pName, p_start, p_size) {
    # Iterate through our parittion names.
    for (pName in partition_names) {
        # The current iteration's start value.
        p_start = int(partitions[pName, "start"]);
        # The current iteration's size value.
        p_size = int(partitions[pName, "size"]);
        # Store the overlap variable.
        overlap = check_overlap(partition_names, partitions, pName, p_start, p_size);
        # If overlap is ok, skip.
        if (overlap == 0) {
            continue;
        }
        # If the overlap didn't skip over print nice message
        # break from loop, as no need to do anything else, it's bad.
        printf("# ERROR in new partition table, quitting.\n");
        printf("# ERROR: %s has an overlap.\n", pName);
        return 1;
    }
    # Only print consistent overlap if overlap is not set safe.
    printf("# Partition table is consistent.\n");
    # Return with success.
    return 0;
}

# Checks the overlap.
# Requires:
#  partition_names
#  partitions
#  new_part_name
#  new_start
#  new_size
# partition_names is an array of all the partition names.
# partitions is an array containing the data we need.
#  Partitions are sent in an array of form:
#   partitions['/dev/sda1']['start'] = value;
#   partitions['/dev/sda1']['size'] = value;
# new_part_name is the target we're checking.
# new_start The new start position
# new_size the new size of the partition
# extended_margin locally scoped
# new_type is locally scoped
# new_part_number is locally scoped
# pName is locally scoped
# p_type is locally scoped
# p_start is locally scoped
# p_size is locally scoped
# p_number is locally scoped
# Global Scoped variables:
# label the device label.
function check_overlap(partition_names, partitions, new_part_name, new_start, new_size, extended_margin, new_type, new_part_number, pName, p_type, p_start, p_size, p_number) {
    # Used for extended volumes (logical disks)
    extended_margin = 2;
    # Set new_type variable. (Partition Type -- extended, ntfs, ext4, etc...)
    new_type = int(partitions[new_part_name, "type"]);
    # Set new_start
    new_start = int(new_start);
    # Set new_size
    new_size = int(new_size);
    # Set new_part_number variable. Self explanatory.
    new_part_number = int(partitions[new_part_name, "number"]);
    # Iterate our aprtitions.
    for (pName in partition_names) {
        # Partitions will not overlap themselves, so skip.
        if (new_part_name == pName) {
            continue;
        }
        # Set the type variable from original layout.
        p_type = partitions[pName, "type"];
        # Set the start of the original drive.
        p_start = int(partitions[pName, "start"]);
        # Set the size of the original drive.
        p_size = int(partitions[pName, "size"]);
        # Set the partition number.
        p_number = int(partitions[pName, "number"]);
        # Empty partitions aren't going to have any overlap, so skip.
        if (p_size == 0) {
            continue;
        }
        # New size checks.
        if (new_start < 0) {
            printf("ERROR: New Start postition (%d) on (%s) is less than 0.\n", new_start, pName);
            return 1;
        }
        if (new_start > int(diskSize)) {
            printf("ERROR: New Start postition (%d) on (%s) is larger than the disk (%d).\n.", new_start, pName, int(diskSize));
            return 1;
        }
        if (new_start + new_size < 0) {
            printf("ERROR: New start and size (%d) on (%s) is less than 0.\n", new_start + new_size, pName);
            return 1;
        }
        if (new_start + new_size > int(diskSize)) {
            printf("ERROR: New start and size (%d) on (%s) is larger than the disk (%d).\n", new_start + new_size, pName, int(diskSize));
            return 1;
        }
        # Overlap checks.
        if (p_type == 5 || p_type == "f") {
            # The partition being tested against is the extended container, so
            # the question is containment, not overlap: a logical partition
            # must sit wholly inside it, and anything else must sit wholly
            # outside. The guard used to read `p_number > 4`, but p_number is
            # the container's own number and an extended partition is always a
            # primary (1-4) -- so the containment test never ran and a computed
            # layout whose logicals spilled out of their container was still
            # reported "consistent".
            if (new_part_number > 4) {
                if (new_start < p_start + extended_margin) {
                    printf("ERROR: new_start < p_start + extended_margin value at (%s).\n", pName);
                    return 1;
                }
                if (new_start >= p_start + p_size) {
                    printf("ERROR: new_start >= p_start + p_size value at (%s).\n", pName);
                    return 1;
                }
                if (new_start + new_size <= p_start + extended_margin) {
                    printf("ERROR: new_start + new_size <= p_start + extended_margin value at (%s).\n", pName);
                    return 1;
                }
                if (new_start + new_size > p_start + p_size) {
                    printf("ERROR: new_start + new_size > p_start + p_size value at (%s).\n", pName);
                    return 1;
                }
            }
        } else if (new_start >= p_start) {
            if (new_start < p_start + p_size) {
                printf("ERROR: new_start < p_start + p_size at (%s).\n", pName);
                return 1;
            }
        }
    }
    return 0;
}

# Displays the information in sfdisk type format for us.
# Requires partition_names and partitions.
# partition_names is an array of all the partition names.
# partitions is an array containing the data we need.
#  Partitions are sent in an array of form:
#   partitions['name']['start'] = value;
#   partitions['name']['size'] = value;
# pName is locally scoped
# p_device is locally scoped
# p_start is locally scoped
# p_size is locally scoped
# p_type is locally scoped
# p_flag is locally scoped
# p_uuid is locally scoped
# p_name is locally scoped
# p_attrs is locally scoped
# typelabel is locally scoped
# old_sorted_in is locally scoped
# Global Scoped variables (meaning not needed to pass to the function:
# unit the unit type
# label the device label
# labelid the device label id
# device the device itself
function display_output(partition_names, partitions, pName, p_device, p_start, p_size, p_type, p_flag, p_uuid, p_name, p_attrs, typelabel, old_sorted_in) {
    # If unit is not set, or has no value, set to sectors.
    if (!unit) {
        unit = "sectors";
    }
    # Type label can shift, by default set to Id=
    typelabel = "Id=";
    # If label is set, set label to type=
    if (label) {
        typelabel = "type=";
    }
    # If label, labelid, and device are all set,
    # add to the sfdisk file.
    if (label && labelid && device) {
        printf("label: %s\nlabel-id: %s\ndevice: %s\n", label, labelid, device);
    }
    # Add unit to the sfdisk file.
    printf("unit: %s\n", unit);
    # If the first lba field is set store it too.
    if (firstlba) {
        printf("first-lba: %d\n", firstlba);
    }
    if (lastlba) {
        printf("last-lba: %d\n", lastlba);
    }
    if (sectorsize) {
        printf("sector-size: %d\n", sectorsize);
    }
    printf("\n");
    # Emit in ascending partition number. sfdisk consumes this file top to
    # bottom, so an extended partition has to be written before any logical
    # partition that lives inside it -- see by_partition_number().
    old_sorted_in = PROCINFO["sorted_in"];
    PROCINFO["sorted_in"] = "by_partition_number";
    # Iterate our partition names.
    for (pName in partition_names) {
        # Set our p_device variable.
        p_device = partitions[pName, "device"];
        # Set our p_start variable.
        p_start = int(partitions[pName, "start"]);
        # set our p_size variable.
        p_size = int(partitions[pName, "size"]);
        # Set our p_minsize variable;
        p_minsize = int(partitions[pName, "minsize"]);
        # set our p_type variable.
        p_type = partitions[pName, "type"];
        # Write our data into the sfdisk file.
        printf("%s : start=%12d, size=%12d, %s%s", p_device, p_start, p_size, typelabel, p_type);
        # If label is gpt do these things.
        # else we need the flags.
        if (label == "gpt") {
            # Set our p_uuid variable.
            p_uuid = partitions[pName, "uuid"];
            # Set our p_name variable. (probably could be pName)
            p_name = partitions[pName, "name"];
            # Set our p_attrs variable.
            p_attrs = partitions[pName, "attrs"];
            # If uuid is set, append to line. (Printf before if statement)
            if (p_uuid != "") {
                printf(", uuid=%s", p_uuid);
            }
            # If name is set, append to line. (Printf before if statement)
            if (p_name != "") {
                printf(", name=%s", p_name);
            }
            # If attrs is set, append to line. (Printf before if statement)
            if (p_attrs != "") {
                printf(", attrs=%s", p_attrs);
            }
        } else {
            # Set our p_flag variable.
            p_flag = partitions[pName, "flags"];
            # If flag is set, append to line. (Printf before the if statement)
            if (p_flag != "") {
                printf("%s", p_flag);
            }
        }
        # Write new line from partition info.
        printf("\n");
    }
    PROCINFO["sorted_in"] = old_sorted_in;
    return 0;
}

# Resizes the partition, currently really just shrinks.
# Requires partition_names, partitions, and args.
# partition_names is an array of all the partition names.
# partitions is an array containing the data we need.
#  Partitions are sent in an array of form:
#   partitions['name']['start'] = value;
#   partitions['name']['size'] = value;
# args are the arguments from the caller.
# pName is locally scoped
# new_size is locally scoped
# p_start is locally scoped
# Global Scoped variables (meaning not needed to pass to the function:
# target the device to work off of
# unit the unit type
function resize_partition(partition_names, partitions, args, pName, new_start, new_size) {
    # Iterate our partitions.
    for (pName in partition_names) {
        # If pName is not the target, skip.
        if (pName != target) {
            continue;
        }
        # If unit is not sectors, skip.
        if (unit != "sectors") {
            continue;
        }
        # Set our p_start position to the current start.
        new_start = int(partitions[pName, "start"]);
        # sizePos is a BYTE count -- funcs.sh passes the size it just shrank the
        # filesystem to -- and this table is in logical sectors, so the divisor is
        # the logical sector size. It is NOT SECTOR_SIZE, which is an alignment
        # quantum that only equals the sector size on a 512-byte disk; dividing by
        # it on a 4Kn disk produced a size 8x too large. Rounding is UP, because
        # the filesystem is already sizePos bytes: a partition rounded down would
        # be smaller than the filesystem inside it. See ADR-0016.
        new_size = int((int(sizePos) + int(LOGICAL_SECTOR_SIZE) - 1) / int(LOGICAL_SECTOR_SIZE));
        # Check the overlap.
        overlap = check_overlap(partition_names, partitions, target, new_start, new_size);
        # If there was an issue in checking overlap, skip.
        if (overlap != 0) {
            continue;
        }
        # Sets the new start position.
        # This function currently is only called
        # for capture, so this shouldn't change.
        # Left here for the future to allow changing
        # if we needed to.
        # Ultimately to switch the start position, we
        # could do something like below from check_overlap:
        # partitions[target, "start"] = p_start;
        # partitions[target, "start"] = p_start;
        # Sets the new size which is passed into the script
        # directly. As long as no overlap we know the shrunk
        # size is safe.
        partitions[target, "start"] = new_start;
        partitions[target, "size"] = new_size;
    }
    # last-lba is deliberately NOT recomputed here. It describes where the disk
    # ends, sfdisk -d read it from the disk we are about to write back to, and
    # shrinking one partition does not move the end of a disk. Recomputing it as
    # diskSize - firstlba emitted a last-lba past the end of a 4Kn disk (diskSize
    # arrived in 512-byte units) and made sfdisk refuse the whole table; on a
    # 512-byte disk it silently reserved 1 MiB of tail that the true value
    # (diskSize - 34 on GPT) does not, which fail-loud would now abort on for any
    # image whose last partition reached into it. fill_disk()'s own assignment is
    # a different case and stays: there we are building a table for a disk whose
    # size we were told, and its clamp has to agree with what it emits. ADR-0016.
    return 0;
}

# Moves the partitions around as needed.
# Requires partition_names, partitions, and args.
# partition_names is an array of all the partition names.
# partitions is an array containing the data we need.
#  Partitions are sent in an array of form:
#   partitions['name']['start'] = value;
#   partitions['name']['size'] = value;
# args are the arguments from the caller.
# pName is locally scoped
# new_start is locally scoped
# new_size is locally scoped
# Global Scoped variables (meaning not needed to pass to the function:
# target the device to work off of
# unit the unit type
# MIN_START is the minimum start point of the drive
function move_partition(partition_names, partitions, args, pName, new_start, new_size) {
    # Iterate our partitions.
    for (pName in partition_names) {
        # If pName is not the target, skip.
        if (pName != target) {
            continue;
        }
        # If unit is not sectors, skip.
        if (unit != "sectors") {
            continue;
        }
        # Ensure start postition is aligned properly.
        new_start = int(sizePos) + int(SECTOR_SIZE);
        new_start -= (new_start % int(SECTOR_SIZE));
        # If the new_start is less than the MIN_START
        # ensure the new_start is equal to the min start point.
        if (new_start < int(MIN_START)) {
            new_start = int(MIN_START);
        }
        # Set the new size variable.
        new_size = int(partitions[pName, "size"]);
        overlap = check_overlap(partition_names, partitions, target, new_start, new_size);
        if (overlap != 0) {
            continue;
        }
        # Ensure our values are adjusted.
        partitions[target, "start"] = new_start;
        partitions[target, "size"] = new_size;
    }
    return 0;
}

# Fill the disk space.
# Requires partition_names, partitions, and args.
# partition_names is an array of all the partition names.
# partitions is an array containing the data we need.
#  Partitions are sent in an array of form:
#   partitions['name']['start'] = value;
#   partitions['name']['size'] = value;
# args are the arguments from the caller.
# fixed_partitions is locally scoped
# original_variable is locally scoped
# original_fixed is locally scoped
# new_variable is locally scoped
# extended_margin is locally scoped
# pName is locally scoped
# p_type is locally scoped
# p_number is locally scoped
# p_size is locally scoped
# p_minsize is locally scoped
# i is locally scoped
# partition_starts is locally scoped
# ordered_starts is locally scoped
# old_sorted_in is locally scoped
# curr_start is locally scoped
# ext_name is locally scoped (the extended partition's device name, if any)
# ext_end is locally scoped
# p_end is locally scoped
# logical_count is locally scoped
function fill_disk(partition_names, partitions, args, n, fixed_partitions, original_variable, original_fixed, new_variable, extended_margin, pName, p_type, p_number, p_size, p_minsize, i, partition_starts, ordered_starts, old_sorted_in, curr_start, ext_name, ext_end, p_end, logical_count) {
    # Used for extended volumes (logical disks)
    extended_margin = 2;
    # The "find the next partition" scan below infers a partition's original
    # size from where its neighbor starts, so the partition_names traversals
    # need a defined order -- ascending partition number, the order the dump
    # was written in. See by_partition_number().
    old_sorted_in = PROCINFO["sorted_in"];
    PROCINFO["sorted_in"] = "by_partition_number";
    # Ensure we start at 0 for original sizes.
    original_variable = 0;
    # Fixed should be MIN_START.
    original_fixed = int(MIN_START);
    # full size initialize.
    full_size = 0;
    # Tell if we have extended.
    # Trim any beginning or trailling colons
    gsub(/^[:]+|[:]+$/, "", fixedList);
    if (firstlba && lastlba) {
        original_fixed += firstlba;
        full_size = int(lastlba);
    }
    # Iterate partitions and setup any unfound
    # fixed partitions.
    for (pName in partition_names) {
        # Set p_type variable.
        p_type = partitions[pName, "type"];
        # Set p_number variable.
        p_number = int(partitions[pName, "number"]);
        # Set p_start variable.
        p_start = int(partitions[pName, "start"]);
        # Set partition starts.
        partition_starts[p_start] = pName;
        # Set p_size variable.
        p_size = int(partitions[pName, "size"]);
        # Regex setter.
        regex = "(^|[:])"p_number"([:]|$)"
        # If we're dos label do stuff.
        if (label != "gpt") {
            # If this is an extended partition
            # The full size is set by the extended start + extended size.
            if (p_type == 5 || p_type == "f") {
                # Only set full size if needed.
                if (full_size == 0) {
                    # Get our full size.
                    full_size = p_start + p_size;
                }
                original_fixed += int(MIN_START);
                continue;
            }
            if (p_number > 4) {
                original_fixed += int(MIN_START);
            }
        }
        # Add 0 sized parts to fixed size.
        if (p_size == 0) {
            if (!match(fixedList, regex)) {
                fixedList = fixedList":"p_number;
            }
        }
        # Add swap to fixed size.
        if (p_type == 82) {
            if (!match(fixedList, regex)) {
                fixedList = fixedList":"p_number;
            }
        }
        # If fixed, add the partition size.
        if (!match(fixedList, regex)) {
            # Increment the variable value.
            original_variable += p_size;
            continue;
        }
        original_fixed += p_size;
        partitions[pName, "orig_size"] = p_size;
    }
    # This just finds and set's the original sizes.
    for (pName in partition_names) {
        # Set p_type variable.
        p_type = partitions[pName, "type"];
        # Set p_number variable.
        p_number = int(partitions[pName, "number"]);
        # Set p_start variable.
        p_start = int(partitions[pName, "start"]);
        # Set partition starts.
        partition_starts[p_start] = pName;
        # Set p_size variable.
        p_size = int(partitions[pName, "size"]);
        # Set p_next_start variable.
        p_next_start = 0;
        # Set the orig size variable.
        p_orig_size = int(partitions[pName, "orig_size"]);
        # Reset the found param.
        found = 0;
        # If orig size already set, skip.
        if (p_orig_size > 0) {
            continue;
        }
        if (label != "gpt") {
            if (p_type == 5 || p_type == "f") {
                p_next_start = full_size - p_start;
                partitions[pName, "orig_size"] = p_next_start;
                continue;
            }
        }
        # Rescan to get the next partition to find the start.
        # This will figure out the original size.
        for (p_name in partition_names) {
            if (p_name == pName) {
                found = 1;
                continue;
            }
            if (found) {
                p_next_start = int(partitions[p_name, "start"]);
                partitions[pName, "orig_size"] = p_next_start - p_start;
                break;
            }
        }
        if (p_next_start == 0) {
            if (full_size > 0) {
                p_next_start = full_size - p_start;
            }
            partitions[pName, "orig_size"] = p_next_start;
        }
    }
    # Trim any beginning or trailling colons
    gsub(/^[:]+|[:]+$/, "", fixedList);
    # How much room do we have available.
    new_variable = int(diskSize) - original_fixed;
    # We will loop the partitions again to get sizes.
    for (pName in partition_names) {
        # Reset our p_type variable.
        p_type = partitions[pName, "type"];
        # Reset our p_number variable.
        p_number = int(partitions[pName, "number"]);
        # Reset our p_start variable.
        p_start = int(partitions[pName, "start"]);
        # Reset our p_size variable.
        p_size = int(partitions[pName, "size"]);
        # Reset our p_minsize variable.
        p_minsize = int(partitions[pName, "minsize"]);
        # Ensure p_size is aligned.
        p_size -= (p_size % int(SECTOR_SIZE));
        # Reset our p_orig_size variable.
        p_orig_size = int(partitions[pName, "orig_size"]);
        # Regex setter.
        regex = "(^|[:])"p_number"([:]|$)"
        # If a fixed partition, go to next.
        if (match(fixedList, regex)) {
            continue;
        }
        # An extended partition holds no data of its own -- it is a container
        # whose extent is defined by the logical partitions inside it. Scaling
        # its captured size by the same percentage as a data partition is what
        # made the container run off the end of the target disk. Its size is
        # derived from where the logicals actually land, after the start
        # positions below have been assigned.
        if (label != "gpt" && (p_type == 5 || p_type == "f")) {
            continue;
        }
        # Get's the percentage increase/decrease and makes adjustment.
        p_size = new_variable * p_size / original_variable;
        # If the new size is smaller than the minsize reset the size to at least equal the min size.
        if (p_size < p_minsize) {
            p_size = p_minsize;
        }
        # Ensure we're aligned.
        p_size -= (p_size % int(SECTOR_SIZE));
        # Ensure the partition size is setup.
        partitions[pName, "size"] = p_size;
    }
    # Assign the new start positions.
    asort(partition_starts, ordered_starts, "@ind_num_asc");
    # asort() indexes ordered_starts 1..n in ascending start order, and the loop
    # below accumulates curr_start as it walks, so this traversal must follow
    # that index order rather than the by-partition-number order used above.
    PROCINFO["sorted_in"] = "@ind_num_asc";
    # curr-start must be set to MIN_START initially.
    curr_start = int(MIN_START);
    # Prior size should start as 0
    prior_size = 0;
    # The exclusive upper bound for a partition's end. On GPT the tail of the
    # disk holds the backup GPT header and partition-entry array (the same span
    # firstlba reserves at the front), so nothing may run past diskSize -
    # firstlba -- which is exactly the last-lba this function emits below, so the
    # clamp and the emitted last-lba can never disagree. On non-GPT labels
    # firstlba is unset and the whole disk is usable.
    disk_end = int(diskSize);
    if (firstlba) {
        disk_end = int(diskSize) - int(firstlba);
    }
    # Iterate the ordered start positions.
    for (i in ordered_starts) {
        # pName will be the ordered start position.
        pName = ordered_starts[i];
        # Set p_type.
        p_type = partitions[pName, "type"];
        # Set p_number.
        p_number = int(partitions[pName, "number"]);
        # Set p_size.
        p_size = int(partitions[pName, "size"]);
        # Set p_start.
        p_start = int(partitions[pName, "start"]);
        # Regex setter.
        regex = "(^|[:])"p_number"([:]|$)"
        # Skip empty sized partitions.
        if (p_size == 0) {
            continue;
        }
        # If we are not GPT test for logical/extended partitions
        # And ensure our current start is give just the chunk size
        # for an even balance.
        if (label != "gpt") {
            # The start position for the extended/logical partitions
            # needs to be increased by the chunk size.
            # Otherwise increase it by the p_size.
            if (p_type == "5" || p_type == "f") {
                curr_start += int(MIN_START) - extended_margin;
                partitions[pName, "start"] = curr_start;
                # Remember the container so its size can be derived once every
                # logical partition inside it has been placed.
                ext_name = pName;
                curr_start += extended_margin;
                logical_count = 0;
                continue;
            }
            # Every logical partition is introduced by its own EBR sector,
            # which lives in the gap immediately before it. The first logical
            # gets that gap from the extended partition's own placement above
            # (the container starts MIN_START - extended_margin early, so the
            # first logical lands MIN_START past the previous partition). Each
            # later logical needs a fresh gap of its own -- loop one already
            # reserves MIN_START per logical in original_fixed, but nothing was
            # spending it, so the logicals were packed end to end with nowhere
            # to put their EBRs and sfdisk ran out of free sectors.
            if (p_number > 4) {
                if (logical_count > 0) {
                    curr_start += int(MIN_START);
                }
                logical_count++;
            }
        }
        p_start = curr_start;
        if (prior_size > 0 && p_start < (prior_size + prior_start)) {
            p_start = prior_size + prior_start;
        }
        # p_start is adjusted to whatever curr_start is.
        # Set the new start value.
        partitions[pName, "start"] = p_start;
        curr_start += p_size;
        # Set the partitions start to our adjusted start.
        partitions[pName, "start"] = p_start;
        # Set the last boundary properly, keeping GPT's reserved backup area
        # (everything past disk_end) clear so the final partition can't overwrite
        # the backup GPT header/entries.
        if (p_start + p_size > disk_end) {
            p_size -= (p_start + p_size - disk_end);
            p_size -= (p_size % int(SECTOR_SIZE));
            partitions[pName, "size"] = p_size;
        }
        prior_size = p_size;
        prior_start = p_start;
    }
    # Size the extended container to exactly span the logical partitions that
    # were just placed inside it. Doing it here rather than in the sizing loop
    # means the container automatically follows the clamp applied to the last
    # logical above, so it can never extend past disk_end.
    if (label != "gpt" && ext_name != "") {
        ext_end = 0;
        for (pName in partition_names) {
            if (int(partitions[pName, "number"]) <= 4) {
                continue;
            }
            p_end = int(partitions[pName, "start"]) + int(partitions[pName, "size"]);
            if (p_end > ext_end) {
                ext_end = p_end;
            }
        }
        # An extended partition with no logicals inside it keeps its captured
        # size; there is nothing to derive an extent from.
        if (ext_end > int(partitions[ext_name, "start"])) {
            partitions[ext_name, "size"] = ext_end - int(partitions[ext_name, "start"]);
        }
    }
    # Set our lastlba
    if (firstlba) {
        lastlba = int(diskSize) - firstlba;
    }
    PROCINFO["sorted_in"] = old_sorted_in;
    # Check for any overlaps.
    return check_all_partitions(partition_names, partitions);
}
beginning = 0;
# This is where it all begins (See->BEGIN) :)
BEGIN {
    # Arguments - Use "-v var=val" when calling this script
    # CHUNK_SIZE;
    # MIN_START;
    # action;
    # target;
    # sizePos;
    # diskSize;
    # fixedList;
    # LOGICAL_SECTOR_SIZE;
    # processSfdisk always passes this; defaulted so the script stays runnable by
    # hand, and so an older caller cannot turn the resize divisor into a division
    # by zero.
    if (!LOGICAL_SECTOR_SIZE) {
        LOGICAL_SECTOR_SIZE = 512;
    }
    label = "";
    unit = "";
    partitions[0] = "";
    partition_names[0] = "";
}
# Set label global variable
/^label:/{label = $2}
# Set labelid global variable
/^label-id:/{labelid = $2}
# Set device global variable
/^device:/{device = $2}
# Set unit global variable
/^unit:/{unit = $2}
# Get the first lba sector.
/^first-lba:/{firstlba = $2}
# Get the last lba sector.
/^last-lba:/{lastlba = $2}
# Get the sector size
/^sector-size:/{sectorsize = $2}
# Get the start positions
/start=/{
    # Get Partition Name
    part_name = $1;
    # Start setup of partitions.
    partitions[part_name, "device"] = part_name;
    # Start setup of partition_names.
    partition_names[part_name] = part_name;
    # Isolate Partition Number.
    # The regex can handle devices like mmcblk0p3 and nvme0n1p2
    part_number = gensub(/^.*[^0-9]([0-9]+)/, "\\1", 1, part_name);
    # Set the partitions number.
    partitions[part_name, "number"] = part_number;
    # Separate attributes
    split($0, fields, ",");
    # Get start value
    gsub(/.*start= */, "", fields[1]);
    # Set start point.
    partitions[part_name, "start"] = fields[1];
    # Get size value
    gsub(/.*size= */, "", fields[2]);
    # Set size.
    # If minsize is not set, set it.
    if (!partitions[part_name, "minsize"]) {
        partitions[part_name, "minsize"] = fields[2];
    }
    partitions[part_name, "size"] = fields[2];
    # Get type/id value
    gsub(/.*(type|Id)= */, "", fields[3]);
    # Set type.
    partitions[part_name, "type"] = fields[3];
    # Sets up based on dos/gpt label types.
    # Sets defaults if unit type is neither.
    if (label == "dos") {
        split($0, typeList, "type=");
        # Sets the partition flags.
        part_flags = gensub(/^[^,$]*/, "",1,typeList[2]);
        # Ensure object has the flags defined.
        partitions[part_name, "flags"] = part_flags;
    } else if (label == "gpt") {
        # Get uuid value
        gsub(/.*uuid= */, "", fields[4]);
        # Set the uuid in the object
        partitions[part_name, "uuid"] = fields[4];

        testfield1 = fields[5];
        testfield2 = fields[5];
        namefield = gsub(/.*name= */, "", testfield1);
        attrsfield = gsub(/.*attrs= */, "", testfield2);
        if (namefield > 0) {
            # Checking for corrupted name field, e.g. name="attrs=\x22RequiredPartition GUID:63"
            testnameattrs = fields[5];
            nameattrsfield = gsub(/.*attrs= */, "", testnameattrs);
            gsub(/.*name= */, "", fields[5]);
            if (nameattrsfield > 0) {
                attrs_special_char = gsub(/.*\\x22 */, "\"", testnameattrs);
                partitions[part_name, "attrs"] = testnameattrs;
            }
            else {
                partitions[part_name, "name"] = fields[5];
            }
        } else if (attrsfield > 0) {
            gsub(/.*attrs= */, "", fields[5]);
            partitions[part_name, "attrs"] = fields[5];
        }
        # Get attrs value
        if (fields[6]) {
            gsub(/.*attrs= */, "", fields[6]);
            # Only set attrs when it's not being set by fields[5] before or if it's different to that
            if (partitions[part_name, "attrs"] == "" || partitions[part_name, "attrs"] != fields[6]) {
                # Sets the attrs in the object.
                partitions[part_name, "attrs"] = fields[6];
            }
        }
    } else {
        split($0, typeList, "Id=");
        # Gets the partition flags.
        part_flags = gensub(/^[^,$]*/, "",1,typeList[2]);
        # Sets the flags to the object.
        partitions[part_name, "flags"] = part_flags;
    }
} END {
    # Clean up.
    delete partitions[0];
    delete partition_names[0];
    # If the action value is resize run resize_partition function.
    # If the action value is move run the move_partition function.
    # If the action value is filldisk run the fill_disk function.
    # If the action value is neither of the above fail out.
    switch (action) {
        case "resize":
            rc = resize_partition(partition_names, partitions, args);
            break;
        case "move":
            rc = move_partition(partition_names, partitions, args);
            break;
        case "filldisk":
            rc = fill_disk(partition_names, partitions, args);
            break;
        default:
            printf("Please enter a proper action.\n");
            exit(1);
    }
    # Display output.
    display_output(partition_names, partitions);
    # A nonzero return means the computed table is inconsistent (e.g. fill_disk
    # detected overlapping partitions). Exit non-zero so the caller refuses to
    # apply a corrupt table instead of silently writing it to disk.
    if (rc != 0)
        exit(1);
}
